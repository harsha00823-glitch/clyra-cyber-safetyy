import Tesseract from 'tesseract.js';

/**
 * Extracts text from an image file using local client-side WebAssembly OCR.
 * Privacy-first: The image never leaves the user's browser.
 */
export async function extractTextFromImage(file: File): Promise<string> {
  try {
    const result = await Tesseract.recognize(file, 'eng');
    return result.data.text;
  } catch (error) {
    console.error('OCR Error:', error);
    throw new Error('Failed to extract text from the image. Ensure the image is clear and contains readable text.');
  }
}
