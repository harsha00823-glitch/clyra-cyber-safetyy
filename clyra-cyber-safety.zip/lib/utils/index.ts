// Utility helper functions for Cyber Safety Platform

export function formatRiskLevel(level: 'low' | 'medium' | 'high'): string {
  switch (level) {
    case 'low':
      return 'Low Risk';
    case 'medium':
      return 'Moderate Risk';
    case 'high':
      return 'High Risk';
    default:
      return 'Unknown Risk';
  }
}
