import { AnalysisResult, DetectionSignal, RiskLevel } from '@/types/analysis';
import { checkPhishingPatterns } from './rules/phishing';
import { checkKeywords } from './rules/keywords';
import { checkAuthorityImpersonation } from './rules/authority';
import { checkCoercionAndThreats } from './rules/coercion';
import { checkMaliciousAppSignals } from './rules/maliciousApps';
import { checkFinancialLures } from './rules/financial';
import { analyzeUrlStructure } from './rules/url';

const DISCLAIMER_TEXT =
  'Risk score is an automated assessment based on detected warning signals. It is not proof that content is malicious.';

/**
 * Redacts sensitive tokens such as long numbers, card digits, or OTPs from display previews.
 */
export function sanitizeInputPreview(input: string): string {
  if (!input) return '';
  return input
    .trim()
    // Redact 12-16 digit numbers (card numbers, Aadhaar)
    .replace(/\b\d{4}[-\s]?\d{4}[-\s]?\d{4}(?:[-\s]?\d{4})?\b/g, '[REDACTED NUMBER]')
    // Redact 6 digit OTP codes
    .replace(/\b\d{6}\b/g, '[OTP CODE]')
    // Cap preview length to 280 chars
    .slice(0, 280);
}

/**
 * Extracts URLs embedded within general text messages.
 */
export function extractUrlsFromText(text: string): string[] {
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"'{}|\\^`[\]]+/gi;
  const matches = text.match(urlRegex) || [];
  return Array.from(new Set(matches));
}

/**
 * Core Deterministic Risk Scoring Engine.
 * Follows: INPUT -> NORMALIZATION -> SIGNAL EXTRACTION -> PATTERN MATCHING -> RISK SCORING -> EXPLANATION
 */
export function analyzeContent(
  rawInput: string,
  type: 'message' | 'url' | 'screenshot' = 'message'
): AnalysisResult {
  const normalized = (rawInput || '').trim();
  const allSignals: DetectionSignal[] = [];
  let investigationDetails: Record<string, unknown> | undefined = undefined;

  if (!normalized) {
    return {
      score: 0,
      level: 'low',
      summary: 'No input provided for analysis.',
      disclaimer: DISCLAIMER_TEXT,
      signals: [],
      analysisType: type,
      inputPreview: '',
      timestamp: new Date().toISOString(),
    };
  }

  // 1. URL Analysis Pathway
  if (type === 'url' || /^(?:https?:\/\/|www\.)/i.test(normalized) || (!normalized.includes(' ') && normalized.includes('.'))) {
    const { signals: urlSignals, investigation } = analyzeUrlStructure(normalized);
    allSignals.push(...urlSignals);
    investigationDetails = investigation as unknown as Record<string, unknown>;
  }

  // 2. Message / Text Analysis Pathway
  // If input is purely a URL, skip conversational text rules to avoid false positives on domain words
  if (type !== 'url' || normalized.includes(' ')) {
    const phishingSignals = checkPhishingPatterns(normalized);
    const keywordSignals = checkKeywords(normalized);
    const authoritySignals = checkAuthorityImpersonation(normalized);
    const coercionSignals = checkCoercionAndThreats(normalized);
    const appSignals = checkMaliciousAppSignals(normalized);
    const financialSignals = checkFinancialLures(normalized);

    allSignals.push(
      ...phishingSignals,
      ...keywordSignals,
      ...authoritySignals,
      ...coercionSignals,
      ...appSignals,
      ...financialSignals
    );
  }

  // 3. Embedded URLs inside text messages
  if (type !== 'url') {
    const embeddedUrls = extractUrlsFromText(normalized);
    for (const url of embeddedUrls) {
      const { signals: embeddedUrlSignals } = analyzeUrlStructure(url);
      allSignals.push(...embeddedUrlSignals);
    }
  }

  // Deduplicate signals by id
  const seenIds = new Set<string>();
  const uniqueSignals: DetectionSignal[] = [];
  for (const s of allSignals) {
    if (!seenIds.has(s.id)) {
      seenIds.add(s.id);
      uniqueSignals.push(s);
    }
  }

  // 4. Deterministic Risk Scoring (0 - 100)
  let rawScore = 0;
  let hasCritical = false;
  let hasHigh = false;

  for (const s of uniqueSignals) {
    rawScore += s.weight;
    if (s.severity === 'critical') hasCritical = true;
    if (s.severity === 'high') hasHigh = true;
  }

  // Multi-signal synergy rules (synergistic threats are far riskier than isolated keywords)
  const hasAuthority = uniqueSignals.some((s) => s.category === 'authority_impersonation');
  const hasCoercion = uniqueSignals.some((s) => s.category === 'threat_coercion');
  const hasPhishing = uniqueSignals.some((s) => s.category === 'phishing');
  const hasCredentials = uniqueSignals.some((s) => s.name.toLowerCase().includes('credential') || s.name.toLowerCase().includes('otp'));
  const hasAppThreat = uniqueSignals.some((s) => s.category === 'malicious_app');
  const hasUrgency = uniqueSignals.some((s) => s.id === 'kw-urgency-modifiers' || s.name.toLowerCase().includes('urgency') || s.name.toLowerCase().includes('urgent'));
  const hasIsolation = uniqueSignals.some((s) => s.id === 'kw-isolation-coercion' || s.id === 'coercion-secrecy-isolation');
  const hasLegal = uniqueSignals.some((s) => s.id === 'kw-legal-intimidation' || s.id === 'auth-legal-notice-threat' || s.id === 'coercion-case-implication');
  const hasDeceptiveUrl = uniqueSignals.some((s) => s.id === 'url-deceptive-hostname-keywords' || s.id.startsWith('url-brand-spoof'));
  const hasActionPath = uniqueSignals.some((s) => s.id === 'url-suspicious-path');

  // Digital Arrest synergy (Authority/Legal + Coercion/Isolation)
  if ((hasAuthority || hasLegal) && (hasCoercion || hasIsolation)) {
    rawScore = Math.max(rawScore, 85);
  }

  // Phishing / Credential theft synergy
  if (hasPhishing && hasCredentials) {
    rawScore = Math.max(rawScore, 82);
  }

  // Urgent Phishing / Account Verification pressure
  if (hasPhishing && hasUrgency) {
    rawScore = Math.max(rawScore, 65);
  }

  // Deceptive URL + Action Path (e.g. /login on phishing domain)
  if (hasDeceptiveUrl && hasActionPath) {
    rawScore = Math.max(rawScore, 65);
  }

  // Remote Access extortion
  if (hasAppThreat && (hasAuthority || hasCoercion)) {
    rawScore = Math.max(rawScore, 88);
  }

  // Floor adjustments based on highest severity
  if (hasCritical && rawScore < 75) {
    rawScore = 75;
  } else if (hasHigh && rawScore < 50) {
    rawScore = 52;
  }

  // Bound score between 0 and 100
  const finalScore = Math.min(100, Math.max(0, Math.round(rawScore)));

  // 5. Determine Risk Level
  // 0 - 24 = Low (Safe) -> GREEN
  // 25 - 49 = Moderate / Medium -> YELLOW
  // 50 - 74 = High -> RED
  // 75 - 100 = Critical -> RED
  let level: RiskLevel = 'low';
  if (finalScore >= 75) {
    level = 'critical';
  } else if (finalScore >= 50) {
    level = 'high';
  } else if (finalScore >= 25) {
    level = 'medium'; // Moderate
  } else {
    level = 'low';
  }

  // 6. Summary generation
  let summary = 'No prominent threat signals were detected.';
  if (level === 'critical') {
    summary = `Critical risk detected with ${uniqueSignals.length} threat indicator(s), including severe coercion, impersonation, or credential theft patterns.`;
  } else if (level === 'high') {
    summary = `High risk detected. Identified ${uniqueSignals.length} warning signal(s) consistent with deceptive tactics.`;
  } else if (level === 'medium') {
    summary = `Moderate risk detected. Identified ${uniqueSignals.length} cautionary signal(s) requiring verification.`;
  } else if (uniqueSignals.length > 0) {
    summary = `Low risk with ${uniqueSignals.length} minor informational observation(s). Proceed with normal caution.`;
  }

  return {
    score: finalScore,
    level,
    summary,
    disclaimer: DISCLAIMER_TEXT,
    signals: uniqueSignals,
    analysisType: type,
    inputPreview: sanitizeInputPreview(normalized),
    timestamp: new Date().toISOString(),
    investigationDetails,
  };
}
