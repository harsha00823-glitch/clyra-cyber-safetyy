import { analyzeContent } from '../engine';

interface TestCase {
  id: number;
  name: string;
  input: string;
  type: 'message' | 'url';
  expectedMinScore: number;
  expectedMaxScore: number;
  expectedCategory?: string;
  expectedSignalSnippet?: string;
}

export const TEST_CASES: TestCase[] = [
  // 1. Normal harmless message
  {
    id: 1,
    name: 'Normal harmless message',
    input: 'Hey Ramesh, are we still meeting for tea this evening at 5 PM? Let me know.',
    type: 'message',
    expectedMinScore: 0,
    expectedMaxScore: 24,
  },
  // 2. Bank phishing message
  {
    id: 2,
    name: 'Bank phishing message',
    input: 'Dear Customer, your HDFC bank account access has been suspended due to pending security update. Click here to verify immediately: http://hdfc-verify-netbanking.xyz/login',
    type: 'message',
    expectedMinScore: 50,
    expectedMaxScore: 100,
    expectedCategory: 'phishing',
  },
  // 3. OTP request
  {
    id: 3,
    name: 'OTP request',
    input: 'Urgent: Please share the 6-digit OTP sent to your phone to confirm your refund of Rs 4,999 from the bank.',
    type: 'message',
    expectedMinScore: 60,
    expectedMaxScore: 100,
    expectedCategory: 'keywords',
  },
  // 4. KYC scam
  {
    id: 4,
    name: 'KYC scam',
    input: 'Dear User, your SBI SIM card and banking KYC expired today. Complete your KYC update within 2 hours or your account will be permanently blocked.',
    type: 'message',
    expectedMinScore: 50,
    expectedMaxScore: 100,
    expectedCategory: 'phishing',
  },
  // 5. Digital arrest message
  {
    id: 5,
    name: 'Digital arrest message',
    input: 'This is Crime Branch Police. A parcel in your name containing illegal narcotics and fake passports was seized by Customs. Connect to Skype video call immediately for digital arrest procedure. Do not disconnect.',
    type: 'message',
    expectedMinScore: 75,
    expectedMaxScore: 100,
    expectedCategory: 'threat_coercion',
  },
  // 6. Fake government warning
  {
    id: 6,
    name: 'Fake government warning',
    input: 'TRAI notice: Department of Telecommunications order. Your mobile number is associated with illegal activities and will be disconnected in 2 hours unless verified.',
    type: 'message',
    expectedMinScore: 50,
    expectedMaxScore: 100,
    expectedCategory: 'authority_impersonation',
  },
  // 7. Fake job scam
  {
    id: 7,
    name: 'Fake job scam',
    input: 'Congratulations! Selected for Part-time Online Review Job. Earn 5000 daily guaranteed returns. Claim bonus prize and deposit registration fee to begin.',
    type: 'message',
    expectedMinScore: 25,
    expectedMaxScore: 85,
    expectedCategory: 'keywords',
  },
  // 8. Suspicious shortened URL
  {
    id: 8,
    name: 'Suspicious shortened URL',
    input: 'https://bit.ly/3kX9yz1',
    type: 'url',
    expectedMinScore: 15,
    expectedMaxScore: 50,
    expectedCategory: 'url_structure',
  },
  // 9. IP-address URL
  {
    id: 9,
    name: 'IP-address URL',
    input: 'http://192.168.1.105/banking/sbi/login.php',
    type: 'url',
    expectedMinScore: 70,
    expectedMaxScore: 100,
    expectedCategory: 'url_structure',
  },
  // 10. HTTPS legitimate URL
  {
    id: 10,
    name: 'HTTPS legitimate URL',
    input: 'https://www.onlinesbi.sbi/index.html',
    type: 'url',
    expectedMinScore: 0,
    expectedMaxScore: 24,
  },
  // 11. Obfuscated URL
  {
    id: 11,
    name: 'Obfuscated URL with excessive subdomains',
    input: 'http://secure.login.sbi.com.user-verify.xyz/update/account',
    type: 'url',
    expectedMinScore: 50,
    expectedMaxScore: 100,
    expectedCategory: 'domain_reputation',
  },
  // 12. Financial scam
  {
    id: 12,
    name: 'Financial scam',
    input: 'You have won 25 Lakhs in RBI lottery jackpot! Transfer processing fee of Rs 2500 to official RBI verification account to release your prize.',
    type: 'message',
    expectedMinScore: 50,
    expectedMaxScore: 100,
    expectedCategory: 'authority_impersonation',
  },
  // 13. Malicious APK warning
  {
    id: 13,
    name: 'Malicious APK warning',
    input: 'Download PM Kisan Yojana update APK from unverified link. Install AnyDesk and grant accessibility permission for support agent to fix your pension.',
    type: 'message',
    expectedMinScore: 70,
    expectedMaxScore: 100,
    expectedCategory: 'malicious_app',
  },
  // 14. Authority impersonation
  {
    id: 14,
    name: 'Authority impersonation',
    input: 'Central Bureau of Investigation (CBI) summons issued. Supreme Court arrest warrant active against your Aadhaar card for money laundering.',
    type: 'message',
    expectedMinScore: 60,
    expectedMaxScore: 100,
    expectedCategory: 'authority_impersonation',
  },
];

export function runAllTests(): { passed: number; failed: number; results: Array<{ id: number; name: string; success: boolean; score: number; level: string; reason?: string }> } {
  let passed = 0;
  let failed = 0;
  const results = [];

  for (const tc of TEST_CASES) {
    const res = analyzeContent(tc.input, tc.type);
    const scoreInRange = res.score >= tc.expectedMinScore && res.score <= tc.expectedMaxScore;
    const categoryMatched = !tc.expectedCategory || res.signals.some((s) => s.category === tc.expectedCategory);

    const success = scoreInRange && categoryMatched;
    if (success) {
      passed++;
    } else {
      failed++;
    }

    results.push({
      id: tc.id,
      name: tc.name,
      success,
      score: res.score,
      level: res.level,
      reason: !scoreInRange
        ? `Score ${res.score} outside expected range [${tc.expectedMinScore}, ${tc.expectedMaxScore}]`
        : !categoryMatched
        ? `Expected category ${tc.expectedCategory} not found in signals`
        : undefined,
    });
  }

  return { passed, failed, results };
}
