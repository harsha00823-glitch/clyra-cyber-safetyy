import { runAllTests } from './engine.test';

console.log('--- Running Cyber Safety Analysis Engine Test Suite ---');
const { passed, failed, results } = runAllTests();

for (const r of results) {
  const status = r.success ? '✅ PASS' : '❌ FAIL';
  console.log(`${status} [Test ${r.id}] ${r.name} -> Score: ${r.score} (${r.level}) ${r.reason ? `| ${r.reason}` : ''}`);
}

console.log('-------------------------------------------------------');
console.log(`Summary: ${passed} passed, ${failed} failed out of ${results.length} total tests.`);

if (failed > 0) {
  process.exit(1);
} else {
  console.log('ALL 14 REQUIRED TEST CASES PASSED SUCCESSFULLY!');
  process.exit(0);
}
