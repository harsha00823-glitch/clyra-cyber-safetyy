import { DetectionSignal } from '@/types/analysis';

const APP_PATTERNS = [
  {
    id: 'app-remote-access',
    name: 'Remote Access / Screen Sharing Software',
    patterns: [
      /\b(?:anydesk|teamviewer|rustdesk|quicksupport|airdroid|zoho\s*assist|screen\s*share|remote\s*support)\b/i,
      /\b(?:install|download)\s*(?:app\s*for\s*support|application\s*to\s*resolve|software\s*to\s*verify)\b/i,
    ],
    severity: 'critical' as const,
    weight: 35,
    explanation: 'Fraudsters instruct victims to install remote desktop tools to view passwords, mirror bank apps, and steal 2FA OTPs.',
    recommendedAction: 'Do NOT install AnyDesk or screen sharing tools at the behest of callers. If installed, immediately turn on Airplane Mode and uninstall.',
  },
  {
    id: 'app-apk-sideload',
    name: 'Unverified APK Sideloading Invitation',
    patterns: [
      /\b(?:download|install)\s*(?:apk|\.apk|app\s*from\s*link|unverified\s*source)\b/i,
      /\b(?:pm\s*kisan\s*app|sbi\s*rewards\s*apk|police\s*verification\s*apk|challan\s*pay\s*apk)\b/i,
      /\b(?:enable\s*unknown\s*sources|allow\s*third\s*party\s*apps|install\s*outside\s*play\s*store)\b/i,
    ],
    severity: 'high' as const,
    weight: 30,
    explanation: 'Sideloaded APKs bypass Google Play Protect checks and frequently contain banking trojans or keyloggers.',
    recommendedAction: 'Only install software from official app stores like Google Play Store or Apple App Store. Never click APK links in WhatsApp or SMS.',
  },
  {
    id: 'app-dangerous-permissions',
    name: 'Sensitive Device Permission Solicitation',
    patterns: [
      /\b(?:accessibility\s*service|read\s*sms|receive\s*sms|display\s*over\s*other\s*apps|draw\s*over|device\s*admin(?:istrator)?)\b/i,
      /\b(?:grant\s*permission\s*to\s*read|enable\s*accessibility)\b/i,
    ],
    severity: 'critical' as const,
    weight: 32,
    explanation: 'Accessibility and SMS permissions allow malicious apps to secretly read incoming 2FA codes and auto-click banking prompts.',
    recommendedAction: 'Never grant Accessibility or SMS permissions to apps claiming to be utility, banking, or customer support utilities.',
  },
];

export function checkMaliciousAppSignals(text: string): DetectionSignal[] {
  const signals: DetectionSignal[] = [];

  for (const item of APP_PATTERNS) {
    for (const pattern of item.patterns) {
      const match = text.match(pattern);
      if (match) {
        signals.push({
          id: item.id,
          name: item.name,
          category: 'malicious_app',
          severity: item.severity,
          explanation: item.explanation,
          recommendedAction: item.recommendedAction,
          matchedSnippet: match[0],
          weight: item.weight,
        });
        break;
      }
    }
  }

  return signals;
}
