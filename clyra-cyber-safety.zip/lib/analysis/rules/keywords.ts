import { DetectionSignal } from '@/types/analysis';

interface KeywordGroup {
  id: string;
  name: string;
  keywords: string[];
  severity: DetectionSignal['severity'];
  weight: number;
  explanation: string;
  recommendedAction: string;
}

const HIGH_RISK_KEYWORD_GROUPS: KeywordGroup[] = [
  {
    id: 'kw-security-credentials',
    name: 'Sensitive Authentication Credentials',
    keywords: [
      'otp', 'cvv', 'mpin', 'upi pin', 'atm pin', 'netbanking password',
      'card security code', 'auth token', 'one-time password', 'bank password'
    ],
    severity: 'critical',
    weight: 28,
    explanation: 'Contains explicit terms related to authentication credentials that should remain strictly confidential.',
    recommendedAction: 'Keep all PINs and OTPs private. Treat any request to share them as an active compromise attempt.',
  },
  {
    id: 'kw-account-verification',
    name: 'Account Verification & Service Threat Keywords',
    keywords: [
      'verification urgently', 'verify your details', 'verify your account',
      'account verification', 'interruption of service', 'service interruption',
      'avoid interruption', 'avoid suspension', 'account suspended', 'account blocked',
      'unauthorized access', 'security alert', 'confirm identity', 're-verify account',
      'service deactivation', 'avoid service disruption'
    ],
    severity: 'medium',
    weight: 22,
    explanation: 'Contains phrases commonly used in social engineering to manufacture false urgency around account verification and service suspension.',
    recommendedAction: 'Do not follow links or prompts inside the message. Log into your provider app or visit official support directly.',
  },
  {
    id: 'kw-financial-transactions',
    name: 'High-Risk Financial Transaction Terms',
    keywords: [
      'lottery', 'prize money', 'jackpot', 'crypto investment', 'guaranteed returns',
      'claim refund', 'cashback reward', 'bonus credits', 'part-time earning', 'daily payout'
    ],
    severity: 'medium',
    weight: 18,
    explanation: 'Scammers promise unexpected windfalls, refunds, or high investment returns to trap users into sending advance fees.',
    recommendedAction: 'Ignore unsolicited prizes or investments offering unrealistically high guaranteed returns.',
  },
  {
    id: 'kw-legal-intimidation',
    name: 'Legal Threat & Arrest Terminology',
    keywords: [
      'legal notice', 'urgent legal notice', 'serious case', 'linked to a serious case',
      'identity has been linked', 'identity linked', 'arrest warrant', 'court notice',
      'police summons', 'cbi case', 'money laundering', 'narcotics parcel',
      'customs seizure', 'digital arrest', 'law enforcement notice', 'statutory notice'
    ],
    severity: 'high',
    weight: 32,
    explanation: 'Language designed to intimidate and panic the victim by weaponizing legal or law enforcement terms.',
    recommendedAction: 'Indian law enforcement does not serve arrest warrants or question suspects via messaging apps. Disconnect immediately.',
  },
  {
    id: 'kw-isolation-coercion',
    name: 'Coercive Secrecy & Compliance Directives',
    keywords: [
      'do not contact anyone', 'do not tell anyone', 'do not inform family',
      'keep confidential', 'strictly confidential', 'follow our instructions',
      'follow our instructions immediately', 'strict secrecy', 'official secrets act',
      'do not disconnect', 'isolate yourself', 'maintain silence'
    ],
    severity: 'high',
    weight: 32,
    explanation: 'Explicit commands demanding secrecy, isolation, or unconditional compliance to prevent victims from consulting trusted family or police.',
    recommendedAction: 'Break isolation immediately. Real police or courts encourage consulting legal counsel and family.',
  },
  {
    id: 'kw-urgency-modifiers',
    name: 'Urgent Psychological Pressure Words',
    keywords: [
      'urgently', 'urgent', 'immediately', 'immediate', 'right away', 'without delay',
      'urgent action', 'within 2 hours', 'within 24 hours', 'last warning', 'final notice',
      'action required today', 'time running out', 'expires today', 'expiring soon', 'act now'
    ],
    severity: 'medium',
    weight: 18,
    explanation: 'Urgent phrases are deliberately deployed to bypass rational thinking and prevent verification.',
    recommendedAction: 'Take a step back. Genuine administrative processes always allow time for verification.',
  },
];

export function checkKeywords(text: string): DetectionSignal[] {
  const normalized = text.toLowerCase();
  const signals: DetectionSignal[] = [];

  for (const group of HIGH_RISK_KEYWORD_GROUPS) {
    const matched: string[] = [];
    for (const kw of group.keywords) {
      // Escape for regex and allow flexible whitespace between words
      const escaped = kw
        .replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')
        .replace(/\s+/g, '\\s+');
      const regex = new RegExp(`\\b${escaped}\\b`, 'i');
      if (regex.test(normalized)) {
        matched.push(kw);
      }
    }

    if (matched.length > 0) {
      signals.push({
        id: group.id,
        name: group.name,
        category: 'keywords',
        severity: group.severity,
        explanation: `${group.explanation} (Matched terms: ${matched.join(', ')})`,
        recommendedAction: group.recommendedAction,
        matchedSnippet: matched.join(', '),
        weight: group.weight,
      });
    }
  }

  return signals;
}
