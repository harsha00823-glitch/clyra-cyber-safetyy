import { DetectionSignal } from '@/types/analysis';

const AUTHORITY_PATTERNS = [
  {
    id: 'auth-police-cbi',
    name: 'Law Enforcement & Investigating Agency Impersonation',
    patterns: [
      /\b(?:cbi|central\s*bureau\s*of\s*investigation|crime\s*branch|cyber\s*crime\s*cell|delhi\s*police|mumbai\s*police|enforcement\s*directorate|\bed\b)\b/i,
      /\b(?:police\s*officer|inspector|dsp|commissioner|investigating\s*officer)\b/i,
    ],
    severity: 'critical' as const,
    weight: 35,
    explanation: 'Scammers frequently impersonate CBI, Mumbai/Delhi Police, and Cyber Crime officers to stage "Digital Arrests".',
    recommendedAction: 'No police department investigates cases or orders arrests via Skype or WhatsApp. Hang up and dial 1930.',
  },
  {
    id: 'auth-legal-notice-threat',
    name: 'Urgent Legal Notice / Statutory Threat Claim',
    patterns: [
      /\b(?:urgent\s*)?legal\s*notice\b.*(?:identity|serious\s*case|case|linked|arrest|court|action|immediately)/i,
      /\b(?:formal|statutory|official)\s*notice\b.*(?:investigation|offence|offense|prosecution|arrest)/i,
      /\bthis\s*is\s*an?\s*(?:urgent\s*)?legal\s*notice\b/i,
    ],
    severity: 'high' as const,
    weight: 30,
    explanation: 'Scammers issue fabricated "urgent legal notices" via electronic messaging to mimic formal judicial process and intimidate recipients.',
    recommendedAction: 'Formal legal notices are never served over SMS or WhatsApp. Do not panic and consult a licensed advocate if ever in doubt.',
  },
  {
    id: 'auth-judiciary-court',
    name: 'Judicial & Court Impersonation',
    patterns: [
      /\b(?:supreme\s*court|high\s*court|chief\s*justice|judge|non-bailable\s*warrant|court\s*order|summons\s*issued)\b/i,
    ],
    severity: 'critical' as const,
    weight: 30,
    explanation: 'Forged court orders and judicial threats are fabricated to terrify citizens into compliance.',
    recommendedAction: 'Indian courts never serve arrest warrants over digital messaging apps or demand instant bail transfers.',
  },
  {
    id: 'auth-telecom-trai',
    name: 'Telecom / TRAI / DOT Impersonation',
    patterns: [
      /\b(?:trai|telecom\s*regulatory\s*authority|department\s*of\s*telecommunications|\bdot\b)\b.*(?:block|deactivat|illegal\s*activit|sim\s*card|disconnect|suspend)/i,
      /\byour\s*(?:mobile|sim|number)\s*(?:is|will\s*be)\s*(?:associated|blocked|disconnected)\b.*(?:illegal|disconnect|hour|verif)/i,
    ],
    severity: 'high' as const,
    weight: 28,
    explanation: 'TRAI does not block individual mobile numbers or demand verification under threat of disconnection.',
    recommendedAction: 'Report telecom impersonation calls on the Department of Telecommunications Chakshu portal (sancharsaathi.gov.in).',
  },
  {
    id: 'auth-rbi-tax',
    name: 'Financial Regulator / Tax Authority Impersonation',
    patterns: [
      /\b(?:rbi|reserve\s*bank\s*of\s*india|income\s*tax\s*department|income\s*tax\s*officer|customs\s*officer)\b/i,
      /\b(?:rbi\s*verification\s*account|rbi\s*safe\s*account|unclaimed\s*refund)\b/i,
    ],
    severity: 'high' as const,
    weight: 28,
    explanation: 'The Reserve Bank of India does not hold individual public accounts or conduct "fund verifications".',
    recommendedAction: 'Never send money to any account claiming to be an "RBI Safe Account" or "Verification Escrow".',
  },
];

export function checkAuthorityImpersonation(text: string): DetectionSignal[] {
  const signals: DetectionSignal[] = [];

  for (const item of AUTHORITY_PATTERNS) {
    for (const pattern of item.patterns) {
      const match = text.match(pattern);
      if (match) {
        signals.push({
          id: item.id,
          name: item.name,
          category: 'authority_impersonation',
          severity: item.severity,
          explanation: item.explanation,
          recommendedAction: item.recommendedAction,
          matchedSnippet: match[0],
          weight: item.weight,
        });
        break;
      }
    }
  }

  return signals;
}
