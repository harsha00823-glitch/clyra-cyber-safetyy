import { DetectionSignal } from '@/types/analysis';

const COERCION_PATTERNS = [
  {
    id: 'coercion-video-mandate',
    name: 'Mandatory Video Call / Digital Arrest Order',
    patterns: [
      /\b(?:stay\s*on|join|open|connect)\s*(?:the\s*)?(?:skype|whatsapp|video\s*call|camera)\b/i,
      /\b(?:digital\s*arrest|virtual\s*custody|surveillance\s*order)\b/i,
      /\bdo\s*not\s*(?:disconnect|cut|end)\s*the\s*call\b/i,
    ],
    severity: 'critical' as const,
    weight: 40,
    explanation: 'There is no concept of "Digital Arrest" in Indian Law. Law enforcement does not place suspects under camera surveillance over video calls.',
    recommendedAction: 'Disconnect the video call immediately. You are not under legal custody. Alert trusted family members and call 1930.',
  },
  {
    id: 'coercion-secrecy-isolation',
    name: 'Coerced Secrecy & Isolation Tactic',
    patterns: [
      /\bdo\s*not\s*(?:contact|tell|inform|speak\s*to|call)\s*(?:anyone|anybody|any\s*person|family|friends|lawyer|third\s*party|police)\b/i,
      /\b(?:keep\s*(?:this|it)\s*(?:strictly\s*)?confidential|maintain\s*secrecy|national\s*security\s*secret)\b/i,
      /\b(?:do\s*not\s*inform\s*family|isolate\s*yourself|go\s*to\s*a\s*private\s*room)\b/i,
      /\b(?:under\s*official\s*secrets\s*act|confidential\s*investigation)\b/i,
    ],
    severity: 'critical' as const,
    weight: 35,
    explanation: 'Scammers demand strict secrecy and isolation to prevent victims from consulting family members, friends, or real police officers.',
    recommendedAction: 'Immediately tell family or colleagues. Break the isolation scam tactic right away.',
  },
  {
    id: 'coercion-case-implication',
    name: 'Severe Legal Case / Criminal Implication Threat',
    patterns: [
      /\b(?:identity|name|aadhaar|pan|number)\s*(?:has\s*been|is)\s*(?:linked|involved|associated|implicated)\s*(?:in|to|with)\s*(?:a\s*)?(?:serious|criminal|illegal|fraud|laundering|narcotics)\s*(?:case|investigation|matter|crime)\b/i,
      /\b(?:serious\s*case|criminal\s*charges?|arrest\s*warrant)\b.*(?:identity|linked|investigation|notice)/i,
    ],
    severity: 'critical' as const,
    weight: 35,
    explanation: 'Scammers invent fabricated criminal charges or claim your identity is tied to serious offenses to cause severe distress and obedience.',
    recommendedAction: 'Indian law enforcement does not issue criminal notifications or arrest threats over WhatsApp, SMS, or Telegram. Hang up immediately.',
  },
  {
    id: 'coercion-compliance-demand',
    name: 'Forced Immediate Compliance Directive',
    patterns: [
      /\bfollow\s*(?:our|all|the)\s*instructions\s*(?:immediately|without\s*delay|strictly|carefully)\b/i,
      /\b(?:comply\s*immediately|surrender\s*immediately|fail(?:ure)?\s*to\s*comply\s*will\s*lead\s*to\s*arrest)\b/i,
    ],
    severity: 'high' as const,
    weight: 28,
    explanation: 'Coercive commands demanding immediate and unquestioning obedience are designed to bypass victim verification.',
    recommendedAction: 'Never obey instructions from unverified callers or messages. Stop all communication immediately.',
  },
  {
    id: 'coercion-illegal-parcel',
    name: 'Illegal Parcel / Narcotics Seizure Tactic',
    patterns: [
      /\b(?:parcel|package|shipment)\b.*(?:customs|drugs|narcotics|mdma|fake\s*passports|illegal\s*substances|seized)\b/i,
      /\b(?:fedex|dhl|customs\s*department)\b.*(?:taiwan|cambodia|thailand|dubai|illegal)/i,
    ],
    severity: 'high' as const,
    weight: 30,
    explanation: 'A classic courier scam where fraudsters claim a parcel in your name contains narcotics or forged passports to manufacture panic.',
    recommendedAction: 'Real courier companies and Customs will not connect you to a "police officer" on WhatsApp or ask for security deposits.',
  },
  {
    id: 'coercion-fund-transfer',
    name: 'Asset Verification / Bail Deposit Demand',
    patterns: [
      /\b(?:transfer|deposit|send)\b.*(?:all\s*your\s*funds|verification\s*account|clearance\s*account|avoid\s*arrest|refunded\s*after\s*investigation)/i,
      /\b(?:finance\s*audit|asset\s*verification|provisional\s*bail\s*amount)\b/i,
    ],
    severity: 'critical' as const,
    weight: 40,
    explanation: 'Government agencies NEVER ask citizens to transfer money to "temporary safe accounts" or verify personal assets via RTGS/NEFT/UPI.',
    recommendedAction: 'Never transfer funds under threat. Once transferred to fraud mule accounts, money is quickly laundered through crypto or ATMs.',
  },
];

export function checkCoercionAndThreats(text: string): DetectionSignal[] {
  const signals: DetectionSignal[] = [];

  for (const item of COERCION_PATTERNS) {
    for (const pattern of item.patterns) {
      const match = text.match(pattern);
      if (match) {
        signals.push({
          id: item.id,
          name: item.name,
          category: 'threat_coercion',
          severity: item.severity,
          explanation: item.explanation,
          recommendedAction: item.recommendedAction,
          matchedSnippet: match[0],
          weight: item.weight,
        });
        break;
      }
    }
  }

  return signals;
}
