import { DetectionSignal } from '@/types/analysis';

const FINANCIAL_AND_JOB_PATTERNS = [
  {
    id: 'fin-fake-job-lure',
    name: 'Part-Time / Task / Review Job Fraud',
    patterns: [
      /\b(?:part-time|online\s*review|telegram\s*task|youtube\s*like|hotel\s*review)\s*job\b/i,
      /\b(?:earn\s*\d+\s*(?:daily|per\s*day|hourly)|work\s*from\s*home\s*guaranteed\s*salary)\b/i,
      /\b(?:deposit\s*registration\s*fee|prepaid\s*task|vip\s*upgrade\s*task)\b/i,
    ],
    severity: 'high' as const,
    weight: 30,
    explanation: 'Scammers offer high daily payouts for rating hotels, liking videos, or doing "merchant tasks", then demand deposits to withdraw fake earnings.',
    recommendedAction: 'Legitimate employers never ask candidates to pay registration fees or fund prepaid crypto tasks.',
  },
  {
    id: 'fin-lottery-windfall',
    name: 'Lottery / Prize / Windfall Scam',
    patterns: [
      /\b(?:won|winner|awarded|lucky\s*draw)\b.*(?:\b\d+\s*(?:lakh|crore|million|dollars|usd|inr)\b|lottery|jackpot)/i,
      /\b(?:claim\s*(?:your)?\s*prize|release\s*(?:your)?\s*winnings)\b.*(?:fee|deposit|tax|charges)/i,
    ],
    severity: 'high' as const,
    weight: 32,
    explanation: 'Unsolicited lottery winnings requiring advance "taxes", "processing fees", or "customs duty" are classic advance-fee scams.',
    recommendedAction: 'Never pay money to claim a prize you never entered. Genuine lotteries do not ask for advance clearance fees.',
  },
  {
    id: 'fin-investment-crypto-lure',
    name: 'High-Yield Investment / Crypto Ponzi Scheme',
    patterns: [
      /\b(?:guaranteed\s*(?:returns|profit)|double\s*your\s*money|100%\s*safe\s*investment|crypto\s*arbitrage)\b/i,
      /\b(?:expert\s*trading\s*group|exclusive\s*insider\s*signals)\b/i,
    ],
    severity: 'high' as const,
    weight: 28,
    explanation: 'Promises of guaranteed investment returns with zero risk are hallmarks of illegal financial pyramid and fake trading scams.',
    recommendedAction: 'Verify financial advisors through SEBI (sebi.gov.in). Never transfer investment funds to personal UPI IDs.',
  },
];

export function checkFinancialLures(text: string): DetectionSignal[] {
  const signals: DetectionSignal[] = [];

  for (const item of FINANCIAL_AND_JOB_PATTERNS) {
    for (const pattern of item.patterns) {
      const match = text.match(pattern);
      if (match) {
        signals.push({
          id: item.id,
          name: item.name,
          category: 'financial',
          severity: item.severity,
          explanation: item.explanation,
          recommendedAction: item.recommendedAction,
          matchedSnippet: match[0],
          weight: item.weight,
        });
        break;
      }
    }
  }

  return signals;
}
