import { DetectionSignal, URLInvestigation } from '@/types/analysis';

const KNOWN_SHORTENERS = new Set([
  'bit.ly', 'tinyurl.com', 'is.gd', 't.co', 'cutt.ly', 'tiny.cc', 'rb.gy', 'shorte.st',
  'adf.ly', 'goo.gl', 'ow.ly', 'buff.ly', 'rebrand.ly', 'bl.ink', 'v.gd', 'qr.ae',
]);

const HIGH_RISK_TLDS = new Set([
  'xyz', 'top', 'click', 'buzz', 'work', 'rest', 'tk', 'ml', 'ga', 'cf', 'gq', 'fit', 'loan', 'cam', 'country', 'stream',
]);

const BRAND_KEYWORDS = [
  'sbi', 'hdfc', 'icici', 'axis', 'pnb', 'paytm', 'phonepe', 'gpay', 'amazon', 'flipkart',
  'netflix', 'paypal', 'apple', 'microsoft', 'google', 'aadhaar', 'uidai', 'incometax',
  'cybercrime', 'police', 'trai', 'whatsapp', 'telegram', 'facebook',
];

const PHISHING_COMPOUND_TERMS = [
  'account-verify', 'secure-account', 'verify-account', 'account-update', 'login-verify',
  'security-update', 'kyc-update', 'update-kyc', 'netbanking-verify', 'online-verify',
  'customer-support-desk', 'portal-verify', 'auth-verify', 'secure-login', 'secure-verify',
  'account-security', 'verify-identity', 'account-check', 'user-verify', 'secure-account-verify'
];

const PHISHING_SINGLE_TOKENS = [
  'secure', 'account', 'verify', 'verification', 'login', 'signin', 'auth', 'update', 'banking', 'wallet', 'kyc'
];

export function analyzeUrlStructure(rawUrl: string): { signals: DetectionSignal[]; investigation: URLInvestigation } {
  const signals: DetectionSignal[] = [];

  let cleanUrl = rawUrl.trim();
  if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
    // If protocol omitted, evaluate with https default for parsing but signal missing protocol
    cleanUrl = 'https://' + cleanUrl;
  }

  let parsed: URL;
  try {
    parsed = new URL(cleanUrl);
  } catch {
    signals.push({
      id: 'url-invalid-format',
      name: 'Malformed URL Syntax',
      category: 'url_structure',
      severity: 'high',
      explanation: 'The provided URL is improperly formatted or utilizes obfuscated character encodings.',
      recommendedAction: 'Do not attempt to open malformed web links. They often hide deceptive browser redirect scripts.',
      matchedSnippet: rawUrl,
      weight: 30,
    });

    const emptyInvestigation: URLInvestigation = {
      originalUrl: rawUrl,
      protocol: 'unknown',
      hostname: 'unknown',
      pathname: '',
      queryParams: {},
      isHttps: false,
      isIpAddress: false,
      subdomainCount: 0,
      subdomains: [],
      domain: '',
      tld: '',
      isShortener: false,
      hasPunycode: false,
      hasSuspiciousKeywords: false,
      pathDepth: 0,
      advancedLookupStatus: 'not_configured',
      advancedLookupMessage: 'Advanced reputation lookup is not configured. Displaying local structural analysis.',
    };

    return { signals, investigation: emptyInvestigation };
  }

  const hostname = parsed.hostname.toLowerCase();
  const protocol = parsed.protocol.replace(':', '');
  const pathname = parsed.pathname;

  // 1. Insecure Protocol Check (HTTP)
  const isHttps = protocol === 'https';
  if (!isHttps) {
    signals.push({
      id: 'url-insecure-http',
      name: 'Insecure Protocol (Unencrypted HTTP)',
      category: 'url_structure',
      severity: 'medium',
      explanation: 'The link uses plain HTTP rather than secure HTTPS. Data transmitted over HTTP can be intercepted or manipulated.',
      recommendedAction: 'Never enter credentials, passwords, or personal details on websites without HTTPS encryption.',
      matchedSnippet: `${protocol}://`,
      weight: 15,
    });
  }

  // 2. IP Address as Hostname
  const isIpV4 = /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname);
  const isIpV6 = /^\[?[a-fA-F0-9:]+\]?$/.test(hostname);
  const isIpAddress = isIpV4 || isIpV6;

  if (isIpAddress) {
    signals.push({
      id: 'url-ip-hostname',
      name: 'Direct IP Address Hostname',
      category: 'url_structure',
      severity: 'critical',
      explanation: 'The URL directs straight to an IP address rather than a registered domain name. Legitimate consumer services never use raw IP URLs.',
      recommendedAction: 'Avoid visiting raw IP addresses. Scammers use them to bypass domain registration takedowns.',
      matchedSnippet: hostname,
      weight: 40,
    });
  }

  // 3. Known URL Shortener
  const isShortener = KNOWN_SHORTENERS.has(hostname);
  if (isShortener) {
    signals.push({
      id: 'url-shortener-hidden',
      name: 'URL Shortener (Obscured Target Destination)',
      category: 'url_structure',
      severity: 'medium',
      explanation: 'Shortened URLs mask the true destination domain, preventing inspection before clicking.',
      recommendedAction: 'Use a link expander tool or verify the actual destination before browsing shortened URLs received via text or social media.',
      matchedSnippet: hostname,
      weight: 20,
    });
  }

  // Domain breakdown
  const parts = hostname.split('.');
  const tld = parts.length > 1 ? parts[parts.length - 1] : '';
  const domain = parts.length > 1 ? parts[parts.length - 2] : hostname;
  const subdomains = parts.length > 2 ? parts.slice(0, parts.length - 2) : [];
  const subdomainCount = subdomains.length;

  // 4. Excessive Subdomains (Domain Cloaking)
  if (subdomainCount >= 3) {
    signals.push({
      id: 'url-excessive-subdomains',
      name: 'Excessive Subdomain Levels (Domain Spoofing Tactic)',
      category: 'url_structure',
      severity: 'high',
      explanation: `The URL contains ${subdomainCount} subdomain layers. Attackers prepend famous brand names as subdomains (e.g. sbi.com.user-verify.xyz) to deceive victims.`,
      recommendedAction: 'Always check the rightmost domain before the TLD (.com, .in). The text on the far right is the actual hosting entity.',
      matchedSnippet: hostname,
      weight: 25,
    });
  }

  // 5. Punycode / Internationalized Domain Name (Homograph Attack)
  const hasPunycode = hostname.includes('xn--');
  if (hasPunycode) {
    signals.push({
      id: 'url-punycode-homograph',
      name: 'Punycode / Homograph Deception Detected',
      category: 'url_structure',
      severity: 'high',
      explanation: 'Contains punycode (xn--), which can disguise Cyrillic or non-Latin characters that visually mimic standard Latin domain names.',
      recommendedAction: 'Be extremely cautious. Verify that the domain characters are genuine and not spoofed homoglyphs.',
      matchedSnippet: hostname,
      weight: 35,
    });
  }

  // 6. Brand Impersonation / Typosquatting in Hostname or Subdomain
  let hasSuspiciousKeywords = false;
  for (const brand of BRAND_KEYWORDS) {
    if (hostname.includes(brand)) {
      hasSuspiciousKeywords = true;
      const isLikelyLegitimate =
        hostname === `${brand}.com` ||
        hostname === `${brand}.co.in` ||
        hostname === `${brand}.in` ||
        hostname === `${brand}.org` ||
        hostname === `${brand}bank.com` ||
        hostname.endsWith(`.${brand}bank.com`) ||
        hostname.endsWith(`.${brand}.com`) ||
        hostname.endsWith(`.${brand}.co.in`) ||
        hostname.endsWith(`.${brand}.in`) ||
        hostname.endsWith(`.${brand}`) ||
        hostname.includes(`online${brand}.${brand}`);

      if (!isLikelyLegitimate) {
        signals.push({
          id: `url-brand-spoof-${brand}`,
          name: `Brand Impersonation Indicator (${brand.toUpperCase()})`,
          category: 'domain_reputation',
          severity: 'high',
          explanation: `The domain or subdomain mentions '${brand}', but does not match the official domain structure of the organization.`,
          recommendedAction: `Access ${brand.toUpperCase()} exclusively through their official verified website or mobile app. Do not click this link.`,
          matchedSnippet: hostname,
          weight: 32,
        });
        break; // Match first major brand
      }
    }
  }

  // 7. Deceptive Phishing / Security Compound Keywords in Subdomain or Hostname
  const matchedCompound = PHISHING_COMPOUND_TERMS.find((term) => hostname.includes(term));
  const tokenHits = PHISHING_SINGLE_TOKENS.filter((token) => {
    const regex = new RegExp(`(^|[-_.])${token}([-_.]|$)`, 'i');
    return regex.test(hostname);
  });

  const isTrustedProvider = [
    'google.com', 'microsoft.com', 'apple.com', 'github.com', 'amazon.com', 'gov.in', 'nic.in'
  ].some((d) => hostname === d || hostname.endsWith(`.${d}`));

  if (!isTrustedProvider && (matchedCompound || tokenHits.length >= 2)) {
    hasSuspiciousKeywords = true;
    signals.push({
      id: 'url-deceptive-hostname-keywords',
      name: 'Deceptive Phishing / Security Keywords in Domain',
      category: 'domain_reputation',
      severity: 'high',
      explanation: `The domain or subdomain ('${hostname}') contains combined security/verification keywords (${matchedCompound || tokenHits.join(', ')}) commonly used in phishing campaigns.`,
      recommendedAction: 'Do not enter passwords, OTPs, or personal data. Verify the authentic domain of the service directly.',
      matchedSnippet: hostname,
      weight: 28,
    });
  }

  // 8. High-Risk TLD
  if (HIGH_RISK_TLDS.has(tld)) {
    signals.push({
      id: 'url-high-risk-tld',
      name: `High-Risk Top-Level Domain (.${tld})`,
      category: 'domain_reputation',
      severity: 'medium',
      explanation: `The .${tld} top-level domain has a statistically high correlation with disposable spam and credential harvesting campaigns due to low registration hurdles.`,
      recommendedAction: 'Exercise heightened vigilance. Major financial and governmental bodies operate primarily on established .gov.in, .nic.in, .in, or .com domains.',
      matchedSnippet: `.${tld}`,
      weight: 18,
    });
  }

  // 9. Suspicious Path or Obfuscated Parameters
  const pathLower = (pathname + parsed.search).toLowerCase();
  const pathDepth = pathname.split('/').filter(Boolean).length;

  if (/(?:login|verify|kyc|signin|banking|account|update|wp-content\/plugins|eval|base64|download.*apk)/i.test(pathLower)) {
    signals.push({
      id: 'url-suspicious-path',
      name: 'High-Risk Action Path/Query Keywords',
      category: 'url_structure',
      severity: 'medium',
      explanation: 'The URL path explicitly requests account login, verification, or APK download actions outside of verified domains.',
      recommendedAction: 'Do not follow links asking to authenticate or update credentials unless you entered the address yourself.',
      matchedSnippet: pathname + (parsed.search ? parsed.search.slice(0, 30) : ''),
      weight: 15,
    });
  }

  // Query params
  const queryParams: Record<string, string> = {};
  parsed.searchParams.forEach((val, key) => {
    queryParams[key] = val.length > 50 ? val.slice(0, 50) + '...' : val;
  });

  const investigation: URLInvestigation = {
    originalUrl: rawUrl,
    protocol,
    hostname,
    pathname,
    queryParams,
    isHttps,
    isIpAddress,
    subdomainCount,
    subdomains,
    domain,
    tld,
    isShortener,
    hasPunycode,
    hasSuspiciousKeywords,
    pathDepth,
    advancedLookupStatus: 'not_configured',
    advancedLookupMessage: 'Advanced external reputation lookup is not configured in this environment. Displaying deterministic local structural analysis.',
  };

  return { signals, investigation };
}
