import { DetectionSignal } from '@/types/analysis';

interface PatternRule {
  id: string;
  name: string;
  patterns: RegExp[];
  severity: DetectionSignal['severity'];
  weight: number;
  explanation: string;
  recommendedAction: string;
}

const PHISHING_RULES: PatternRule[] = [
  {
    id: 'phish-kyc-urgency',
    name: 'Urgent KYC Verification Request',
    patterns: [
      /\b(?:kyc|re-kyc)\b.*(?:expire|suspend|deactivat|block|mandat|updat|link|within|immediately)/i,
      /\b(?:update|complete|verify)\b.*(?:your|the)?\s*\b(?:kyc|pan|aadhaar)\b.*(?:link|immediately|today|block)/i,
      /\b(?:sim|bank\s*account)\b.*(?:blocked|deactivated|disconnected)\b.*(?:kyc)/i,
    ],
    severity: 'high',
    weight: 28,
    explanation: 'Legitimate banks and telecom operators never threaten immediate account suspension over SMS or unverified links for KYC updates.',
    recommendedAction: 'Do not click the link or provide documents. Visit your official bank branch or app directly to check KYC status.',
  },
  {
    id: 'phish-account-verification-urgency',
    name: 'Urgent Account Verification & Service Interruption Threat',
    patterns: [
      /\b(?:account|service|access|profile)\b.*(?:needs?|requires?)\s*(?:verification|updating|validation)\b.*(?:urgently|immediately|today|avoid\s*(?:interruption|suspension|deactivation|blocking))/i,
      /\b(?:verify|update|confirm)\s*(?:your\s*)?(?:details|account|identity|information)\s*(?:urgently|immediately|now|promptly)\s*(?:to\s*avoid|or\s*face)?\s*(?:interruption|suspension|deactivation|blocking|closure|service\s*disruption)/i,
      /\b(?:avoid\s*(?:interruption|disruption|suspension)\s*of\s*(?:service|services)|prevent\s*account\s*deactivation)\b/i,
    ],
    severity: 'high',
    weight: 28,
    explanation: 'Urgent demands to verify account details to avoid immediate service interruption are typical social engineering phishing tactics.',
    recommendedAction: 'Do not reply or click provided links. Contact the official customer support service through their verified app or portal.',
  },
  {
    id: 'phish-account-suspension',
    name: 'Account Suspension Threat',
    patterns: [
      /\b(?:account|card|access|service)\b.*(?:has been|will be|is)\s*(?:suspended|blocked|terminated|frozen|locked)/i,
      /\b(?:immediate(?:ly)?\s*action\s*required|reactivate\s*your\s*account|avoid\s*(?:closure|penalty))/i,
    ],
    severity: 'high',
    weight: 24,
    explanation: 'Scammers frequently fabricate urgent account suspensions to induce panic and force hurried clicks on deceptive links.',
    recommendedAction: 'Log in only through the official verified app or official website. Never follow links sent via SMS or messaging apps.',
  },
  {
    id: 'phish-login-alert',
    name: 'Suspicious Security / Login Alert',
    patterns: [
      /\b(?:unauthorized|suspicious|unknown)\b.*(?:login|access|transaction|device|attempt)/i,
      /\bif\s*this\s*was\s*not\s*you\b.*(?:click|visit|link|cancel|revert|call)/i,
    ],
    severity: 'medium',
    weight: 20,
    explanation: 'Deceptive security alerts mimic bank or email notices with fake "cancel transaction" or "revert charge" links that harvest credentials.',
    recommendedAction: 'Do not click the link. Independently open your official banking app and check transaction history.',
  },
  {
    id: 'phish-credential-solicitation',
    name: 'Direct Credential / Secret Solicitation',
    patterns: [
      /\b(?:share|enter|send|provide|submit|confirm)\b.*(?:otp|one\s*time\s*password|pin|cvv|password|atm\s*pin|netbanking\s*password)/i,
      /\b(?:never\s*share\s*otp\b.*)?(?:share\s*this\s*otp\s*to\s*(?:cancel|verify|refund))/i,
      /\b(?:enter\s*(?:your)?\s*(?:mpin|upi\s*pin)\s*to\s*(?:receive|claim|accept))/i,
    ],
    severity: 'critical',
    weight: 35,
    explanation: 'Any message requesting your OTP, CVV, or PIN is fraudulent. Entering your UPI PIN always deducts money—it never receives money.',
    recommendedAction: 'Never share OTPs, CVVs, or enter your UPI PIN. Bank officials and customer support will never request your PIN.',
  },
  {
    id: 'phish-electricity-bill',
    name: 'Electricity / Utility Disconnection Scam',
    patterns: [
      /\b(?:electricity|power|bill|water|gas)\b.*(?:disconnect|cut\s*off|suspended)\b.*(?:tonight|today|immediately|officer)/i,
      /\b(?:contact|call)\b.*(?:electricity\s*officer|discom|power\s*department)\b/i,
    ],
    severity: 'high',
    weight: 30,
    explanation: 'Utility providers follow formal notice periods and never message personal mobile numbers demanding immediate payments to avoid power cuts.',
    recommendedAction: 'Do not call the number in the SMS. Pay your power bills only through official electricity board portals or authorized apps.',
  },
];

export function checkPhishingPatterns(text: string): DetectionSignal[] {
  const signals: DetectionSignal[] = [];

  for (const rule of PHISHING_RULES) {
    for (const pattern of rule.patterns) {
      const match = text.match(pattern);
      if (match) {
        signals.push({
          id: rule.id,
          name: rule.name,
          category: 'phishing',
          severity: rule.severity,
          explanation: rule.explanation,
          recommendedAction: rule.recommendedAction,
          matchedSnippet: match[0],
          weight: rule.weight,
        });
        break; // matched this rule, avoid duplicate signals for same rule
      }
    }
  }

  return signals;
}
