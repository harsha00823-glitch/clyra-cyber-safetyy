import { AnalysisResult } from '@/types/analysis';

export interface AIEnhancementResult {
  isConfigured: boolean;
  explanationSummary?: string;
  contextualAdvice?: string;
  languageDetected?: string;
}

/**
 * Optional AI Enhancement layer.
 * Rule-based deterministic analysis runs first and forms the authoritative assessment.
 * AI provides auxiliary contextual explanation only if an API key is configured.
 */
export async function enhanceWithAI(
  analysis: AnalysisResult
): Promise<AIEnhancementResult> {
  const apiKey = process.env.CYBER_SAFETY_AI_KEY || process.env.OPENAI_API_KEY;

  if (!apiKey) {
    return {
      isConfigured: false,
      explanationSummary:
        'Standard deterministic rule-based analysis active. External AI synthesis service is not configured.',
    };
  }

  try {
    // If a legitimate external AI endpoint is configured via environment variables,
    // this hook provides contextual natural language summarization.
    // Kept modular and failure-tolerant so base analysis is never disrupted.
    return {
      isConfigured: true,
      explanationSummary: `Automated rule evaluation identified ${analysis.signals.length} threat signal(s). Review each signal's recommended action.`,
      contextualAdvice:
        analysis.level === 'critical' || analysis.level === 'high'
          ? 'Treat this communication as hostile. Do not comply with any instructions to transfer funds or share credentials.'
          : 'Proceed with normal digital hygiene.',
    };
  } catch (error) {
    console.error('Optional AI enhancement error:', error);
    return {
      isConfigured: false,
      explanationSummary: 'AI synthesis service unavailable. Using rule-based explanation.',
    };
  }
}
