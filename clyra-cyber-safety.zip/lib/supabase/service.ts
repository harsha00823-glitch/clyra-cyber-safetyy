import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import { AnalysisResult } from '@/types/analysis';

/**
 * SERVER-ONLY Supabase Administrative Client.
 *
 * Used exclusively for server-side privileged operations such as recording
 * verified analysis sessions into analysis_sessions & analysis_signals
 * (which are locked down from browser clients via REVOKE INSERT/UPDATE/DELETE).
 *
 * NEVER import this file into any Client Component.
 */

export function getServiceSupabaseClient() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceKey) {
    return null;
  }

  return createClient(supabaseUrl, serviceKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}

/**
 * Safely persists an analysis session and its signals to Supabase.
 * Respects user privacy: only stores an SHA-256 input hash, a redacted preview,
 * the calculated score, risk level, and explainable signal descriptions.
 */
export async function persistAnalysisSession(
  analysis: AnalysisResult,
  rawInput: string,
  userId?: string | null
): Promise<{ sessionId?: string; persisted: boolean; note?: string }> {
  const client = getServiceSupabaseClient();

  if (!client) {
    return {
      persisted: false,
      note: 'Session persistence skipped: SUPABASE_SERVICE_ROLE_KEY is not configured in environment.',
    };
  }

  try {
    const inputHash = crypto.createHash('sha256').update(rawInput).digest('hex');
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30); // 30-day retention policy

    const { data: sessionData, error: sessionError } = await client
      .from('analysis_sessions')
      .insert({
        user_id: userId || null,
        analysis_type: analysis.analysisType,
        input_hash: inputHash,
        input_preview: analysis.inputPreview,
        risk_score: analysis.score,
        risk_level: analysis.level,
        signals_count: analysis.signals.length,
        expires_at: expiresAt.toISOString(),
      })
      .select('id')
      .single();

    if (sessionError || !sessionData) {
      console.error('Failed to insert analysis session:', sessionError);
      return { persisted: false, note: sessionError?.message };
    }

    const sessionId = sessionData.id;

    if (analysis.signals.length > 0) {
      const signalRecords = analysis.signals.map((s) => ({
        session_id: sessionId,
        signal_category: s.category,
        signal_name: s.name,
        severity: s.severity,
        description: s.explanation,
        matched_snippet: s.matchedSnippet || null,
        recommended_action: s.recommendedAction || null,
      }));

      const { error: signalsError } = await client
        .from('analysis_signals')
        .insert(signalRecords);

      if (signalsError) {
        console.error('Failed to insert analysis signals:', signalsError);
      }
    }

    return { sessionId, persisted: true };
  } catch (error) {
    console.error('Error persisting analysis:', error);
    return { persisted: false, note: (error as Error).message };
  }
}
