import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

export async function updateSession(request: NextRequest) {
  let supabaseResponse = NextResponse.next({
    request,
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          supabaseResponse = NextResponse.next({
            request,
          });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  // Check Supabase user
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Check demo session cookie for instant evaluation / testing
  const demoCookie = request.cookies.get("csp_demo_session")?.value;
  const isDemo = demoCookie === "true";
  const isAuthenticated = !!user || isDemo;

  const pathname = request.nextUrl.pathname;

  // Protect /dashboard
  if (pathname.startsWith("/dashboard") && !isAuthenticated) {
    const url = request.nextUrl.clone();
    url.pathname = "/auth/sign-in";
    return NextResponse.redirect(url);
  }

  // Redirect authenticated users away from auth pages (except reset-password/callback)
  if (
    isAuthenticated &&
    (pathname === "/auth/sign-in" ||
      pathname === "/auth/sign-up" ||
      pathname === "/auth/forgot-password")
  ) {
    const url = request.nextUrl.clone();
    url.pathname = "/dashboard";
    return NextResponse.redirect(url);
  }

  return supabaseResponse;
}
