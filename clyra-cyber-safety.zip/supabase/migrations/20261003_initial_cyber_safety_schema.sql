-- ============================================================================
-- Cyber Safety Platform — Initial Database Schema (Hardened)
-- VTU 2025 Scheme 3rd Semester Community Project
-- ============================================================================
-- Migration: 20261003_initial_cyber_safety_schema.sql
--
-- Creates 16 application tables across 8 domains:
--   1. User Profiles          (user_profiles)
--   2. Analysis Engine         (analysis_sessions, analysis_signals)
--   3. Detection Patterns      (detection_patterns)
--   4. Scam Knowledge Library  (scam_categories, scam_entries)
--   5. Educational Content     (articles, safety_tips)
--   6. Quizzes & Learning      (quizzes, quiz_questions, quiz_options,
--                               user_quiz_attempts, user_quiz_answers)
--   7. Safety Action Center    (safety_actions, reporting_resources)
--   8. Multilingual Support    (content_translations)
--
-- Also creates:
--   - 7 helper functions
--   - 1 security-barrier view (quiz_options_public)
--   - Triggers for auto-timestamps, profile creation, role protection,
--     quiz answer validation
--   - RLS policies on every table
--
-- SECURITY NOTES:
--   - All SECURITY DEFINER functions use SET search_path = '' to prevent
--     search_path injection attacks.
--   - Analysis results (risk_score, signals) can only be written by
--     service_role (server-side). Browser clients cannot fabricate scores.
--   - quiz_options.is_correct is hidden from browser clients via a
--     security-barrier view. Correct answers are computed by a database
--     trigger, never trusted from the client.
--   - detection_patterns are fully inaccessible to browser clients
--     (RLS + REVOKE).
--   - content_translations are only visible for published parent content.
--
-- IMPORTANT: Review all SECURITY DEFINER functions before executing.
-- ============================================================================


-- ============================================================================
-- SECTION 1: HELPER FUNCTIONS
-- ============================================================================

-- 1a. Auto-update the updated_at column on row modification.
--     Used as a BEFORE UPDATE trigger on tables with an updated_at column.
--     NOT SECURITY DEFINER: only modifies the row being updated.
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


-- 1b. Check if the current authenticated user has the 'admin' role.
--     SECURITY DEFINER with safe search_path.
--     Runs as function owner (postgres), bypassing RLS to prevent infinite
--     recursion when called inside RLS policies on user_profiles.
--     The role check is always against the DATABASE, not a client-provided value.
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_profiles
    WHERE id = auth.uid()
      AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = '';


-- 1c. Auto-create a user_profiles row when a new auth.users row is inserted.
--     SECURITY DEFINER with safe search_path.
--     Needs permission to INSERT into user_profiles regardless of calling context.
--     Always creates profiles with role='user' — never 'admin'.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_profiles (id)
  VALUES (NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';


-- 1d. Prevent non-admin users from changing the role column.
--     SECURITY DEFINER with safe search_path.
--     Provides defense-in-depth: even if RLS allows UPDATE on the row,
--     only database-verified admins can change the role column.
CREATE OR REPLACE FUNCTION public.prevent_role_change()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.role IS DISTINCT FROM OLD.role AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Only administrators can change user roles';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';


-- 1e. Validate quiz answer integrity and compute is_correct from the database.
--     SECURITY DEFINER with safe search_path.
--     Enforces:
--       - The attempt is not already completed
--       - The question belongs to the quiz being attempted
--       - The selected option belongs to the specified question
--       - is_correct is ALWAYS set from quiz_options, never from client input
--     This function reads quiz_options.is_correct which is hidden from browser
--     clients, so SECURITY DEFINER is required.
CREATE OR REPLACE FUNCTION public.validate_and_score_quiz_answer()
RETURNS TRIGGER AS $$
DECLARE
  v_attempt_quiz_id UUID;
  v_attempt_completed TIMESTAMPTZ;
  v_question_quiz_id UUID;
  v_option_question_id UUID;
  v_is_correct BOOLEAN;
BEGIN
  -- 1. Verify the attempt exists and is not completed
  SELECT quiz_id, completed_at
  INTO v_attempt_quiz_id, v_attempt_completed
  FROM public.user_quiz_attempts
  WHERE id = NEW.attempt_id;

  IF v_attempt_quiz_id IS NULL THEN
    RAISE EXCEPTION 'Quiz attempt not found';
  END IF;

  IF v_attempt_completed IS NOT NULL THEN
    RAISE EXCEPTION 'Cannot add answers to a completed quiz attempt';
  END IF;

  -- 2. Verify the question belongs to this attempt's quiz
  SELECT quiz_id INTO v_question_quiz_id
  FROM public.quiz_questions
  WHERE id = NEW.question_id;

  IF v_question_quiz_id IS NULL THEN
    RAISE EXCEPTION 'Question not found';
  END IF;

  IF v_question_quiz_id IS DISTINCT FROM v_attempt_quiz_id THEN
    RAISE EXCEPTION 'Question does not belong to the quiz being attempted';
  END IF;

  -- 3. Verify the selected option belongs to the specified question
  SELECT question_id, is_correct
  INTO v_option_question_id, v_is_correct
  FROM public.quiz_options
  WHERE id = NEW.selected_option_id;

  IF v_option_question_id IS NULL THEN
    RAISE EXCEPTION 'Selected option not found';
  END IF;

  IF v_option_question_id IS DISTINCT FROM NEW.question_id THEN
    RAISE EXCEPTION 'Selected option does not belong to the specified question';
  END IF;

  -- 4. Override client-provided is_correct with authoritative database value
  NEW.is_correct = v_is_correct;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';


-- 1f. Finalize a quiz attempt: compute score and pass status server-side.
--     SECURITY DEFINER with safe search_path.
--     Callable via Supabase RPC by authenticated users for their own attempts.
--     Score = (correct answers / total questions in quiz) * 100
--     Unanswered questions count against the score.
CREATE OR REPLACE FUNCTION public.finalize_quiz_attempt(p_attempt_id UUID)
RETURNS void AS $$
DECLARE
  v_attempt RECORD;
  v_total_questions INT;
  v_correct_answers INT;
  v_score SMALLINT;
  v_passing_score SMALLINT;
BEGIN
  -- Fetch the attempt and verify ownership
  SELECT user_id, quiz_id, completed_at
  INTO v_attempt
  FROM public.user_quiz_attempts
  WHERE id = p_attempt_id;

  IF v_attempt IS NULL THEN
    RAISE EXCEPTION 'Quiz attempt not found';
  END IF;

  IF v_attempt.completed_at IS NOT NULL THEN
    RAISE EXCEPTION 'Quiz attempt is already completed';
  END IF;

  -- Only the owning user (or an admin) can finalize
  IF v_attempt.user_id IS DISTINCT FROM auth.uid() AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Not authorized to finalize this attempt';
  END IF;

  -- Count total questions in the quiz (not just answered ones)
  SELECT COUNT(*) INTO v_total_questions
  FROM public.quiz_questions
  WHERE quiz_id = v_attempt.quiz_id;

  IF v_total_questions = 0 THEN
    RAISE EXCEPTION 'Quiz has no questions';
  END IF;

  -- Count correct answers from the authoritative is_correct column
  SELECT COUNT(*) FILTER (WHERE is_correct) INTO v_correct_answers
  FROM public.user_quiz_answers
  WHERE attempt_id = p_attempt_id;

  -- Calculate percentage score
  v_score = ROUND((v_correct_answers::NUMERIC / v_total_questions) * 100)::SMALLINT;

  -- Get passing score threshold from the quiz
  SELECT passing_score INTO v_passing_score
  FROM public.quizzes
  WHERE id = v_attempt.quiz_id;

  -- Finalize the attempt (bypasses RLS via SECURITY DEFINER)
  UPDATE public.user_quiz_attempts
  SET score = v_score,
      passed = (v_score >= v_passing_score),
      completed_at = now()
  WHERE id = p_attempt_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';


-- 1g. Check if a polymorphically-referenced content record is published.
--     SECURITY DEFINER with safe search_path.
--     Used in content_translations RLS to restrict public access to
--     translations of published content only.
--     For quiz_questions/quiz_options, checks parent quiz status.
CREATE OR REPLACE FUNCTION public.is_content_published(
  p_table_name TEXT,
  p_record_id UUID
)
RETURNS BOOLEAN AS $$
DECLARE
  v_status TEXT;
BEGIN
  CASE p_table_name
    WHEN 'scam_categories' THEN
      SELECT status INTO v_status
      FROM public.scam_categories WHERE id = p_record_id;
    WHEN 'scam_entries' THEN
      SELECT status INTO v_status
      FROM public.scam_entries WHERE id = p_record_id;
    WHEN 'articles' THEN
      SELECT status INTO v_status
      FROM public.articles WHERE id = p_record_id;
    WHEN 'safety_tips' THEN
      SELECT status INTO v_status
      FROM public.safety_tips WHERE id = p_record_id;
    WHEN 'quizzes' THEN
      SELECT status INTO v_status
      FROM public.quizzes WHERE id = p_record_id;
    WHEN 'quiz_questions' THEN
      SELECT q.status INTO v_status
      FROM public.quiz_questions qq
      JOIN public.quizzes q ON q.id = qq.quiz_id
      WHERE qq.id = p_record_id;
    WHEN 'quiz_options' THEN
      SELECT q.status INTO v_status
      FROM public.quiz_options qo
      JOIN public.quiz_questions qq ON qq.id = qo.question_id
      JOIN public.quizzes q ON q.id = qq.quiz_id
      WHERE qo.id = p_record_id;
    WHEN 'safety_actions' THEN
      SELECT status INTO v_status
      FROM public.safety_actions WHERE id = p_record_id;
    WHEN 'reporting_resources' THEN
      SELECT status INTO v_status
      FROM public.reporting_resources WHERE id = p_record_id;
    ELSE
      RETURN false;
  END CASE;

  RETURN COALESCE(v_status = 'published', false);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = '';


-- ============================================================================
-- SECTION 2: TABLES, INDEXES, AND TRIGGERS
-- ============================================================================

-- --------------------------------------------------------------------------
-- Domain 1: User Profiles
-- --------------------------------------------------------------------------

CREATE TABLE public.user_profiles (
  id                 UUID PRIMARY KEY
                       REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name       TEXT,
  preferred_language TEXT NOT NULL DEFAULT 'en'
                       CHECK (preferred_language ~ '^[a-z]{2}$'),
  role               TEXT NOT NULL DEFAULT 'user'
                       CHECK (role IN ('user', 'admin', 'moderator')),
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_user_profiles_role
  ON public.user_profiles (role);

CREATE TRIGGER tr_user_profiles_updated_at
  BEFORE UPDATE ON public.user_profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER tr_user_profiles_prevent_role_change
  BEFORE UPDATE ON public.user_profiles
  FOR EACH ROW EXECUTE FUNCTION public.prevent_role_change();

-- Auto-create profile when a new user signs up via Supabase Auth
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


-- --------------------------------------------------------------------------
-- Domain 2: Analysis Engine
-- --------------------------------------------------------------------------
-- SECURITY: analysis_sessions and analysis_signals are ONLY writable by
-- service_role (server-side API routes). Browser clients can read their own
-- results but cannot fabricate risk scores, risk levels, or signals.

CREATE TABLE public.analysis_sessions (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  analysis_type  TEXT NOT NULL
                   CHECK (analysis_type IN ('message', 'url', 'screenshot')),
  input_hash     TEXT NOT NULL,
  input_preview  TEXT,
  risk_score     SMALLINT NOT NULL
                   CHECK (risk_score BETWEEN 0 AND 100),
  risk_level     TEXT NOT NULL
                   CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
  signals_count  SMALLINT NOT NULL DEFAULT 0,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at     TIMESTAMPTZ
);

CREATE INDEX idx_analysis_sessions_user_id
  ON public.analysis_sessions (user_id)
  WHERE user_id IS NOT NULL;

CREATE INDEX idx_analysis_sessions_created_at
  ON public.analysis_sessions (created_at DESC);

CREATE INDEX idx_analysis_sessions_expires
  ON public.analysis_sessions (expires_at)
  WHERE expires_at IS NOT NULL;


CREATE TABLE public.analysis_signals (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id         UUID NOT NULL
                       REFERENCES public.analysis_sessions(id) ON DELETE CASCADE,
  signal_category    TEXT NOT NULL,
  signal_name        TEXT NOT NULL,
  severity           TEXT NOT NULL
                       CHECK (severity IN ('info', 'low', 'medium', 'high', 'critical')),
  description        TEXT NOT NULL,
  matched_snippet    TEXT,
  recommended_action TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_analysis_signals_session_id
  ON public.analysis_signals (session_id);


-- --------------------------------------------------------------------------
-- Domain 3: Detection Patterns (Admin-Only, Server-Side)
-- --------------------------------------------------------------------------

CREATE TABLE public.detection_patterns (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pattern_type   TEXT NOT NULL
                   CHECK (pattern_type IN ('keyword', 'phrase', 'regex', 'domain', 'url_pattern')),
  pattern_value  TEXT NOT NULL,
  category       TEXT NOT NULL,
  severity       TEXT NOT NULL DEFAULT 'medium'
                   CHECK (severity IN ('info', 'low', 'medium', 'high', 'critical')),
  signal_name    TEXT NOT NULL,
  description    TEXT NOT NULL,
  is_active      BOOLEAN NOT NULL DEFAULT true,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (pattern_type, pattern_value)
);

CREATE INDEX idx_detection_patterns_active
  ON public.detection_patterns (category, pattern_type)
  WHERE is_active = true;

CREATE TRIGGER tr_detection_patterns_updated_at
  BEFORE UPDATE ON public.detection_patterns
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


-- --------------------------------------------------------------------------
-- Domain 4: Scam Knowledge Library
-- --------------------------------------------------------------------------

CREATE TABLE public.scam_categories (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug           TEXT NOT NULL UNIQUE,
  name           TEXT NOT NULL,
  description    TEXT NOT NULL,
  icon_name      TEXT,
  display_order  SMALLINT NOT NULL DEFAULT 0,
  status         TEXT NOT NULL DEFAULT 'draft'
                   CHECK (status IN ('draft', 'published', 'archived')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_scam_categories_status
  ON public.scam_categories (status, display_order);

CREATE TRIGGER tr_scam_categories_updated_at
  BEFORE UPDATE ON public.scam_categories
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


CREATE TABLE public.scam_entries (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id         UUID NOT NULL
                        REFERENCES public.scam_categories(id) ON DELETE CASCADE,
  title               TEXT NOT NULL,
  description         TEXT NOT NULL,
  warning_signs       JSONB NOT NULL DEFAULT '[]',
  examples            JSONB NOT NULL DEFAULT '[]',
  prevention_guidance TEXT NOT NULL,
  response_guidance   TEXT,
  severity            TEXT NOT NULL DEFAULT 'medium'
                        CHECK (severity IN ('info', 'low', 'medium', 'high', 'critical')),
  status              TEXT NOT NULL DEFAULT 'draft'
                        CHECK (status IN ('draft', 'published', 'archived')),
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_scam_entries_category
  ON public.scam_entries (category_id, status);

CREATE TRIGGER tr_scam_entries_updated_at
  BEFORE UPDATE ON public.scam_entries
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


-- --------------------------------------------------------------------------
-- Domain 5: Educational Content
-- --------------------------------------------------------------------------

CREATE TABLE public.articles (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug         TEXT NOT NULL UNIQUE,
  title        TEXT NOT NULL,
  summary      TEXT NOT NULL,
  content      TEXT NOT NULL,
  category     TEXT NOT NULL,
  author_id    UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  status       TEXT NOT NULL DEFAULT 'draft'
                 CHECK (status IN ('draft', 'published', 'archived')),
  published_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_articles_category_status
  ON public.articles (category, status);

CREATE INDEX idx_articles_published
  ON public.articles (published_at DESC)
  WHERE status = 'published';

CREATE TRIGGER tr_articles_updated_at
  BEFORE UPDATE ON public.articles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


CREATE TABLE public.safety_tips (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title         TEXT NOT NULL,
  content       TEXT NOT NULL,
  category      TEXT NOT NULL,
  display_order SMALLINT NOT NULL DEFAULT 0,
  status        TEXT NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft', 'published', 'archived')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_safety_tips_category_status
  ON public.safety_tips (category, status, display_order);

CREATE TRIGGER tr_safety_tips_updated_at
  BEFORE UPDATE ON public.safety_tips
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


-- --------------------------------------------------------------------------
-- Domain 6: Quizzes & Learning Progress
-- --------------------------------------------------------------------------

CREATE TABLE public.quizzes (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug          TEXT NOT NULL UNIQUE,
  title         TEXT NOT NULL,
  description   TEXT NOT NULL,
  category      TEXT NOT NULL,
  difficulty    TEXT NOT NULL DEFAULT 'beginner'
                  CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
  passing_score SMALLINT NOT NULL DEFAULT 70,
  status        TEXT NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft', 'published', 'archived')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_quizzes_category_status
  ON public.quizzes (category, status);

CREATE TRIGGER tr_quizzes_updated_at
  BEFORE UPDATE ON public.quizzes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


CREATE TABLE public.quiz_questions (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id        UUID NOT NULL
                   REFERENCES public.quizzes(id) ON DELETE CASCADE,
  question_text  TEXT NOT NULL,
  explanation    TEXT NOT NULL,
  question_order SMALLINT NOT NULL DEFAULT 0,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_quiz_questions_quiz
  ON public.quiz_questions (quiz_id, question_order);

CREATE TRIGGER tr_quiz_questions_updated_at
  BEFORE UPDATE ON public.quiz_questions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


CREATE TABLE public.quiz_options (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id  UUID NOT NULL
                 REFERENCES public.quiz_questions(id) ON DELETE CASCADE,
  option_text  TEXT NOT NULL,
  is_correct   BOOLEAN NOT NULL DEFAULT false,
  option_order SMALLINT NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_quiz_options_question
  ON public.quiz_options (question_id, option_order);


-- HARDENED: score and passed are NULLABLE. They start as NULL when a user
-- begins a quiz and are computed server-side by finalize_quiz_attempt().
-- Browser clients cannot set these values directly.
CREATE TABLE public.user_quiz_attempts (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL
                 REFERENCES auth.users(id) ON DELETE CASCADE,
  quiz_id      UUID NOT NULL
                 REFERENCES public.quizzes(id) ON DELETE CASCADE,
  score        SMALLINT,
  passed       BOOLEAN,
  completed_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_user_quiz_attempts_user
  ON public.user_quiz_attempts (user_id, created_at DESC);

CREATE INDEX idx_user_quiz_attempts_quiz
  ON public.user_quiz_attempts (quiz_id);


-- HARDENED: is_correct defaults to false but is ALWAYS overridden by the
-- validate_and_score_quiz_answer trigger. The client value is never trusted.
CREATE TABLE public.user_quiz_answers (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id         UUID NOT NULL
                       REFERENCES public.user_quiz_attempts(id) ON DELETE CASCADE,
  question_id        UUID NOT NULL
                       REFERENCES public.quiz_questions(id) ON DELETE CASCADE,
  selected_option_id UUID NOT NULL
                       REFERENCES public.quiz_options(id) ON DELETE CASCADE,
  is_correct         BOOLEAN NOT NULL DEFAULT false,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (attempt_id, question_id)
);

-- Trigger: validate answer integrity and compute is_correct from database
CREATE TRIGGER tr_validate_quiz_answer
  BEFORE INSERT ON public.user_quiz_answers
  FOR EACH ROW EXECUTE FUNCTION public.validate_and_score_quiz_answer();


-- --------------------------------------------------------------------------
-- Domain 7: Safety Action Center
-- --------------------------------------------------------------------------

CREATE TABLE public.safety_actions (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title          TEXT NOT NULL,
  scenario       TEXT NOT NULL,
  guidance_steps JSONB NOT NULL DEFAULT '[]',
  severity       TEXT NOT NULL DEFAULT 'medium'
                   CHECK (severity IN ('info', 'low', 'medium', 'high', 'critical')),
  category       TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'draft'
                   CHECK (status IN ('draft', 'published', 'archived')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_safety_actions_category_status
  ON public.safety_actions (category, status);

CREATE TRIGGER tr_safety_actions_updated_at
  BEFORE UPDATE ON public.safety_actions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


CREATE TABLE public.reporting_resources (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  description   TEXT NOT NULL,
  contact_info  TEXT NOT NULL,
  resource_type TEXT NOT NULL
                  CHECK (resource_type IN ('helpline', 'website', 'authority', 'app')),
  region        TEXT NOT NULL DEFAULT 'IN',
  display_order SMALLINT NOT NULL DEFAULT 0,
  status        TEXT NOT NULL DEFAULT 'published'
                  CHECK (status IN ('draft', 'published', 'archived')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_reporting_resources_type_region
  ON public.reporting_resources (resource_type, region, status);

CREATE TRIGGER tr_reporting_resources_updated_at
  BEFORE UPDATE ON public.reporting_resources
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


-- --------------------------------------------------------------------------
-- Domain 8: Multilingual Support
-- --------------------------------------------------------------------------
-- table_name + record_id is a polymorphic reference. PostgreSQL foreign keys
-- cannot enforce referential integrity across multiple target tables.
-- Integrity is maintained at the application layer. Orphaned translations
-- are harmless and can be cleaned up periodically.
--
-- HARDENED: table_name is restricted via CHECK to known content tables only.
-- Public visibility is governed by is_content_published(), which checks the
-- parent record's publication status.

CREATE TABLE public.content_translations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  table_name      TEXT NOT NULL
                    CHECK (table_name IN (
                      'scam_categories', 'scam_entries', 'articles', 'safety_tips',
                      'quizzes', 'quiz_questions', 'quiz_options',
                      'safety_actions', 'reporting_resources'
                    )),
  record_id       UUID NOT NULL,
  language_code   TEXT NOT NULL
                    CHECK (language_code ~ '^[a-z]{2}$'),
  field_name      TEXT NOT NULL,
  translated_text TEXT NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (table_name, record_id, language_code, field_name)
);

CREATE TRIGGER tr_content_translations_updated_at
  BEFORE UPDATE ON public.content_translations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


-- ============================================================================
-- SECTION 3: SECURITY-BARRIER VIEW
-- ============================================================================
-- quiz_options_public exposes quiz option data WITHOUT the is_correct column.
-- security_barrier = true prevents the query optimizer from pushing
-- user-supplied predicates below the view's WHERE clause, blocking
-- information leaks via timing or error side-channels.
-- Only shows options for published quizzes.

CREATE VIEW public.quiz_options_public
WITH (security_barrier = true) AS
SELECT
  qo.id,
  qo.question_id,
  qo.option_text,
  qo.option_order,
  qo.created_at
FROM public.quiz_options qo
JOIN public.quiz_questions qq ON qq.id = qo.question_id
JOIN public.quizzes q ON q.id = qq.quiz_id
WHERE q.status = 'published';


-- ============================================================================
-- SECTION 4: ENABLE ROW LEVEL SECURITY ON ALL TABLES
-- ============================================================================

ALTER TABLE public.user_profiles        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analysis_sessions    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analysis_signals     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.detection_patterns   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scam_categories      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scam_entries         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.articles             ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.safety_tips          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quizzes              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_questions       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_options         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_quiz_attempts   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_quiz_answers    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.safety_actions       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reporting_resources  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_translations ENABLE ROW LEVEL SECURITY;


-- ============================================================================
-- SECTION 5: REVOKE / GRANT
-- ============================================================================

-- detection_patterns: fully inaccessible to browser clients.
-- RLS with no policies already blocks access; REVOKE provides defense-in-depth.
REVOKE ALL ON public.detection_patterns FROM anon, authenticated;

-- quiz_options: two-step privilege setup.
-- 1. REVOKE ALL removes default privileges from both anon and authenticated.
-- 2. GRANT CRUD back to authenticated ONLY — required because RLS policies
--    do not grant table-level privileges. Without this GRANT, even an
--    authenticated admin would be blocked at the privilege layer before
--    RLS policies are ever evaluated.
-- Net effect:
--   anon          → no table privileges → completely blocked
--   authenticated → has table privileges → but RLS restricts to admin-only
--   public users  → read via quiz_options_public view (no is_correct)
REVOKE ALL ON public.quiz_options FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.quiz_options TO authenticated;

-- analysis_sessions & analysis_signals: block INSERT/UPDATE/DELETE from browser.
-- Only service_role (server-side) can write analysis results.
-- SELECT is controlled by RLS policies below.
REVOKE INSERT, UPDATE, DELETE ON public.analysis_sessions FROM anon, authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.analysis_signals FROM anon, authenticated;

-- Grant public read access to the safe quiz options view
GRANT SELECT ON public.quiz_options_public TO anon, authenticated;

-- Grant execute on finalize_quiz_attempt only to authenticated users
REVOKE EXECUTE ON FUNCTION public.finalize_quiz_attempt(UUID) FROM anon;
GRANT EXECUTE ON FUNCTION public.finalize_quiz_attempt(UUID) TO authenticated;


-- ============================================================================
-- SECTION 6: ROW LEVEL SECURITY POLICIES
-- ============================================================================

-- --------------------------------------------------------------------------
-- user_profiles
-- --------------------------------------------------------------------------

-- Users can read their own profile
CREATE POLICY "Users can read own profile"
  ON public.user_profiles FOR SELECT
  TO authenticated
  USING (id = auth.uid());

-- Admins can read all profiles
CREATE POLICY "Admins can read all profiles"
  ON public.user_profiles FOR SELECT
  TO authenticated
  USING (public.is_admin());

-- Users can update their own profile (role change blocked by trigger)
CREATE POLICY "Users can update own profile"
  ON public.user_profiles FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- No client-side INSERT policy: profiles are created by the
-- handle_new_user trigger (SECURITY DEFINER), which bypasses RLS.

-- No client-side DELETE policy: profiles are cascade-deleted
-- when the auth.users row is removed.


-- --------------------------------------------------------------------------
-- analysis_sessions
-- --------------------------------------------------------------------------
-- HARDENED: No INSERT/UPDATE/DELETE policies for anon or authenticated.
-- All writes go through server-side API routes using service_role,
-- which bypasses RLS. This prevents browser clients from fabricating
-- risk_score, risk_level, signals_count, or any analysis results.

-- Authenticated users can read their own analysis history
CREATE POLICY "Users can read own analysis sessions"
  ON public.analysis_sessions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Admins can read all sessions (for moderation/analytics)
CREATE POLICY "Admins can read all analysis sessions"
  ON public.analysis_sessions FOR SELECT
  TO authenticated
  USING (public.is_admin());

-- No INSERT policies: service_role only (bypasses RLS).
-- No UPDATE policies: service_role only.
-- No DELETE policies: service_role only.


-- --------------------------------------------------------------------------
-- analysis_signals
-- --------------------------------------------------------------------------
-- HARDENED: No INSERT/UPDATE/DELETE policies. Server-side only.

-- Authenticated users can read signals from their own sessions
CREATE POLICY "Users can read signals from own sessions"
  ON public.analysis_signals FOR SELECT
  TO authenticated
  USING (
    session_id IN (
      SELECT id FROM public.analysis_sessions
      WHERE user_id = auth.uid()
    )
  );

-- Admins can read all signals
CREATE POLICY "Admins can read all signals"
  ON public.analysis_signals FOR SELECT
  TO authenticated
  USING (public.is_admin());

-- No INSERT policies: service_role only.
-- No UPDATE policies: service_role only.
-- No DELETE policies: service_role only.


-- --------------------------------------------------------------------------
-- detection_patterns (NO policies — server-only via service_role)
-- --------------------------------------------------------------------------
-- Intentionally empty. Only service_role (which bypasses RLS) can access
-- this table. All reads happen in server-side API routes. Admin management
-- also goes through server-side routes using the service_role client.
-- Table-level REVOKE above provides an additional layer of defense.


-- --------------------------------------------------------------------------
-- Public content tables: scam_categories, scam_entries, articles,
-- safety_tips, quizzes, quiz_questions, safety_actions,
-- reporting_resources
--
-- Pattern: Everyone can read published content. Admins can manage all.
-- --------------------------------------------------------------------------

-- ---- scam_categories ----

CREATE POLICY "Anyone can read published scam categories"
  ON public.scam_categories FOR SELECT
  TO anon, authenticated
  USING (status = 'published');

CREATE POLICY "Admins can read all scam categories"
  ON public.scam_categories FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert scam categories"
  ON public.scam_categories FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update scam categories"
  ON public.scam_categories FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete scam categories"
  ON public.scam_categories FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- ---- scam_entries ----

CREATE POLICY "Anyone can read published scam entries"
  ON public.scam_entries FOR SELECT
  TO anon, authenticated
  USING (status = 'published');

CREATE POLICY "Admins can read all scam entries"
  ON public.scam_entries FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert scam entries"
  ON public.scam_entries FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update scam entries"
  ON public.scam_entries FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete scam entries"
  ON public.scam_entries FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- ---- articles ----

CREATE POLICY "Anyone can read published articles"
  ON public.articles FOR SELECT
  TO anon, authenticated
  USING (status = 'published');

CREATE POLICY "Admins can read all articles"
  ON public.articles FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert articles"
  ON public.articles FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update articles"
  ON public.articles FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete articles"
  ON public.articles FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- ---- safety_tips ----

CREATE POLICY "Anyone can read published safety tips"
  ON public.safety_tips FOR SELECT
  TO anon, authenticated
  USING (status = 'published');

CREATE POLICY "Admins can read all safety tips"
  ON public.safety_tips FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert safety tips"
  ON public.safety_tips FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update safety tips"
  ON public.safety_tips FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete safety tips"
  ON public.safety_tips FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- ---- quizzes ----

CREATE POLICY "Anyone can read published quizzes"
  ON public.quizzes FOR SELECT
  TO anon, authenticated
  USING (status = 'published');

CREATE POLICY "Admins can read all quizzes"
  ON public.quizzes FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert quizzes"
  ON public.quizzes FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update quizzes"
  ON public.quizzes FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete quizzes"
  ON public.quizzes FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- ---- quiz_questions ----

CREATE POLICY "Anyone can read questions of published quizzes"
  ON public.quiz_questions FOR SELECT
  TO anon, authenticated
  USING (
    quiz_id IN (
      SELECT id FROM public.quizzes WHERE status = 'published'
    )
  );

CREATE POLICY "Admins can read all quiz questions"
  ON public.quiz_questions FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert quiz questions"
  ON public.quiz_questions FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update quiz questions"
  ON public.quiz_questions FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete quiz questions"
  ON public.quiz_questions FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- ---- quiz_options (admin-only direct access) ----
-- HARDENED: No public SELECT policy on the underlying table.
-- Public users access quiz_options_public (view) instead,
-- which excludes the is_correct column.
-- Table-level REVOKE above blocks anon/authenticated entirely;
-- only admin RLS policies grant authenticated admin access.

CREATE POLICY "Admins can read all quiz options"
  ON public.quiz_options FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert quiz options"
  ON public.quiz_options FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update quiz options"
  ON public.quiz_options FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete quiz options"
  ON public.quiz_options FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- ---- safety_actions ----

CREATE POLICY "Anyone can read published safety actions"
  ON public.safety_actions FOR SELECT
  TO anon, authenticated
  USING (status = 'published');

CREATE POLICY "Admins can read all safety actions"
  ON public.safety_actions FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert safety actions"
  ON public.safety_actions FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update safety actions"
  ON public.safety_actions FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete safety actions"
  ON public.safety_actions FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- ---- reporting_resources ----

CREATE POLICY "Anyone can read published reporting resources"
  ON public.reporting_resources FOR SELECT
  TO anon, authenticated
  USING (status = 'published');

CREATE POLICY "Admins can read all reporting resources"
  ON public.reporting_resources FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert reporting resources"
  ON public.reporting_resources FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update reporting resources"
  ON public.reporting_resources FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete reporting resources"
  ON public.reporting_resources FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- --------------------------------------------------------------------------
-- content_translations
-- --------------------------------------------------------------------------
-- HARDENED: Public users can only read translations for PUBLISHED content.
-- is_content_published() checks the parent record's status via a CASE
-- statement over known table names.

CREATE POLICY "Anyone can read translations of published content"
  ON public.content_translations FOR SELECT
  TO anon, authenticated
  USING (public.is_content_published(table_name, record_id));

-- Admins can read all translations (including draft/archived)
CREATE POLICY "Admins can read all translations"
  ON public.content_translations FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Admins can insert content translations"
  ON public.content_translations FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update content translations"
  ON public.content_translations FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY "Admins can delete content translations"
  ON public.content_translations FOR DELETE
  TO authenticated
  USING (public.is_admin());


-- --------------------------------------------------------------------------
-- User-owned learning tables: user_quiz_attempts, user_quiz_answers
-- --------------------------------------------------------------------------

-- ---- user_quiz_attempts ----
-- HARDENED: INSERT enforces that score, passed, and completed_at are all NULL.
-- These fields are computed server-side by finalize_quiz_attempt().
-- No UPDATE policy: only finalize_quiz_attempt (SECURITY DEFINER) can update.

CREATE POLICY "Users can read own quiz attempts"
  ON public.user_quiz_attempts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can read all quiz attempts"
  ON public.user_quiz_attempts FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Users can create own quiz attempts"
  ON public.user_quiz_attempts FOR INSERT
  TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND score IS NULL
    AND passed IS NULL
    AND completed_at IS NULL
  );

-- No UPDATE policy: score/passed/completed_at are set exclusively by
-- finalize_quiz_attempt() which runs as SECURITY DEFINER.

-- No DELETE policy: cascade from auth.users handles cleanup.


-- ---- user_quiz_answers ----
-- HARDENED: INSERT only allowed for own incomplete attempts.
-- The validate_and_score_quiz_answer trigger provides additional
-- defense-in-depth by verifying question/option relationships
-- and computing is_correct from the database.

CREATE POLICY "Users can read own quiz answers"
  ON public.user_quiz_answers FOR SELECT
  TO authenticated
  USING (
    attempt_id IN (
      SELECT id FROM public.user_quiz_attempts
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can read all quiz answers"
  ON public.user_quiz_answers FOR SELECT
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Users can create answers for own incomplete attempts"
  ON public.user_quiz_answers FOR INSERT
  TO authenticated
  WITH CHECK (
    attempt_id IN (
      SELECT id FROM public.user_quiz_attempts
      WHERE user_id = auth.uid()
        AND completed_at IS NULL
    )
  );

-- No UPDATE policy: answers cannot be changed after submission.
-- No DELETE policy: cascade from user_quiz_attempts handles cleanup.


-- ============================================================================
-- END OF MIGRATION
-- ============================================================================
