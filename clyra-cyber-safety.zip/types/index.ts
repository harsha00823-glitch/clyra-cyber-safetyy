// Core TypeScript definitions for Cyber Safety Platform

export * from './analysis';

export interface NavItem {
  label: string;
  href: string;
}

export interface UserProfile {
  id: string;
  display_name: string | null;
  preferred_language: string;
  role: 'user' | 'admin' | 'moderator';
  created_at: string;
  updated_at: string;
}

export interface ScamCategory {
  id: string;
  slug: string;
  name: string;
  description: string;
  icon_name?: string | null;
  display_order: number;
  status: 'draft' | 'published' | 'archived';
  created_at: string;
  updated_at: string;
}

export interface ScamEntry {
  id: string;
  category_id: string;
  title: string;
  description: string;
  warning_signs: string[];
  example_scenario: string;
  prevention_steps: string[];
  response_steps: string[];
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'draft' | 'published' | 'archived';
  created_at: string;
  updated_at: string;
}

export interface SafetyTip {
  id: string;
  title: string;
  tip_text: string;
  category: string;
  display_order: number;
  status: 'draft' | 'published' | 'archived';
}

export interface ReportingResource {
  id: string;
  name: string;
  description: string;
  contact_info: string;
  resource_type: 'helpline' | 'website' | 'authority' | 'app';
  region: string;
  display_order: number;
  status: 'draft' | 'published' | 'archived';
}

export interface Quiz {
  id: string;
  slug: string;
  title: string;
  description: string;
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  passing_score: number;
  display_order: number;
  status: 'draft' | 'published' | 'archived';
}

export interface QuizQuestion {
  id: string;
  quiz_id: string;
  question_text: string;
  explanation: string;
  question_order: number;
}

export interface QuizOptionPublic {
  id: string;
  question_id: string;
  option_text: string;
  option_order: number;
  created_at: string;
}
