// Analysis Engine TypeScript definitions for Cyber Safety Platform

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

export type SignalSeverity = 'info' | 'low' | 'medium' | 'high' | 'critical';

export type SignalCategory =
  | 'phishing'
  | 'keywords'
  | 'urgency'
  | 'threat_coercion'
  | 'authority_impersonation'
  | 'financial'
  | 'credentials'
  | 'malicious_app'
  | 'url_structure'
  | 'domain_reputation'
  | 'technical';

export interface DetectionSignal {
  id: string;
  name: string;
  category: SignalCategory;
  severity: SignalSeverity;
  explanation: string;
  recommendedAction: string;
  matchedSnippet?: string;
  weight: number;
}

export interface AnalysisResult {
  id?: string;
  score: number; // 0 - 100
  level: RiskLevel;
  summary: string;
  disclaimer: string;
  signals: DetectionSignal[];
  analysisType: 'message' | 'url' | 'screenshot';
  inputPreview: string;
  timestamp: string;
  investigationDetails?: Record<string, unknown>;
}

export interface URLInvestigation {
  originalUrl: string;
  protocol: string;
  hostname: string;
  pathname: string;
  queryParams: Record<string, string>;
  isHttps: boolean;
  isIpAddress: boolean;
  subdomainCount: number;
  subdomains: string[];
  domain: string;
  tld: string;
  isShortener: boolean;
  hasPunycode: boolean;
  hasSuspiciousKeywords: boolean;
  pathDepth: number;
  advancedLookupStatus: 'not_configured' | 'configured';
  advancedLookupMessage: string;
}

export interface IncidentReportData {
  id?: string;
  incidentType: string;
  targetContent: string;
  platform: string;
  dateTime: string;
  riskScore?: number;
  riskLevel?: RiskLevel;
  detectedSignals?: string[];
  userDescription: string;
  financialLossReported: boolean;
  lossAmount?: string;
  suspectContact?: string;
  recommendedActions: string[];
}
