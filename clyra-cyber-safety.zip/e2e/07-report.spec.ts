import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener } from './helpers';

test.describe('CLYRA Incident Report Wizard', () => {
  test('should complete 3-step incident summary and provide official portal submission link', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/report');

    // 1. Verify Step 1: Incident Details Form
    await expect(page.getByRole('heading', { name: /Tell your story/i })).toBeVisible();
    await expect(page.getByText(/1 · Incident details/i).first()).toBeVisible();

    // Verify form fields
    const narrativeTextarea = page.locator('textarea');
    await expect(narrativeTextarea).toBeVisible();

    // 2. Click "Review summary draft →"
    const nextBtn = page.getByRole('button', { name: /Review summary draft/i });
    await expect(nextBtn).toBeVisible();
    await nextBtn.click();

    // 3. Verify Step 2: Review & Export Dossier
    await expect(page.getByRole('heading', { name: /Personal Incident Dossier/i })).toBeVisible();

    // 4. Verify Export & Official Portal Actions
    const printBtn = page.getByRole('button', { name: /Export summary · PDF/i });
    await expect(printBtn).toBeVisible();

    const portalLink = page.getByRole('link', { name: /Open official reporting portal/i });
    await expect(portalLink).toBeVisible();
    await expect(portalLink).toHaveAttribute('href', 'https://cybercrime.gov.in');

    expect(consoleErrors).toHaveLength(0);
  });
});
