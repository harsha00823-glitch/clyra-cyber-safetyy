import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener, verifyNoBrokenImages } from './helpers';

const ROUTES = [
  '/',
  '/analyze',
  '/emergency',
  '/report',
  '/learn',
  '/digital-arrest',
  '/malicious-apps',
  '/community',
  '/quiz',
  '/privacy',
  '/auth/sign-in',
  '/auth/sign-up',
];

test.describe('CLYRA Resilience, Image Loading & Browser History', () => {
  for (const route of ROUTES) {
    test(`should load ${route} without console errors or broken images`, async ({ page }) => {
      const consoleErrors = setupConsoleErrorListener(page);
      const response = await page.goto(route);
      expect(response?.status()).toBeLessThan(400);

      await verifyNoBrokenImages(page);
      expect(consoleErrors).toHaveLength(0);
    });
  }

  test('should support browser back and forward history navigation without crash', async ({ page }) => {
    await page.goto('/');
    await page.goto('/analyze');
    await page.goto('/learn');

    // Go back to /analyze
    await page.goBack();
    await expect(page).toHaveURL(/\/analyze/);

    // Go back to /
    await page.goBack();
    await expect(page).toHaveURL('/');

    // Go forward to /analyze
    await page.goForward();
    await expect(page).toHaveURL(/\/analyze/);
  });
});
