import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener } from './helpers';

test.describe('CLYRA Smart Threat Analyzer Flow', () => {
  test('should analyze high-risk SMS text and display explainable signals', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/analyze');

    // 1. Check tab is on Message text
    const messageTab = page.getByRole('button', { name: /Message text/i });
    await expect(messageTab).toBeVisible();

    // 2. Fill suspicious message with KYC urgency, fake link, and OTP demand
    const textarea = page.locator('textarea#text-input');
    await expect(textarea).toBeVisible();
    await textarea.fill('URGENT: Your SBI account will be blocked today within 2 hours. Update KYC now at http://sbi-kyc-update.top and submit OTP.');

    // 3. Click Check button
    const checkBtn = page.getByRole('button', { name: /Check for warning signs/i });
    await expect(checkBtn).toBeVisible();
    await checkBtn.click();

    // 4. Verify Results
    await expect(page.getByRole('heading', { name: /This message shows high-risk warning signs/i })).toBeVisible({ timeout: 10000 });
    await expect(page.getByText(/High risk/i).first()).toBeVisible();

    // 5. Verify Warning Signs breakdown and What to do now
    await expect(page.getByText(/Why these are warning signs:/i)).toBeVisible();
    await expect(page.getByText(/What to do now:/i)).toBeVisible();

    // 6. Verify Action Buttons in result
    await expect(page.getByRole('link', { name: /Open my safety checklist/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /Prepare incident report/i })).toBeVisible();

    expect(consoleErrors).toHaveLength(0);
  });

  test('should analyze suspicious URL with domain scoring', async ({ page }) => {
    await page.goto('/analyze');

    // 1. Switch to URL tab
    const urlTab = page.getByRole('button', { name: /Website link/i });
    await expect(urlTab).toBeVisible();
    await urlTab.click();

    // 2. Fill suspicious URL
    const urlInput = page.locator('textarea#text-input');
    await expect(urlInput).toBeVisible();
    await urlInput.fill('http://192.168.1.1/secure-login-hdfc-kyc.apk');

    // 3. Click Check button
    const checkBtn = page.getByRole('button', { name: /Check for warning signs/i });
    await expect(checkBtn).toBeVisible();
    await checkBtn.click();

    // 4. Verify Results
    const resultPanel = page.locator('#analysis-result-panel');
    await expect(resultPanel).toBeVisible({ timeout: 10000 });
    await expect(resultPanel.getByText(/High risk/i).or(resultPanel.getByText(/Caution/i)).or(resultPanel.getByText(/Warning/i)).first()).toBeVisible();
  });

  test('should display on-device WebAssembly OCR privacy guarantee for Screenshot tab', async ({ page }) => {
    await page.goto('/analyze');

    // 1. Switch to Screenshot tab
    const screenshotTab = page.getByRole('button', { name: /Screenshot/i });
    await expect(screenshotTab).toBeVisible();
    await screenshotTab.click();

    // 2. Verify On-Device Privacy Guarantee Badge
    await expect(page.getByText(/100% On-Device Privacy/i)).toBeVisible();
    await expect(page.getByText(/WebAssembly/i)).toBeVisible();
    await expect(page.getByText(/Choose redacted image/i)).toBeVisible();
  });

  test('should disable analyze button on empty input', async ({ page }) => {
    await page.goto('/analyze');
    const textarea = page.locator('textarea#text-input');
    await textarea.fill('');

    const checkBtn = page.getByRole('button', { name: /Check for warning signs/i });
    await expect(checkBtn).toBeDisabled();
  });
});
