import { BrowserContext, Page, expect } from '@playwright/test';

/**
 * Authenticates the browser context by setting the demo session cookie.
 */
export async function authenticateDemoUser(context: BrowserContext, page?: Page) {
  await context.addCookies([
    {
      name: 'csp_demo_session',
      value: 'true',
      url: 'http://localhost:3000',
    },
    {
      name: 'csp_demo_session',
      value: 'true',
      domain: 'localhost',
      path: '/',
    },
  ]);
  if (page) {
    try {
      await page.request.post('http://localhost:3000/api/auth/demo-login');
    } catch {
      // Ignored if server not directly reachable via request context
    }
  }
}

/**
 * Clears authentication cookies.
 */
export async function clearAuthCookies(context: BrowserContext) {
  await context.clearCookies();
}

/**
 * Helper to monitor console errors and unhandled exceptions on a page.
 */
export function setupConsoleErrorListener(page: Page) {
  const errors: string[] = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      const text = msg.text();
      // Ignore normal browser font/analytics 404s
      if (!text.includes('favicon.ico') && !text.includes('404')) {
        errors.push(text);
      }
    }
  });
  page.on('pageerror', (err) => {
    errors.push(err.message);
  });
  return errors;
}

/**
 * Helper to verify that all visible images loaded successfully (naturalWidth > 0).
 */
export async function verifyNoBrokenImages(page: Page) {
  const images = page.locator('img');
  const count = await images.count();
  for (let i = 0; i < count; i++) {
    const img = images.nth(i);
    if (await img.isVisible()) {
      const naturalWidth = await img.evaluate((el: HTMLImageElement) => el.naturalWidth);
      expect(naturalWidth, `Image at index ${i} has naturalWidth > 0`).toBeGreaterThan(0);
    }
  }
}
