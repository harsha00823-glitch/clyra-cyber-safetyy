import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener } from './helpers';

test.describe('CLYRA Navigation & Layout', () => {
  test('should navigate across primary routes using responsive navigation (Desktop navbar or Mobile/Tablet drawer)', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/');

    const isDesktop = (page.viewportSize()?.width ?? 1280) >= 1024;

    // Helper to click navigation links depending on responsive layout
    const navigateTo = async (linkName: RegExp | string, expectedUrl: RegExp) => {
      if (!isDesktop) {
        const menuBtn = page.locator('button[aria-label="Toggle navigation"]');
        await menuBtn.click();
        await page.waitForTimeout(150);
      }
      
      const link = isDesktop
        ? page.locator('header nav').getByRole('link', { name: linkName }).first()
        : page.locator('header div.shadow-xl').getByRole('link', { name: linkName }).first();
      
      await link.click();
      await expect(page).toHaveURL(expectedUrl);
    };

    // 1. Check something -> /analyze
    await navigateTo(/Check something/i, /\/analyze/);
    await expect(page.getByRole('heading', { name: /Let’s check what you received/i })).toBeVisible();

    // 2. Emergency help -> /emergency
    await navigateTo(/Emergency help/i, /\/emergency/);
    await expect(page.getByRole('heading', { name: /Lost money\? Focus on these steps first/i })).toBeVisible();

    // 3. Prepare a report -> /report
    await navigateTo(/Prepare a report/i, /\/report/);
    await expect(page.getByRole('heading', { name: /Tell your story/i })).toBeVisible();

    // 4. Learn -> /learn
    await navigateTo(/^Learn$/i, /\/learn/);
    await expect(page.getByRole('heading', { name: /Confidence grows with a little practice\./i })).toBeVisible();

    // 5. Community -> /community
    await navigateTo(/Community/i, /\/community/);
    await expect(page.getByRole('heading', { name: /Ask a question/i })).toBeVisible();

    // 6. Sign In -> /auth/sign-in
    await navigateTo(/Sign In/i, /\/auth\/sign-in/);
    await expect(page.getByText(/Sign In to CLYRA/i)).toBeVisible();

    // 7. Logo Click -> Returns to Home
    await page.getByRole('link', { name: /cylra/i }).first().click();
    await expect(page).toHaveURL('/');

    expect(consoleErrors).toHaveLength(0);
  });

  test('should handle responsive menu toggling on mobile/tablet and desktop navbar layout on desktop', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/');

    const isDesktop = (page.viewportSize()?.width ?? 1280) >= 1024;

    if (!isDesktop) {
      // Mobile / Tablet: verify hamburger button can open and close the drawer
      const menuBtn = page.locator('button[aria-label="Toggle navigation"]');
      await expect(menuBtn).toBeVisible();

      // Open drawer
      await menuBtn.click();
      const drawer = page.locator('header div.shadow-xl');
      await expect(drawer).toBeVisible();
      await expect(drawer.getByRole('link', { name: /Check something/i })).toBeVisible();
      await expect(drawer.getByRole('link', { name: /Emergency help/i })).toBeVisible();
      await expect(drawer.getByRole('link', { name: /Protect yourself/i })).toBeVisible();
      await expect(drawer.getByRole('link', { name: /Learn/i })).toBeVisible();
      await expect(drawer.getByRole('link', { name: /Community/i })).toBeVisible();

      // Close drawer by clicking toggle button again
      await menuBtn.click();
      await expect(drawer).not.toBeVisible();
    } else {
      // Desktop: verify horizontal navbar links and tagline
      await expect(page.locator('header nav').getByRole('link', { name: /Check something/i })).toBeVisible();
      await expect(page.locator('header nav').getByRole('link', { name: /Emergency help/i })).toBeVisible();
      await expect(page.locator('header nav').getByRole('link', { name: /Prepare a report/i })).toBeVisible();
      await expect(page.locator('header nav').getByRole('link', { name: /^Learn$/i })).toBeVisible();
      await expect(page.locator('header nav').getByRole('link', { name: /Community/i })).toBeVisible();
      await expect(page.locator('header nav').getByRole('link', { name: /Sign In/i })).toBeVisible();
      await expect(page.locator('header nav').getByText('Detect. Understand. Protect', { exact: true })).toBeVisible();

      // Mobile toggle button should not be visible on desktop
      await expect(page.locator('button[aria-label="Toggle navigation"]')).not.toBeVisible();
    }

    expect(consoleErrors).toHaveLength(0);
  });

  test('should support language switcher interaction across responsive viewports', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/');

    const isDesktop = (page.viewportSize()?.width ?? 1280) >= 1024;

    if (!isDesktop) {
      // Open mobile/tablet drawer to access drawer language switcher
      const menuBtn = page.locator('button[aria-label="Toggle navigation"]');
      await menuBtn.click();
      
      const drawer = page.locator('header div.shadow-xl');
      const hindiBtn = drawer.getByRole('button', { name: 'हिन्दी' });
      await expect(hindiBtn).toBeVisible();
      await hindiBtn.click();
      await expect(hindiBtn).toHaveClass(/font-bold/);

      const englishBtn = drawer.getByRole('button', { name: 'English' });
      await englishBtn.click();
      await expect(englishBtn).toHaveClass(/font-bold/);
    } else {
      // Desktop language switcher in header nav
      const hindiBtn = page.locator('header nav').getByRole('button', { name: 'हिन्दी' });
      await expect(hindiBtn).toBeVisible();
      await hindiBtn.click();
      await expect(hindiBtn).toHaveClass(/font-bold/);

      const englishBtn = page.locator('header nav').getByRole('button', { name: 'English' });
      await englishBtn.click();
      await expect(englishBtn).toHaveClass(/font-bold/);
    }

    expect(consoleErrors).toHaveLength(0);
  });
});
