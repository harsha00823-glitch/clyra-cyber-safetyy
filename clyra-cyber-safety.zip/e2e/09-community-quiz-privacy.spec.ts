import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener } from './helpers';

test.describe('CLYRA Community, Quiz & Privacy Policies', () => {
  test('should render moderated community questions and moderator responses', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/community');

    await expect(page.getByRole('heading', { name: /Ask a question\. Leave private details out\./i })).toBeVisible();
    await expect(page.getByText(/Do I need my UPI PIN to get a refund\?/i)).toBeVisible();
    await expect(page.getByText(/CLYRA moderator/i).first()).toBeVisible();

    // Verify search filter
    const searchInput = page.locator('input[placeholder*="Search"]');
    if (await searchInput.isVisible()) {
      await searchInput.fill('UPI');
      await expect(page.getByText(/Do I need my UPI PIN to get a refund\?/i)).toBeVisible();
    }

    expect(consoleErrors).toHaveLength(0);
  });

  test('should allow user to take interactive scam habit quiz and get instant explanations', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/quiz');

    await expect(page.getByRole('heading', { name: /Safety Habits Check/i })).toBeVisible();
    await expect(page.getByText(/Question 1 of/i)).toBeVisible();

    // Select option "c" (Disconnect the call immediately)
    const optionC = page.getByText(/Disconnect the call immediately/i);
    await expect(optionC).toBeVisible();
    await optionC.click();

    // Click Check Answer
    const submitBtn = page.getByRole('button', { name: /Check Answer/i });
    await expect(submitBtn).toBeVisible();
    await submitBtn.click();

    // Explanation should appear
    await expect(page.getByText(/Indian law and law enforcement agencies/i)).toBeVisible();

    // Next question button appears
    const nextBtn = page.getByRole('button', { name: /Next Question/i });
    await expect(nextBtn).toBeVisible();

    expect(consoleErrors).toHaveLength(0);
  });

  test('should display privacy policy with local on-device OCR guarantee', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/privacy');

    await expect(page.getByRole('heading', { name: /Privacy Notice: How CLYRA Protects What You Share/i })).toBeVisible();
    await expect(page.getByText(/No Sign-In Needed to Check a Threat/i)).toBeVisible();

    expect(consoleErrors).toHaveLength(0);
  });
});
