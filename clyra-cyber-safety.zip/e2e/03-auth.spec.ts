import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener, authenticateDemoUser, clearAuthCookies } from './helpers';

test.describe('CLYRA Authentication & Access Control Suite', () => {
  test.beforeEach(async ({ context }) => {
    await clearAuthCookies(context);
  });

  // ==========================================================================
  // Flow A: Normal Signup & Client Validation
  // ==========================================================================
  test('Flow A1: should validate signup form fields (password mismatch & length)', async ({ page }) => {
    await page.goto('/auth/sign-up');
    await expect(page.getByRole('heading', { name: /Create an Account/i })).toBeVisible();

    const nameInput = page.locator('input#displayName');
    const emailInput = page.locator('input#email');
    const passwordInput = page.locator('input#password');
    const confirmInput = page.locator('input#confirmPassword');
    const submitBtn = page.getByRole('button', { name: /Create Account/i });

    // Test password mismatch
    await nameInput.fill('Asha Sharma');
    await emailInput.fill('asha.test@clyra.community');
    await passwordInput.fill('SecurePass123!');
    await confirmInput.fill('DifferentPass456!');
    await submitBtn.click();

    await expect(page.getByText(/Passwords do not match/i)).toBeVisible();

    // Test short password
    await passwordInput.fill('123');
    await confirmInput.fill('123');
    await submitBtn.click();

    await expect(page.getByText(/Password must be at least 6 characters/i)).toBeVisible();
  });

  test('Flow A2: should process registration and show email confirmation screen with resend option', async ({ page }) => {
    const rawErrors: string[] = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        const text = msg.text();
        if (
          !text.includes('429') &&
          !text.includes('422') &&
          !text.includes('rate limit') &&
          !text.includes('rate_limit') &&
          !text.includes('AuthApiError') &&
          !text.includes('security purposes')
        ) {
          rawErrors.push(text);
        }
      }
    });

    await page.goto('/auth/sign-up');
    await expect(page.getByRole('heading', { name: /Create an Account/i })).toBeVisible();

    const uniqueId = `${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
    const testEmail = `citizen_${uniqueId}@clyra.community`;

    await page.locator('input#displayName').fill('Citizen Tester');
    await page.locator('input#email').fill(testEmail);
    await page.locator('input#password').fill('ValidPassword123!');
    await page.locator('input#confirmPassword').fill('ValidPassword123!');

    const submitBtn = page.getByRole('button', { name: /Create Account/i });
    await expect(submitBtn).toBeEnabled();
    await submitBtn.click();

    // The user either receives the "Confirm your email address" view (if confirmation enabled),
    // is redirected to /dashboard (if email confirmation is disabled in Supabase project),
    // or receives a rate-limit error notice from Supabase
    const emailSentHeading = page.getByRole('heading', { name: /Confirm your email address/i });
    const dashboardHeading = page.getByRole('heading', { name: /Small steps that put you back in control/i });
    const authErrorNotice = page.locator('div.bg-\\[\\#FFF0EE\\]');

    // Wait deterministically for one of the valid outcomes (using .first() on error notice to avoid strict mode violations)
    await expect(emailSentHeading.or(dashboardHeading).or(authErrorNotice.first())).toBeVisible({ timeout: 20000 });

    if (await emailSentHeading.isVisible()) {
      await expect(page.getByText(testEmail)).toBeVisible();
      await expect(page.getByRole('button', { name: /Resend confirmation email/i })).toBeVisible();
      await expect(page.getByRole('link', { name: /Proceed to Sign In/i })).toBeVisible();
    }

    expect(rawErrors).toHaveLength(0);
  });

  // ==========================================================================
  // Flow B: Auth Callback Handling & Error Query Params
  // ==========================================================================
  test('Flow B1: should handle auth callback with expired or missing code/token gracefully', async ({ page }) => {
    // Attempt callback with no code/token
    await page.goto('/auth/callback');
    await expect(page).toHaveURL(/\/auth\/sign-in/);
    await expect(page.getByText(/link is invalid or has expired/i)).toBeVisible();
  });

  test('Flow B2: should handle auth callback with explicit Supabase error parameter', async ({ page }) => {
    // Simulate Supabase redirecting to callback with an error parameter
    await page.goto('/auth/callback?error=access_denied&error_description=Email+link+is+invalid+or+has+expired');
    await expect(page).toHaveURL(/\/auth\/sign-in/);
    await expect(page.getByText(/Email link is invalid or has expired/i)).toBeVisible();
  });

  // ==========================================================================
  // Flow C & D: Sign In Validation, Invalid Credentials & Unconfirmed Behavior
  // ==========================================================================
  test('Flow C: should display clear error on invalid credentials', async ({ page }) => {
    await page.goto('/auth/sign-in');
    await page.locator('input#email').fill('nonexistent.citizen@clyra.community');
    await page.locator('input#password').fill('IncorrectPassword999!');
    await page.getByRole('button', { name: /^Sign In$/i }).click();

    await expect(
      page.getByText(/Invalid email or password/i).or(page.getByText(/Email not confirmed/i)).or(page.getByText(/error|rate limit/i))
    ).toBeVisible({ timeout: 15000 });
  });

  // ==========================================================================
  // Flow E: Forgot Password Flow
  // ==========================================================================
  test('Flow E: should render Forgot Password form, accept email, and confirm email dispatch', async ({ page }) => {
    await page.goto('/auth/forgot-password');
    await expect(page.getByRole('heading', { name: /Reset Your Password/i })).toBeVisible();

    const emailInput = page.locator('input#email');
    await emailInput.fill('registered.citizen@clyra.test');

    const sendLinkBtn = page.getByRole('button', { name: /Send Password Reset Link/i });
    await sendLinkBtn.click();

    // Verifies positive feedback state or graceful rate-limit advisory
    const confirmationNotice = page.locator('p:has-text("Check your inbox")').or(page.getByText(/rate limit|error/i));
    await expect(confirmationNotice.first()).toBeVisible({ timeout: 15000 });
  });

  // ==========================================================================
  // Flow F: Password Reset Form Validation
  // ==========================================================================
  test('Flow F: should render Password Reset form and validate password inputs', async ({ page }) => {
    await page.goto('/auth/reset-password');
    await expect(page.getByRole('heading', { name: /Set New Password/i })).toBeVisible();

    const passwordInput = page.locator('input#password');
    const confirmInput = page.locator('input#confirmPassword');
    const updateBtn = page.getByRole('button', { name: /Update Password & Continue/i });

    // Test password mismatch
    await passwordInput.fill('NewPass123!');
    await confirmInput.fill('Mismatch456!');
    await updateBtn.click();

    await expect(page.getByText(/Passwords do not match/i)).toBeVisible();

    // Verify back-link to forgot password
    const forgotLink = page.getByRole('link', { name: /Request new reset link/i });
    await expect(forgotLink).toBeVisible();
  });

  // ==========================================================================
  // Flow G: Logout & Session Teardown
  // ==========================================================================
  test('Flow G: should allow authenticated user to cleanly sign out and clear session', async ({ page, context }) => {
    await authenticateDemoUser(context, page);
    await page.goto('/dashboard');
    await expect(page.getByRole('heading', { name: /Small steps that put you back in control/i })).toBeVisible();

    // Open user menu in Navbar
    const userMenuButton = page.locator('button[aria-label="User Menu"]');
    if (await userMenuButton.isVisible()) {
      await userMenuButton.click();
      const signOutBtn = page.getByRole('button', { name: /Sign out/i });
      await expect(signOutBtn).toBeVisible();
      await signOutBtn.click();

      // Verified redirect to sign in
      await expect(page).toHaveURL(/\/auth\/sign-in/);
    }
  });

  // ==========================================================================
  // Flow H & I: Protected Dashboard Guard & Session Persistence
  // ==========================================================================
  test('Flow I: should redirect unauthenticated user from /dashboard to /auth/sign-in', async ({ page }) => {
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/auth\/sign-in/);
  });

  test('Flow H: should persist authenticated session across page reloads and navigation', async ({ page, context }) => {
    await authenticateDemoUser(context, page);
    await page.goto('/dashboard');
    await expect(page.getByRole('heading', { name: /Small steps that put you back in control/i })).toBeVisible();

    // Navigate to Learn and back to Dashboard
    await page.goto('/learn');
    await expect(page.getByRole('heading', { name: /Confidence grows with a little practice/i })).toBeVisible();

    await page.goto('/dashboard');
    await expect(page.getByRole('heading', { name: /Small steps that put you back in control/i })).toBeVisible();

    // Reload page
    await page.reload();
    await expect(page.getByRole('heading', { name: /Small steps that put you back in control/i })).toBeVisible();
  });

  // ==========================================================================
  // Flow J: Evaluator / Demo Login Isolation & Security
  // ==========================================================================
  test('Flow J: should support isolated Evaluator / Demo Login without secret exposure', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/auth/sign-in');

    // Verify clear demo labeling
    await expect(page.getByText(/Evaluator \/ Demo Login/i)).toBeVisible();
    await expect(page.getByText(/Pre-configured evaluator workspace with sample incident data/i)).toBeVisible();

    const instantBtn = page.getByRole('button', { name: /One-Click Instant Access/i });
    await expect(instantBtn).toBeVisible();
    await instantBtn.click();

    // Verify redirected to recovery workspace
    await expect(page).toHaveURL(/\/dashboard/);
    await expect(page.getByRole('heading', { name: /Small steps that put you back in control/i })).toBeVisible();

    // Verify no secret keys or service keys leaked in DOM
    const bodyContent = await page.content();
    expect(bodyContent).not.toContain('SUPABASE_SERVICE_ROLE_KEY');
    expect(bodyContent).not.toContain('service_role');
    expect(consoleErrors).toHaveLength(0);
  });
});
