import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener } from './helpers';

test.describe('CLYRA Learning Center & Countermeasure Modules', () => {
  test('should render 6 learning modules on /learn', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/learn');

    await expect(page.getByRole('heading', { name: /Confidence grows with a little practice\./i })).toBeVisible();
    await expect(page.getByText(/UPI: receiving money never needs a PIN/i).first()).toBeVisible();
    await expect(page.getByText(/Spot a message that wants you to rush/i)).toBeVisible();
    await expect(page.getByText(/Take back an account safely/i)).toBeVisible();

    expect(consoleErrors).toHaveLength(0);
  });

  test('should render Section 41A BNSS legal countermeasure on /digital-arrest', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/digital-arrest');

    await expect(page.getByRole('heading', { name: /Digital Arrest: What it is and how to stay safe\./i })).toBeVisible();
    await expect(page.getByText(/BNSS/i).or(page.getByText(/Digital Arrest/i)).first()).toBeVisible();
    await expect(page.locator('a[href="tel:1930"]').first()).toBeVisible();

    expect(consoleErrors).toHaveLength(0);
  });

  test('should render APK sideloading mechanics and permission guide on /malicious-apps', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/malicious-apps');

    await expect(page.getByRole('heading', { name: /Malicious App Safety: Avoid Sideloading & OTP Stealers/i })).toBeVisible();
    await expect(page.getByText(/The Lure/i).first()).toBeVisible();
    await expect(page.getByText(/The Installation/i).first()).toBeVisible();
    await expect(page.getByText(/Airplane Mode/i).first()).toBeVisible();

    expect(consoleErrors).toHaveLength(0);
  });
});
