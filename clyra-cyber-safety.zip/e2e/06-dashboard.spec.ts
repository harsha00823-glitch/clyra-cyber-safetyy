import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener, authenticateDemoUser } from './helpers';

test.describe('CLYRA Dashboard & Personal Recovery Workspace', () => {
  test.beforeEach(async ({ context }) => {
    await authenticateDemoUser(context);
  });

  test('should display personalized greeting, action tiles, 5-step checklist, and timeline', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/dashboard');

    // 1. Verify Header Reassurance
    await expect(page.getByRole('heading', { name: /Small steps that put you back in control/i })).toBeVisible();

    // 2. Verify 4 Quick Action Tiles
    await expect(page.getByText(/Check Threat/i).first()).toBeVisible();
    await expect(page.getByText(/Lost Money\?/i).first()).toBeVisible();
    await expect(page.getByText(/Prepare Report/i).first()).toBeVisible();
    await expect(page.getByText(/Safety Lessons/i).first()).toBeVisible();

    // 3. Verify 5-Step Safety Checklist
    await expect(page.getByText(/Your Personal Safety Checklist/i)).toBeVisible();
    await expect(page.getByText(/Stop contact with the suspicious sender/i)).toBeVisible();
    await expect(page.getByText(/Contact your bank or payment provider/i)).toBeVisible();
    await expect(page.getByText(/Prepare and submit a report/i)).toBeVisible();
    await expect(page.getByText(/Preserve evidence without further contact/i)).toBeVisible();
    await expect(page.getByText(/Review apps and device permissions/i)).toBeVisible();

    // 4. Verify Case Summary & Notes
    await expect(page.getByText(/SC-DEMO-014/i)).toBeVisible();
    await expect(page.getByText(/₹8,500/i)).toBeVisible();

    // 5. Verify Recovery Timeline
    await expect(page.getByText(/Your Recovery Timeline/i)).toBeVisible();
    await expect(page.getByText(/Called 1930/i)).toBeVisible();

    expect(consoleErrors).toHaveLength(0);
  });
});
