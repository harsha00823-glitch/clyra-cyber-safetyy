import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener, verifyNoBrokenImages } from './helpers';

test.describe('CLYRA Home Page Flow', () => {
  test('should render Home page with correct branding, reassurance hero and 4-step progression', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/');

    // 1. Verify Branding and Tagline
    await expect(page).toHaveTitle(/CLYRA/i);
    await expect(page.getByText(/cylra/i).first()).toBeVisible();
    await expect(page.getByText('CLYRA · Detect. Understand. Protect')).toBeVisible();

    // 2. Verify Reassurance Hero
    await expect(page.getByRole('heading', { name: /Clear guidance\. No judgement\./i })).toBeVisible();

    // 3. Verify Threat Quick Check Box
    await expect(page.getByText(/Something doesn’t feel right\? Start with a simple check\./i)).toBeVisible();
    await expect(page.getByText(/1 · Urgency & a threat/i)).toBeVisible();
    await expect(page.getByText(/2 · An unfamiliar link/i)).toBeVisible();
    await expect(page.getByText(/3 · A request for an OTP/i)).toBeVisible();

    // 4. Verify Urgent Emergency Helpline 1930 Callout
    await expect(page.getByText(/Lost money to a suspected scam\?/i).first()).toBeVisible();
    const helplineButton = page.locator('a[href="tel:1930"]').first();
    await expect(helplineButton).toBeVisible();

    // 5. Verify 4-Step Civic Progression
    await expect(page.getByText(/01 \/ DETECT/i)).toBeVisible();
    await expect(page.getByText(/02 \/ UNDERSTAND/i)).toBeVisible();
    await expect(page.getByText(/03 \/ PROTECT/i)).toBeVisible();
    await expect(page.getByText(/04 \/ RECOVER & REPORT/i)).toBeVisible();

    // 6. Verify Footer Civic Boundaries
    await expect(page.getByText(/CLYRA Cyber Safety is a community guidance concept/i)).toBeVisible();
    await expect(page.getByText(/cybercrime\.gov\.in/i).first()).toBeVisible();

    // 7. Verify No Broken Images & Zero Console Errors
    await verifyNoBrokenImages(page);
    expect(consoleErrors).toHaveLength(0);
  });

  test('should navigate to analyzer when clicking "Check this message" CTA', async ({ page }) => {
    await page.goto('/');
    const checkButton = page.getByRole('link', { name: /Check this message/i });
    await expect(checkButton).toBeVisible();
    await checkButton.click();
    await expect(page).toHaveURL(/\/analyze/);
    await expect(page.getByRole('heading', { name: /Let’s check what you received/i })).toBeVisible();
  });

  test('should navigate to emergency when clicking "View urgent steps" CTA', async ({ page }) => {
    await page.goto('/');
    const emergencyButton = page.getByRole('link', { name: /View urgent steps/i });
    await expect(emergencyButton).toBeVisible();
    await emergencyButton.click();
    await expect(page).toHaveURL(/\/emergency/);
    await expect(page.getByRole('heading', { name: /Lost money\? Focus on these steps first\./i })).toBeVisible();
  });
});
