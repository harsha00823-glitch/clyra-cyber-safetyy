import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener, clearAuthCookies } from './helpers';

test.describe('CLYRA Administrative Telemetry & Authorization', () => {
  test('should redirect unauthenticated users from /admin to /auth/sign-in', async ({ page, context }) => {
    await clearAuthCookies(context);
    await page.goto('/admin');
    await expect(page).toHaveURL(/\/auth\/sign-in/);
  });

  test('should grant admin / evaluator telemetry access when authenticated', async ({ page, context }) => {
    await clearAuthCookies(context);
    const consoleErrors = setupConsoleErrorListener(page);

    // Perform Evaluator 1-Click Login to acquire verified evaluator session
    await page.goto('/auth/sign-in');
    const demoButton = page.getByRole('button', { name: /One-Click Instant Access/i });
    await expect(demoButton).toBeVisible();
    await demoButton.click();
    await expect(page).toHaveURL(/\/dashboard/);

    // Navigate to /admin with live session
    await page.goto('/admin');
    await expect(page.getByRole('heading', { name: /Threat Surveillance & Classification Stream/i })).toBeVisible();
    await expect(page.getByText(/Total Inquiries Analyzed/i)).toBeVisible();
    await expect(page.getByText(/Critical Threats Identified/i)).toBeVisible();

    expect(consoleErrors).toHaveLength(0);
  });
});
