import { test, expect } from '@playwright/test';
import { setupConsoleErrorListener } from './helpers';

test.describe('CLYRA Emergency Help & Immediate Actions', () => {
  test('should render 1930 Helpline CTA, bank freeze steps, and anti-fraud warnings', async ({ page }) => {
    const consoleErrors = setupConsoleErrorListener(page);
    await page.goto('/emergency');

    // 1. Verify Header
    await expect(page.getByRole('heading', { name: /Lost money\? Focus on these steps first\./i })).toBeVisible();

    // 2. Verify 1930 Helpline Button
    const call1930Link = page.locator('a[href="tel:1930"]').first();
    await expect(call1930Link).toBeVisible();

    // 3. Verify Bank Contact Guidance
    await expect(page.getByText(/1 · Contact your bank or payment provider immediately/i)).toBeVisible();
    await expect(page.getByText(/2 · Report through the official portal/i)).toBeVisible();
    await expect(page.getByText(/3 · Preserve evidence without contacting the sender again/i)).toBeVisible();

    // 4. Verify Link to Safety Checklist
    const continueRecoveryBtn = page.getByRole('link', { name: /Go to my recovery workspace/i });
    await expect(continueRecoveryBtn).toBeVisible();
    await continueRecoveryBtn.click();
    await expect(page).toHaveURL(/\/(dashboard|auth\/sign-in)/);

    expect(consoleErrors).toHaveLength(0);
  });
});
