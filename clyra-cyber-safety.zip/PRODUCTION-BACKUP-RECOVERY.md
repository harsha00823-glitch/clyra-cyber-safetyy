# CLYRA Cyber Safety Platform
## Production Backup, Disaster Recovery & Security Audit Guide

---

### Executive Summary

This document establishes the official production backup, disaster recovery, and operational security procedures for **CLYRA** (Community Cyber Safety Platform).

> [!IMPORTANT]
> **Production Boundary Disclaimer:**
> CLYRA provides educational and community cyber safety guidance. It is neither a government agency nor an emergency financial service. In active financial fraud emergencies, citizens must always be guided to immediately dial the National Cyber Crime Helpline (**1930**) and contact their bank's official emergency helpline.

---

### 1. Data Classification & Automatic vs. Manual Backups

| Data Domain | Storage Location | Automatic Cloud Backup Status | Potential Loss Risk |
| :--- | :--- | :--- | :--- |
| **User Authentication & Profiles** (`auth.users`, `user_profiles`) | Supabase PostgreSQL | **Automatic (Daily snapshot)** on Supabase Pro. *Manual on Free tier.* | New signups since last daily snapshot. |
| **Threat Analysis Sessions** (`analysis_sessions`, `analysis_signals`) | Supabase PostgreSQL | **Automatic (Daily snapshot)** on Supabase Pro. Data expires after 30 days. | Transient session records since last snapshot. |
| **Knowledge Base & Articles** (`scam_entries`, `articles`, `quizzes`) | Supabase PostgreSQL & Git codebase | **Version Controlled in Git** + Database backup. | Minimal (Canonical copies exist in Git migrations). |
| **User Evidence & Screenshots** | Local Browser Memory (WASM OCR) | **Not Stored on Cloud** (100% On-Device Privacy). | None (Raw images are never uploaded to cloud servers). |
| **Frontend & Edge Routing** | Vercel Global Edge Network | **Automated Immutable Deployments** on Vercel. | Zero (All previous deployment artifacts are retained). |

---

### 2. What Is Automatically Backed Up vs. What Is NOT

#### ✅ What IS Automatically Backed Up:
1. **Application Code & Schemas:** Every commit, migration file (`supabase/migrations/`), and configuration is version-controlled in Git.
2. **Vercel Deployments:** Every production build creates an immutable deployment hash that can be instantly rolled back.
3. **Supabase Database (Pro Tier):** Daily automated database snapshots with 7-day retention (or continuous WAL Point-in-Time Recovery if PITR is enabled).

#### ❌ What is NOT Automatically Backed Up (Requires Explicit Configuration):
1. **Free Tier Supabase Projects:** Supabase Free Tier does not include continuous PITR. Without a scheduled manual export script, data older than the weekly project pause cycle requires manual export.
2. **Local Browser Storage:** Unsaved incident summaries stored in citizen browser `localStorage` or `sessionStorage` exist only on the user's device and cannot be recovered if the browser cache is cleared.
3. **Environment Secrets:** Secrets configured in the Vercel Dashboard or Supabase Dashboard are encrypted at rest but not backed up to Git (by security design).

---

### 3. Database Restoration & Recovery Runbook

```mermaid
flowchart TD
    A["Incident Detected (Data corruption / DB failure)"] --> B{"Assessment"}
    B -->|"Recent Point-in-Time (<7 days)"| C["Supabase Dashboard -> Database -> Backups"]
    C --> D["Select Restore Point / PITR Timestamp"]
    D --> E["Execute In-Place Restoration"]
    B -->|"Catastrophic Project Loss"| F["Provision New Supabase Project"]
    F --> G["Run Migrations from Git: supabase/migrations/"]
    G --> H["Import Latest SQL Backup Dump (pg_restore / psql)"]
    H --> I["Update Vercel Environment Variables (NEXT_PUBLIC_SUPABASE_URL, Keys)"]
    I --> J["Trigger Vercel Redeployment"]
    E --> K["Verify Application with Playwright E2E Suite"]
    J --> K
```

#### Step-by-Step Restoration Procedure:

1. **In-Place Restore (Supabase Dashboard):**
   - Navigate to **Supabase Dashboard** → **Project Settings** → **Database** → **Backups**.
   - Select the desired backup snapshot or specify the exact PITR timestamp.
   - Confirm restoration. The database will enter maintenance mode for 2–5 minutes while snapshot volumes are restored.

2. **Off-Site Manual Backup Export (Recommended Nightly Schedule):**
   ```bash
   # Export schema and data to compressed encrypted backup
   export PGPASSWORD="your-database-password"
   pg_dump -h db.your-project-ref.supabase.co -U postgres -d postgres -F c -b -v -f clyra_db_backup_$(date +%Y%m%d).dump
   ```

3. **Disaster Recovery from SQL Migration Files:**
   If the database project is deleted or corrupted:
   - Create a fresh Supabase project.
   - Run the baseline hardened migration:
     ```bash
     npx supabase db push
     # or execute supabase/migrations/20261003_initial_cyber_safety_schema.sql in the SQL Editor
     ```
   - Restore database dumps:
     ```bash
     pg_restore -h db.new-project-ref.supabase.co -U postgres -d postgres -v clyra_db_backup_latest.dump
     ```

---

### 4. Vercel Deployment Rollback Procedure

If a bad frontend release or regression is deployed to production:

1. **Instant One-Click Rollback (Zero Downtime):**
   - Open **Vercel Dashboard** → **CLYRA Project** → **Deployments**.
   - Locate the previous known-good deployment (e.g., the commit that passed all Playwright tests).
   - Click the **`...` (Options)** menu next to that deployment and select **Instant Rollback (Promote to Production)**.
   - Vercel routes 100% of live traffic to the rollback target in **under 2 seconds**.

2. **Rollback via Vercel CLI:**
   ```bash
   vercel rollback <deployment-url-or-id>
   ```

3. **Git Revert Rollback:**
   ```bash
   git revert HEAD
   git push origin main
   ```

---

### 5. Resiliency & Graceful Degradation Scenarios

#### Scenario A: Supabase Is Temporarily Unavailable
- **Threat Analyzer Functionality:** Continues operating without interruption. Analysis rules, heuristics, and regex matching run deterministically on the server/client.
- **On-Device OCR:** Runs 100% locally in the browser via WebAssembly (`tesseract.js` WASM). Citizens can still extract and check text from screenshots.
- **Educational Modules & Emergency 1930 Guide:** Fully rendered as static/SSR pages, remaining 100% available.
- **Degraded Behavior:** User login and history persistence will log a non-fatal warning (`_persistenceNote`) and allow the user to view their risk score and action checklist immediately.

#### Scenario B: Vercel Edge Is Temporarily Unavailable
- **Edge Caching:** Cloudflare / CDN edges serve cached versions of public educational guides and emergency pages.
- **Failover:** DNS records (e.g. AWS Route53 / Cloudflare) can be repointed to a secondary standby deployment.

---

### 6. Security & Access Control Audit Checklist

- [x] **Zero Secrets in Git:** Verified `.env*` is listed in `.gitignore`. No API keys or passwords in commit tree.
- [x] **Server-Only Service Role Key:** `SUPABASE_SERVICE_ROLE_KEY` has NO `NEXT_PUBLIC_` prefix and is only imported in server API routes.
- [x] **Row Level Security (RLS) on All 16 Tables:**
  - `user_profiles`: Restricted to row owner (`auth.uid() = id`).
  - `analysis_sessions`: Direct inserts/updates REVOKED from browser clients. Only written via server-side `service_role`.
  - `detection_patterns`: Locked from public access.
  - `quiz_options`: `is_correct` field hidden behind security barrier view `quiz_options_public`.
  - `quizzes`: Server-side scoring trigger (`validate_and_score_quiz_answer`).
- [x] **Privacy-by-Design Evidence Handling:** Image files are processed locally inside browser RAM; raw sensitive images are never sent to external AI or cloud storage.
- [x] **Evaluator / Demo Login Isolation:** Uses separate, controlled authentication routes without leaking secrets.

---

### 7. Recommended Production Backup Schedule

| Frequency | Action | Tool / Target |
| :--- | :--- | :--- |
| **Continuous** | WAL Point-in-Time Logging | Supabase Pro PITR |
| **Daily (02:00 UTC)** | Automated Logical SQL Dump | `pg_dump` to secure AWS S3 / GCP Storage bucket |
| **Every Release** | Automated E2E Regression Testing | Playwright (129 tests across Desktop, Tablet, Mobile) |
| **Monthly** | Disaster Recovery Simulation | Restore dump into staging project and run test suite |

---

### 8. Production Readiness Sign-Off

- **TypeScript Compilation:** Passed (`npx tsc --noEmit` -> 0 errors)
- **Code Linter:** Passed (`npm run lint` -> 0 errors, 0 warnings)
- **Production Build:** Passed (`npm run build` -> 25/25 routes compiled)
- **Playwright Test Suite:** Passed (129/129 tests passing across all viewports)
