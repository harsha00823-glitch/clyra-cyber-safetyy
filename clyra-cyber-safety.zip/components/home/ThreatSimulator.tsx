"use client";

import { useState } from "react";
import Link from "next/link";
import { AlertTriangle, ShieldAlert, ArrowRight, CheckCircle2 } from "lucide-react";

interface Scenario {
  id: string;
  name: string;
  type: string;
  icon: string;
  rawText: string;
  score: number;
  level: "critical" | "high" | "medium";
  signals: string[];
  action: string;
  legalNote?: string;
}

const SCENARIOS: Scenario[] = [
  {
    id: "digital-arrest",
    name: "Digital Arrest Call",
    type: "Authority Extortion",
    icon: "🚨",
    rawText: "This is Cyber Crime Branch, Mumbai. A consignment containing synthetic drugs and forged passports was intercepted in your name. You are under immediate Digital Arrest. Do not disconnect this Skype video interrogation under Section 120B or arrest warrant will be dispatched.",
    score: 95,
    level: "critical",
    signals: [
      "Authority Impersonation (Police/Cyber Cell)",
      "Coercion & Illegal 'Digital Arrest' Threat",
      "Isolation Demand (Forbidding Disconnect)",
      "Fake Legal Jurisdiction Claim"
    ],
    action: "Disconnect video call immediately. Indian Police & Courts never conduct arrests or trials over Skype/WhatsApp.",
    legalNote: "Section 41A of BNSS requires physical notices served in person. 'Digital Arrest' is completely fraudulent."
  },
  {
    id: "electricity-bill",
    name: "Electricity Bill Urgency",
    type: "Phishing SMS",
    icon: "⚡",
    rawText: "Dear consumer, your electricity power will be disconnected tonight at 9:30 PM from the electric office because your previous month bill was not updated. Please immediately contact our electricity officer Rahul Sharma at 9876543210. Thank you.",
    score: 85,
    level: "high",
    signals: [
      "Artificial Urgency ('Tonight at 9:30 PM')",
      "Fear-Inducing Utility Disconnection",
      "Personal Mobile Number Contact",
      "Missing Official Consumer Account Details"
    ],
    action: "Do not call the mobile number. Check your official electricity board portal or physical bill receipt.",
    legalNote: "Disconnection requires written physical notice under Section 56 of Electricity Act 2003."
  },
  {
    id: "fake-apk",
    name: "Bank KYC APK Sideload",
    type: "Malicious Software",
    icon: "📱",
    rawText: "Dear SBI customer, your YONO account has been temporarily suspended due to expired KYC. Download and install 'SBI_YONO_Update_v4.apk' from http://sbi-kyc-service.top to avoid permanent account block.",
    score: 92,
    level: "critical",
    signals: [
      "Unverified Third-Party .apk Sideload",
      "Deceptive Typosquatted Domain (.top TLD)",
      "Banking Credential & OTP Harvesting Vector",
      "Account Block Coercion"
    ],
    action: "Never install APKs sent via SMS/WhatsApp. Only install banking apps from Google Play Store or Apple App Store.",
    legalNote: "Malicious APKs abuse Accessibility Services to intercept 2-factor SMS OTPs in the background."
  },
  {
    id: "part-time-job",
    name: "Part-Time Task Scam",
    type: "Financial Fraud",
    icon: "💼",
    rawText: "Congratulations! You have been selected for Amazon Part-time remote review task. Earn Rs 2500 - 8000 daily just by liking YouTube videos and rating hotels. Initial payout Rs 200 guaranteed. Join VIP telegram group @quick_payouts_india to claim.",
    score: 75,
    level: "high",
    signals: [
      "Unrealistic Guaranteed Payouts",
      "Task-Based Lure ('Like YouTube videos')",
      "Telegram Redirection Vector",
      "Ponzi Progression ('VIP Task Deposit')"
    ],
    action: "Block the sender. Initial small payouts are bait to lure you into depositing larger non-refundable amounts.",
    legalNote: "Legitimate corporate recruiters do not hire via unsolicited WhatsApp/Telegram broadcasts."
  }
];

export default function ThreatSimulator() {
  const [selectedScenario, setSelectedScenario] = useState<Scenario>(SCENARIOS[0]);

  return (
    <div className="rounded-[20px] bg-white border border-[#DCE3ED] shadow-[0_4px_20px_rgba(24,43,73,0.05)] p-6 sm:p-8 relative">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 border-b border-[#DCE3ED] pb-5">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-[#245CC5] text-xs font-bold uppercase mb-2">
            <span>●</span>
            <span>Interactive Threat Simulator</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-[#182B49]">
            See How Common Attack Patterns Are Detected
          </h2>
          <p className="text-xs sm:text-sm text-[#58677D] mt-1">
            Select a common scenario to inspect trigger signals and guidance steps.
          </p>
        </div>

        <Link
          href="/analyze"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#245CC5] text-white font-bold text-xs shadow-xs hover:bg-[#1D4A9E] transition-all self-start md:self-auto"
        >
          <span>Test Custom Content</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      {/* Scenario Selector Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-6">
        {SCENARIOS.map((scenario) => {
          const isSelected = selectedScenario.id === scenario.id;
          return (
            <button
              key={scenario.id}
              onClick={() => setSelectedScenario(scenario)}
              className={`p-3.5 rounded-[14px] border text-left transition-all flex items-center space-x-3 ${
                isSelected
                  ? "bg-blue-50/60 border-[#245CC5] text-[#182B49] shadow-xs ring-1 ring-[#245CC5]"
                  : "bg-[#F6F8FB] border-[#DCE3ED] text-[#58677D] hover:text-[#182B49] hover:bg-white"
              }`}
            >
              <span className="text-2xl">{scenario.icon}</span>
              <div className="overflow-hidden">
                <div className="text-xs font-bold truncate text-[#182B49]">{scenario.name}</div>
                <div className="text-[10px] text-[#58677D] truncate">{scenario.type}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Raw Threat Input */}
        <div className="lg:col-span-7 flex flex-col justify-between rounded-[16px] bg-[#F6F8FB] border border-[#DCE3ED] p-5 space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#DCE3ED] text-xs text-[#58677D]">
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#B53232]"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-[#925500]"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-[#18734D]"></span>
                <span className="ml-2 font-bold text-[#182B49]">SAMPLE MESSAGE / SENDER COPY</span>
              </div>
              <span className="text-[11px] text-[#58677D] uppercase font-semibold">SMS / WhatsApp</span>
            </div>

            <div className="mt-4 p-4 rounded-[12px] bg-white border border-[#DCE3ED] text-xs sm:text-sm text-[#182B49] leading-relaxed">
              &quot;{selectedScenario.rawText}&quot;
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <div className="text-[11px] uppercase tracking-wider text-[#58677D] font-bold">
              Detected Warning Signs:
            </div>
            <div className="flex flex-wrap gap-1.5">
              {selectedScenario.signals.map((signal, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-lg bg-[#FFF0EE] border border-[#F6C4BD] text-[#B53232] text-[11px] font-semibold flex items-center space-x-1"
                >
                  <AlertTriangle className="w-3 h-3 text-[#B53232]" />
                  <span>{signal}</span>
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Security Assessment */}
        <div className="lg:col-span-5 rounded-[16px] bg-[#F6F8FB] border border-[#DCE3ED] p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-[#DCE3ED] pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#58677D]">Risk Assessment</span>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                selectedScenario.level === "critical"
                  ? "bg-[#FFF0EE] text-[#B53232] border border-[#F6C4BD]"
                  : "bg-[#FFF5E3] text-[#925500] border border-[#F6DCA8]"
              }`}>
                {selectedScenario.level}
              </span>
            </div>

            <div className="flex items-baseline justify-between">
              <div className="text-xs text-[#58677D] font-medium">Calculated Risk Index:</div>
              <div className="text-3xl font-extrabold text-[#182B49]">
                <span className={selectedScenario.score >= 90 ? "text-[#B53232]" : "text-[#925500]"}>
                  {selectedScenario.score}
                </span>
                <span className="text-sm text-[#8B98A9]">/100</span>
              </div>
            </div>

            <div className="p-3.5 rounded-[12px] bg-white border border-[#DCE3ED] space-y-1.5 shadow-xs">
              <div className="text-[11px] font-bold text-[#18734D] uppercase tracking-wider flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#18734D]" />
                Recommended Next Step
              </div>
              <p className="text-xs text-[#58677D] leading-relaxed">
                {selectedScenario.action}
              </p>
            </div>

            {selectedScenario.legalNote && (
              <div className="p-3 rounded-[12px] bg-white border border-[#DCE3ED] space-y-1 shadow-xs">
                <div className="text-[10px] font-bold text-[#245CC5] uppercase tracking-wider flex items-center gap-1">
                  <ShieldAlert className="w-3 h-3 text-[#245CC5]" />
                  Legal Safeguard
                </div>
                <p className="text-[11px] text-[#58677D] leading-tight">
                  {selectedScenario.legalNote}
                </p>
              </div>
            )}
          </div>

          <div className="pt-2 border-t border-[#DCE3ED]">
            <Link
              href="/analyze"
              className="w-full block text-center py-2.5 rounded-lg bg-white hover:bg-[#F6F8FB] text-[#182B49] font-bold text-xs border border-[#DCE3ED] shadow-xs transition-colors"
            >
              Check a Real Link or Message →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
