import { ReactNode } from "react";
import ClyraLogo from "./ClyraLogo";

interface AuthCardProps {
  title: string;
  description?: string;
  children: ReactNode;
}

export function AuthCard({ title, description, children }: AuthCardProps) {
  return (
    <div className="w-full max-w-md mx-auto my-8">
      <div className="bg-white border border-[#DCE3ED] rounded-[20px] shadow-[0_4px_20px_rgba(24,43,73,0.06)] overflow-hidden">
        <div className="p-6 sm:p-8">
          <div className="flex justify-center mb-6">
            <ClyraLogo size="lg" />
          </div>
          <h2 className="text-2xl font-bold text-[#182B49] mb-1.5 text-center tracking-tight">
            {title}
          </h2>
          {description && (
            <p className="text-[#58677D] text-sm text-center mb-6 leading-relaxed">
              {description}
            </p>
          )}
          {children}
        </div>
      </div>
    </div>
  );
}
