import { InputHTMLAttributes, forwardRef } from "react";

interface FormInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  helperText?: string;
}

export const FormInput = forwardRef<HTMLInputElement, FormInputProps>(
  ({ label, error, helperText, className = "", id, ...props }, ref) => {
    return (
      <div className="w-full text-left">
        <label
          htmlFor={id}
          className="block text-xs font-semibold text-[#182B49] mb-1.5"
        >
          {label}
        </label>
        <input
          id={id}
          ref={ref}
          className={`w-full bg-white border ${
            error
              ? "border-[#B53232] focus:ring-3 focus:ring-[#FFD5D2] text-[#B53232]"
              : "border-[#DCE3ED] focus:border-[#245CC5] focus:ring-3 focus:ring-[#93B4F4] text-[#182B49]"
          } rounded-lg px-3.5 py-2.5 text-sm placeholder-[#8B98A9] focus:outline-none transition-all shadow-xs ${className}`}
          {...props}
        />
        {helperText && !error && (
          <p className="mt-1 text-xs text-[#58677D]">{helperText}</p>
        )}
        {error && (
          <p className="mt-1 text-xs font-medium text-[#B53232]" role="alert">
            {error}
          </p>
        )}
      </div>
    );
  }
);

FormInput.displayName = "FormInput";
