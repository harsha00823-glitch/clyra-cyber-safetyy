import { ButtonHTMLAttributes, forwardRef } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
  variant?: "primary" | "secondary" | "tertiary" | "danger" | "ghost";
  size?: "sm" | "md" | "lg";
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      children,
      isLoading,
      variant = "primary",
      size = "md",
      className = "",
      disabled,
      ...props
    },
    ref
  ) => {
    const baseStyles =
      "inline-flex justify-center items-center rounded-lg font-medium transition-colors focus:outline-none focus:ring-3 focus:ring-[#93B4F4] disabled:opacity-50 disabled:cursor-not-allowed select-none";

    const sizeStyles = {
      sm: "min-h-[36px] px-3 py-1.5 text-xs",
      md: "min-h-[44px] px-4 py-2.5 text-sm",
      lg: "min-h-[48px] px-6 py-3 text-base font-semibold",
    };

    const variants = {
      primary: "bg-[#245CC5] text-white hover:bg-[#19489F] active:bg-[#153C85] shadow-xs",
      secondary:
        "bg-white text-[#182B49] border border-[#DCE3ED] hover:bg-[#F6F8FB] active:bg-[#EEF1F5] shadow-xs",
      tertiary: "bg-transparent text-[#245CC5] hover:bg-[#EDF3FF] active:bg-[#DCE7FD]",
      danger: "bg-[#B53232] text-white hover:bg-[#932525] active:bg-[#791E1E] shadow-xs",
      ghost: "bg-transparent text-[#58677D] hover:text-[#182B49] hover:bg-[#EEF1F5]",
    };

    return (
      <button
        ref={ref}
        disabled={isLoading || disabled}
        className={`${baseStyles} ${sizeStyles[size]} ${variants[variant]} ${className}`}
        {...props}
      >
        {isLoading && (
          <svg
            className="animate-spin -ml-1 mr-2 h-4 w-4 text-current"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            ></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
        )}
        {children}
      </button>
    );
  }
);

Button.displayName = "Button";
