import ClyraLogo from "./ClyraLogo";

export default ClyraLogo;
export { ClyraLogo };
