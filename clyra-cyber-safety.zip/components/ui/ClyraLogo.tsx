import Link from "next/link";

interface ClyraLogoProps {
  className?: string;
  iconOnly?: boolean;
  size?: "sm" | "md" | "lg";
}

export default function ClyraLogo({ className = "", iconOnly = false, size = "md" }: ClyraLogoProps) {
  const iconSizes = {
    sm: "w-7 h-7",
    md: "w-8 h-8",
    lg: "w-10 h-10",
  };

  const textSizes = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-2xl",
  };

  return (
    <Link href="/" className={`inline-flex items-center gap-2.5 group ${className}`}>
      {/* Reassuring shield / speech bubble with checkmark */}
      <div
        className={`${iconSizes[size]} rounded-full bg-[#245CC5] flex items-center justify-center text-white shadow-sm shrink-0 transition-transform group-hover:scale-105`}
      >
        <svg
          className="w-4 h-4"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M20 6L9 17l-5-5" />
        </svg>
      </div>

      {!iconOnly && (
        <div className="flex flex-col leading-none">
          <div className="flex items-baseline gap-1">
            <span className={`${textSizes[size]} font-extrabold tracking-tight text-[#182B49]`}>
              cylra
            </span>
            <span className="text-[10px] font-bold tracking-wider text-[#245CC5] uppercase">
              CLYRA
            </span>
          </div>
          <span className="text-[9px] font-bold tracking-wider text-[#58677D] uppercase mt-0.5">
            Detect · Understand · Protect
          </span>
        </div>
      )}
    </Link>
  );
}
