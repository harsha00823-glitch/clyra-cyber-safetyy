import { ReactNode } from "react";

interface PageContainerProps {
  children: ReactNode;
  className?: string;
}

export default function PageContainer({ children, className = "" }: PageContainerProps) {
  return (
    <main className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 w-full flex-1 ${className}`}>
      {children}
    </main>
  );
}
