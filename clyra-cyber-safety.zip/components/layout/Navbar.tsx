"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { User } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/client";
import ClyraLogo from "@/components/ui/ClyraLogo";
import { 
  ShieldCheck, 
  Search, 
  PhoneCall, 
  FileText, 
  BookOpen, 
  Users, 
  LogOut, 
  Menu, 
  X,
  AlertTriangle,
  ChevronDown
} from "lucide-react";

interface NavbarProps {
  user: User | null;
}

export default function Navbar({ user }: NavbarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [lang, setLang] = useState<"en" | "hi">("en");
  const dropdownRef = useRef<HTMLDivElement>(null);
  const supabase = createClient();

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setUserDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Close on route change without effect setState cascade
  const [prevPathname, setPrevPathname] = useState(pathname);
  if (pathname !== prevPathname) {
    setPrevPathname(pathname);
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
  }

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    await fetch("/api/auth/sign-out", { method: "POST" });
    router.push("/auth/sign-in");
    router.refresh();
  };

  const navItems = [
    { label: "Home", href: "/", icon: ShieldCheck },
    { label: "Check something", href: "/analyze", icon: Search },
    { label: "Protect yourself", href: "/digital-arrest", icon: AlertTriangle },
    { label: "Emergency help", href: "/emergency", icon: PhoneCall, highlight: true },
    { label: "My recovery", href: "/dashboard", icon: FileText },
    { label: "Prepare a report", href: "/report", icon: FileText },
    { label: "Learn", href: "/learn", icon: BookOpen },
    { label: "Community", href: "/community", icon: Users },
  ];

  const initials = user?.user_metadata?.display_name
    ? user.user_metadata.display_name
        .split(" ")
        .map((n: string) => n[0])
        .join("")
        .slice(0, 2)
        .toUpperCase()
    : "AS";

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-[#DCE3ED] shadow-[0_2px_8px_rgba(24,43,73,0.04)]">
      {/* Top Reassurance / Emergency Mini Bar */}
      <div className="bg-[#FFF5E3] border-b border-[#F6E1B6] px-4 py-1 text-center text-xs text-[#925500] font-medium flex items-center justify-center gap-2">
        <span className="font-bold">Lost money to a scam?</span>
        <span>Call India&apos;s cybercrime helpline</span>
        <a
          href="tel:1930"
          className="font-bold underline text-[#925500] hover:text-[#B53232] transition-colors"
        >
          1930
        </a>
        <span className="text-slate-400">·</span>
        <span>Act promptly with your bank</span>
      </div>

      <nav
        aria-label="Main Navigation"
        className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex items-center justify-between h-18"
      >
        {/* Brand & Companion Tagline */}
        <div className="flex items-center gap-4">
          <ClyraLogo />
          <div className="hidden xl:flex items-center border-l border-[#DCE3ED] pl-4 text-xs font-medium text-[#58677D]">
            <span>Detect. Understand. Protect</span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <div className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navItems.map((item) => {
            const isActive = pathname === item.href;
            if (item.highlight) {
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isActive
                      ? "bg-[#FFF0EE] text-[#B53232] border border-[#FFD5D2]"
                      : "text-[#B53232] hover:bg-[#FFF0EE] border border-transparent"
                  }`}
                >
                  <item.icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </Link>
              );
            }

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? "bg-[#EDF3FF] text-[#245CC5] font-semibold"
                    : "text-[#58677D] hover:text-[#182B49] hover:bg-[#F6F8FB]"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </div>

        {/* Right Controls: Language Switcher, User Avatar / Sign In */}
        <div className="hidden md:flex items-center gap-3">
          {/* Language Toggle: English · हिन्दी */}
          <div className="flex items-center rounded-lg border border-[#DCE3ED] bg-[#F6F8FB] p-1 text-xs">
            <button
              onClick={() => setLang("en")}
              className={`px-2 py-0.5 rounded font-medium transition-colors ${
                lang === "en"
                  ? "bg-white text-[#245CC5] shadow-xs font-bold"
                  : "text-[#58677D] hover:text-[#182B49]"
              }`}
            >
              English
            </button>
            <span className="text-[#DCE3ED] px-0.5">·</span>
            <button
              onClick={() => setLang("hi")}
              className={`px-2 py-0.5 rounded font-medium transition-colors ${
                lang === "hi"
                  ? "bg-white text-[#245CC5] shadow-xs font-bold"
                  : "text-[#58677D] hover:text-[#182B49]"
              }`}
            >
              हिन्दी
            </button>
          </div>

          {/* User Account / Avatar Pill */}
          {user ? (
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 p-1 pl-1.5 pr-2 rounded-full border border-[#DCE3ED] bg-white hover:bg-[#F6F8FB] transition-colors focus:ring-3 focus:ring-[#93B4F4]"
                aria-label="User Menu"
              >
                <div className="w-7 h-7 rounded-full bg-[#EDF3FF] text-[#245CC5] border border-[#C5D8FD] flex items-center justify-center font-bold text-xs">
                  {initials}
                </div>
                <span className="text-xs font-semibold text-[#182B49] max-w-[100px] truncate">
                  {user.user_metadata?.display_name || user.email?.split("@")[0] || "Asha"}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-[#58677D]" />
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white border border-[#DCE3ED] shadow-lg p-2 z-50 text-xs">
                  <div className="px-3 py-2 border-b border-[#DCE3ED] mb-1">
                    <p className="font-bold text-[#182B49]">
                      {user.user_metadata?.display_name || "Asha Sharma"}
                    </p>
                    <p className="text-[#58677D] text-[11px] truncate">{user.email}</p>
                  </div>
                  <Link
                    href="/dashboard"
                    className="flex items-center gap-2 px-3 py-2 rounded-lg text-[#182B49] hover:bg-[#F6F8FB] transition-colors font-medium"
                  >
                    <FileText className="w-4 h-4 text-[#245CC5]" />
                    <span>My recovery workspace</span>
                  </Link>
                  <Link
                    href="/report"
                    className="flex items-center gap-2 px-3 py-2 rounded-lg text-[#182B49] hover:bg-[#F6F8FB] transition-colors font-medium"
                  >
                    <FileText className="w-4 h-4 text-[#58677D]" />
                    <span>Prepare incident report</span>
                  </Link>
                  <button
                    onClick={handleSignOut}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-[#B53232] hover:bg-[#FFF0EE] transition-colors font-medium text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/auth/sign-in"
                className="px-3 py-1.5 text-xs font-semibold text-[#58677D] hover:text-[#182B49] transition-colors"
              >
                Sign In
              </Link>
              <Link
                href="/analyze"
                className="px-3.5 py-2 rounded-lg bg-[#245CC5] hover:bg-[#19489F] text-white text-xs font-semibold transition-colors shadow-xs"
              >
                Check message
              </Link>
            </div>
          )}
        </div>

        {/* Mobile Menu Button */}
        <div className="flex lg:hidden items-center gap-2">
          <Link
            href="/analyze"
            className="px-3 py-1.5 rounded-lg bg-[#245CC5] text-white text-xs font-semibold"
          >
            Check
          </Link>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle navigation"
            className="p-2 rounded-lg border border-[#DCE3ED] text-[#58677D] hover:bg-[#F6F8FB]"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Drawer (48px Touch Targets) */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#DCE3ED] bg-white p-4 space-y-3 shadow-xl">
          <div className="grid grid-cols-2 gap-2 text-xs">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`p-3 rounded-xl border flex items-center gap-2.5 min-h-[48px] ${
                  pathname === item.href
                    ? "bg-[#EDF3FF] border-[#245CC5] text-[#245CC5] font-bold"
                    : "border-[#DCE3ED] text-[#182B49] hover:bg-[#F6F8FB]"
                }`}
              >
                <item.icon className="w-4 h-4 text-[#245CC5] shrink-0" />
                <span className="truncate">{item.label}</span>
              </Link>
            ))}
          </div>

          <div className="pt-3 border-t border-[#DCE3ED] flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-[#58677D]">
              <span className="font-semibold text-[#182B49]">Language:</span>
              <button
                onClick={() => setLang("en")}
                className={`px-2 py-1 rounded ${lang === "en" ? "font-bold text-[#245CC5] bg-[#EDF3FF]" : ""}`}
              >
                English
              </button>
              <span>·</span>
              <button
                onClick={() => setLang("hi")}
                className={`px-2 py-1 rounded ${lang === "hi" ? "font-bold text-[#245CC5] bg-[#EDF3FF]" : ""}`}
              >
                हिन्दी
              </button>
            </div>

            {user ? (
              <button
                onClick={handleSignOut}
                className="text-xs font-semibold text-[#B53232] hover:underline"
              >
                Sign out
              </button>
            ) : (
              <Link
                href="/auth/sign-in"
                className="text-xs font-semibold text-[#245CC5] hover:underline"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
