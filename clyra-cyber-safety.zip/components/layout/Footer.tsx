import Link from "next/link";
import ClyraLogo from "@/components/ui/ClyraLogo";
import { ShieldCheck, ExternalLink } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-white border-t border-[#DCE3ED] mt-auto text-xs text-[#58677D]">
      {/* Reassurance & Honest Boundaries Callout */}
      <div className="bg-[#F6F8FB] border-b border-[#DCE3ED] py-6 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3 max-w-3xl">
            <ShieldCheck className="w-5 h-5 text-[#245CC5] shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong className="text-[#182B49] font-semibold">
                CLYRA Cyber Safety is a community guidance concept
              </strong>
              , not an official portal, emergency service, or legal advisor. A check cannot guarantee safety. If money was lost, call India&apos;s financial-fraud helpline{" "}
              <a href="tel:1930" className="text-[#B53232] font-bold underline">
                1930
              </a>{" "}
              promptly and contact your bank through official channels.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <a
              href="https://cybercrime.gov.in"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#DCE3ED] bg-white hover:bg-[#EEF1F5] text-[#182B49] font-medium transition-colors"
            >
              <span>cybercrime.gov.in</span>
              <ExternalLink className="w-3.5 h-3.5 text-[#58677D]" />
            </a>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Col */}
          <div className="md:col-span-1 space-y-3">
            <ClyraLogo size="sm" />
            <p className="text-[#58677D] text-xs leading-relaxed">
              Detect. Understand. Protect. Clear guidance, no judgement, one step at a time.
            </p>
          </div>

          {/* Practical Help */}
          <div className="space-y-2.5">
            <div className="font-semibold text-[#182B49] text-xs uppercase tracking-wider">
              Get Help
            </div>
            <ul className="space-y-2">
              <li>
                <Link href="/analyze" className="hover:text-[#245CC5] transition-colors">
                  Check a message or link
                </Link>
              </li>
              <li>
                <Link href="/emergency" className="text-[#B53232] font-medium hover:underline">
                  Lost money to a scam? (1930)
                </Link>
              </li>
              <li>
                <Link href="/report" className="hover:text-[#245CC5] transition-colors">
                  Prepare an incident report
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="hover:text-[#245CC5] transition-colors">
                  My recovery workspace
                </Link>
              </li>
            </ul>
          </div>

          {/* Education & Awareness */}
          <div className="space-y-2.5">
            <div className="font-semibold text-[#182B49] text-xs uppercase tracking-wider">
              Protect Yourself
            </div>
            <ul className="space-y-2">
              <li>
                <Link href="/digital-arrest" className="hover:text-[#245CC5] transition-colors">
                  Digital arrest scams
                </Link>
              </li>
              <li>
                <Link href="/malicious-apps" className="hover:text-[#245CC5] transition-colors">
                  Malicious apps &amp; fake APKs
                </Link>
              </li>
              <li>
                <Link href="/learn" className="hover:text-[#245CC5] transition-colors">
                  UPI &amp; payment safety rules
                </Link>
              </li>
              <li>
                <Link href="/quiz" className="hover:text-[#245CC5] transition-colors">
                  Safety habit check
                </Link>
              </li>
            </ul>
          </div>

          {/* Privacy & Principles */}
          <div className="space-y-2.5">
            <div className="font-semibold text-[#182B49] text-xs uppercase tracking-wider">
              Privacy &amp; Safety
            </div>
            <ul className="space-y-2">
              <li>
                <Link href="/privacy" className="hover:text-[#245CC5] transition-colors">
                  Zero-upload client-side OCR
                </Link>
              </li>
              <li>
                <Link href="/community" className="hover:text-[#245CC5] transition-colors">
                  Moderated peer community
                </Link>
              </li>
              <li>
                <span className="text-[#58677D]">
                  No sign-in required to start
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-[#DCE3ED] pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#8B98A9]">
          <p>
            © {new Date().getFullYear()} CLYRA Cyber Safety. Civic guidance concept. Detect. Understand. Protect.
          </p>
          <div className="flex items-center gap-4">
            <Link href="/privacy" className="hover:text-[#182B49]">
              Privacy &amp; help
            </Link>
            <span>·</span>
            <span>English · हिन्दी</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
