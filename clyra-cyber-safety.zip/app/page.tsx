"use client";

import { useState } from "react";
import Link from "next/link";
import { 
  ShieldCheck, 
  PhoneCall, 
  ArrowRight, 
  Lock
} from "lucide-react";

export default function Home() {
  const [activeTab, setActiveTab] = useState<"message" | "link" | "phone">("message");
  const [sampleText, setSampleText] = useState(
    "Dear customer, your bank KYC expires TODAY. Your account will be blocked in 2 hours. Update now at [unfamiliar link] and enter the OTP to avoid suspension."
  );

  return (
    <div className="space-y-12 max-w-5xl mx-auto py-2">
      {/* 1. Hero Reassurance Moment */}
      <section className="text-center space-y-4 max-w-2xl mx-auto pt-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EDF3FF] border border-[#C5D8FD] text-[#245CC5] text-xs font-semibold">
          <ShieldCheck className="w-4 h-4 text-[#245CC5]" />
          <span>CLYRA · Detect. Understand. Protect</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182B49] leading-tight">
          Clear guidance. No judgement.{" "}
          <span className="text-[#245CC5]">One step at a time.</span>
        </h1>

        <p className="text-base text-[#58677D] leading-relaxed">
          We’ll help you understand what happened and guide you through what to do next. For everyone, every day.
        </p>
      </section>

      {/* 2. Interactive Quick Check Card (Figma Screen 1) */}
      <section className="clyra-panel p-6 sm:p-8 bg-white space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#DCE3ED] pb-4">
          <div>
            <h2 className="text-lg font-bold text-[#182B49]">
              Something doesn’t feel right? Start with a simple check.
            </h2>
            <p className="text-xs text-[#58677D] mt-0.5">
              Share only what’s needed. We’ll help you spot common warning signs.
            </p>
          </div>

          <span className="self-start sm:self-auto px-2.5 py-1 rounded-full bg-[#F6F8FB] border border-[#DCE3ED] text-[#58677D] text-[11px] font-semibold">
            No sign-in needed to start
          </span>
        </div>

        {/* Tab Selection: Message, Link, Phone number */}
        <div className="flex items-center gap-2 border-b border-[#DCE3ED] pb-3 text-xs">
          <button
            onClick={() => setActiveTab("message")}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === "message"
                ? "bg-[#245CC5] text-white shadow-xs"
                : "text-[#58677D] hover:bg-[#F6F8FB]"
            }`}
          >
            Message
          </button>
          <button
            onClick={() => setActiveTab("link")}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === "link"
                ? "bg-[#245CC5] text-white shadow-xs"
                : "text-[#58677D] hover:bg-[#F6F8FB]"
            }`}
          >
            Link
          </button>
          <button
            onClick={() => setActiveTab("phone")}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === "phone"
                ? "bg-[#245CC5] text-white shadow-xs"
                : "text-[#58677D] hover:bg-[#F6F8FB]"
            }`}
          >
            Phone number
          </button>
        </div>

        {/* Text Input with Redaction Advisory */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-[#58677D]">
            <span className="font-semibold text-[#182B49]">
              {activeTab === "message"
                ? "Message text"
                : activeTab === "link"
                ? "Website link (URL)"
                : "Phone number"}
            </span>
            <span className="text-[11px] text-[#925500] bg-[#FFF5E3] px-2 py-0.5 rounded border border-[#F6E1B6]">
              Keep the wording, but remove private details
            </span>
          </div>

          <textarea
            value={sampleText}
            onChange={(e) => setSampleText(e.target.value)}
            rows={3}
            className="w-full bg-[#F6F8FB] border border-[#DCE3ED] rounded-xl p-3.5 text-sm text-[#182B49] placeholder-[#8B98A9] focus:outline-none focus:ring-3 focus:ring-[#93B4F4] focus:border-[#245CC5] focus:bg-white transition-all resize-none"
            placeholder={
              activeTab === "message"
                ? "Paste the message here (e.g. KYC expiring, parcel on hold)..."
                : activeTab === "link"
                ? "Paste link here (e.g. http://unfamiliar-link.com)..."
                : "Paste phone number here..."
            }
          />

          <div className="p-3 rounded-lg bg-[#F6F8FB] border border-[#DCE3ED] text-xs text-[#58677D] flex items-start gap-2">
            <Lock className="w-4 h-4 text-[#245CC5] shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong className="text-[#182B49]">Keep your private details out:</strong> Do not submit OTPs, UPI PINs, passwords, full account numbers, or Aadhaar details.
            </p>
          </div>
        </div>

        {/* Action Button Row */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
          <Link
            href={`/analyze?query=${encodeURIComponent(sampleText)}`}
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-[#245CC5] hover:bg-[#19489F] text-white font-semibold text-sm transition-all shadow-xs"
          >
            <span>Check this message</span>
            <ArrowRight className="w-4 h-4" />
          </Link>

          <button
            onClick={() => setSampleText("")}
            className="text-xs text-[#58677D] hover:text-[#182B49] text-center sm:text-right hover:underline"
          >
            Clear sample text
          </button>
        </div>

        {/* Interactive Highlighted Sample Breakdown (Figma Step 2) */}
        <div className="mt-6 pt-6 border-t border-[#DCE3ED] space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#58677D]">
              Illustrative result · Why these are warning signs
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-[#FFF0EE] border border-[#FFD5D2] text-[#B53232] text-xs font-bold">
              High risk
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-3.5 rounded-xl bg-[#FFF5E3] border border-[#F6E1B6] space-y-1.5">
              <span className="font-bold text-[#925500]">1 · Urgency &amp; a threat</span>
              <p className="text-[#6D4002] leading-relaxed">
                &ldquo;Blocked in 2 hours&rdquo; pushes you to act before you have time to verify independently.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#FFF5E3] border border-[#F6E1B6] space-y-1.5">
              <span className="font-bold text-[#925500]">2 · An unfamiliar link</span>
              <p className="text-[#6D4002] leading-relaxed">
                The message asks you to leave the bank&apos;s official app or portal for an unknown web address.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#FFF0EE] border border-[#FFD5D2] space-y-1.5">
              <span className="font-bold text-[#B53232]">3 · A request for an OTP</span>
              <p className="text-[#932525] leading-relaxed">
                Never share an OTP or approve a request to prevent an account suspension. Banks never ask for this.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Emergency Banner (If money was lost) */}
      <section className="clyra-card p-6 bg-gradient-to-r from-[#FFF0EE] to-[#FFFFFF] border-[#FFD5D2] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2 text-[#B53232] text-xs font-bold uppercase tracking-wide">
            <PhoneCall className="w-4 h-4 text-[#B53232]" />
            <span>Lost money to a suspected scam?</span>
          </div>
          <h3 className="text-lg font-bold text-[#182B49]">
            Act promptly. Don’t wait for a check.
          </h3>
          <p className="text-xs text-[#58677D] leading-relaxed">
            Call India&apos;s cyber financial fraud helpline at <strong className="text-[#182B49]">1930</strong> and contact your bank or payment provider immediately through official channels.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2.5 w-full sm:w-auto shrink-0">
          <a
            href="tel:1930"
            className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-[#B53232] hover:bg-[#932525] text-white text-xs font-bold text-center transition-colors shadow-xs"
          >
            Call 1930 Helpline
          </a>
          <Link
            href="/emergency"
            className="w-full sm:w-auto px-4 py-2.5 rounded-lg border border-[#DCE3ED] bg-white hover:bg-[#F6F8FB] text-[#182B49] text-xs font-semibold text-center transition-colors"
          >
            View urgent steps
          </Link>
        </div>
      </section>

      {/* 4. The 4-Step CLYRA Journey (From Figma: 01 DETECT to 04 RECOVER) */}
      <section className="space-y-4">
        <div className="text-left space-y-1">
          <h2 className="text-xl font-bold text-[#182B49]">
            A little clarity at every step
          </h2>
          <p className="text-xs text-[#58677D]">
            You don’t have to figure this out alone. One step at a time.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="clyra-card p-5 space-y-2">
            <span className="text-[11px] font-bold text-[#245CC5] uppercase tracking-wider block">
              01 / DETECT
            </span>
            <h4 className="font-bold text-[#182B49] text-sm">
              Check a message or link
            </h4>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Check what happened. Spot high-risk keywords, deceptive URLs, and urgency traps.
            </p>
          </div>

          <div className="clyra-card p-5 space-y-2">
            <span className="text-[11px] font-bold text-[#245CC5] uppercase tracking-wider block">
              02 / UNDERSTAND
            </span>
            <h4 className="font-bold text-[#182B49] text-sm">
              Plain-language signs
            </h4>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Understand the psychological tricks behind fake arrest warrants and OTP stealing.
            </p>
          </div>

          <div className="clyra-card p-5 space-y-2">
            <span className="text-[11px] font-bold text-[#245CC5] uppercase tracking-wider block">
              03 / PROTECT
            </span>
            <h4 className="font-bold text-[#182B49] text-sm">
              Practical next steps
            </h4>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Block the sender, disconnect coercion calls, freeze net-banking, and preserve evidence.
            </p>
          </div>

          <div className="clyra-card p-5 space-y-2">
            <span className="text-[11px] font-bold text-[#245CC5] uppercase tracking-wider block">
              04 / RECOVER &amp; REPORT
            </span>
            <h4 className="font-bold text-[#182B49] text-sm">
              Organise your summary
            </h4>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Prepare a clean incident dossier to submit directly through cybercrime.gov.in.
            </p>
          </div>
        </div>
      </section>

      {/* 5. Personal Recovery Workspace & Education Pillars */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recovery Workspace Card */}
        <div className="clyra-panel p-6 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-[#245CC5] uppercase tracking-wider">
              My Recovery Workspace
            </span>
            <h3 className="text-lg font-bold text-[#182B49]">
              Keep your checklist, notes, and evidence in one place
            </h3>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Pick up where you left off. Track which banks you called, which files you saved, and export your private summary when ready.
            </p>
          </div>

          <div className="pt-2">
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-[#DCE3ED] bg-white hover:bg-[#F6F8FB] text-[#182B49] text-xs font-semibold transition-colors"
            >
              <span>Open my recovery workspace</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#58677D]" />
            </Link>
          </div>
        </div>

        {/* Small Lessons & Community Support */}
        <div className="clyra-panel p-6 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-[#18734D] uppercase tracking-wider">
              Everyday Digital Safety
            </span>
            <h3 className="text-lg font-bold text-[#182B49]">
              Small lessons. Safer habits for the whole family.
            </h3>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Understand why receiving money on UPI never requires a PIN, how fake APK sideloading works, and how to verify workplace messages.
            </p>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <Link
              href="/learn"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#245CC5] hover:bg-[#19489F] text-white text-xs font-semibold transition-colors shadow-xs"
            >
              <span>Explore lessons</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
            <Link
              href="/community"
              className="text-xs font-semibold text-[#58677D] hover:text-[#182B49] transition-colors"
            >
              Moderated community →
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
