import Link from "next/link";
import { 
  ShieldAlert, 
  Smartphone, 
  CheckCircle2, 
  AlertTriangle, 
  PhoneCall, 
  WifiOff, 
  Trash2, 
  Lock, 
  ArrowRight,
  ExternalLink
} from "lucide-react";

export default function MaliciousAppsPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8 py-8 px-4 sm:px-6">
      {/* Category Header */}
      <header className="space-y-3">
        <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#245CC5]">
          <span>PROTECT / MALICIOUS APPS & APK SAFETY</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#182B49] tracking-tight">
          Malicious App Safety: Avoid Sideloading & OTP Stealers
        </h1>
        <p className="text-[#58677D] text-base sm:text-lg leading-relaxed max-w-3xl">
          APK files sent via WhatsApp, Telegram, or downloaded from unknown websites can hijack your phone, secretly intercept SMS banking OTPs, and compromise your personal accounts.
        </p>
      </header>

      {/* How Sideloading Scams Work */}
      <div className="bg-white border border-[#DCE3ED] rounded-[20px] p-6 sm:p-8 shadow-[0_4px_20px_rgba(24,43,73,0.04)]">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-[#FFF5E3] text-[#925500] flex items-center justify-center font-bold">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-[#182B49]">How Sideloading Scams Work</h2>
            <p className="text-xs text-[#58677D]">Scammers bypass app store security by asking you to install files manually</p>
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-5">
          <div className="bg-[#F6F8FB] p-5 rounded-[14px] border border-[#DCE3ED]">
            <div className="w-8 h-8 rounded-lg bg-white border border-[#DCE3ED] text-[#245CC5] flex items-center justify-center font-bold text-sm mb-3 shadow-xs">
              1
            </div>
            <h3 className="text-base font-bold text-[#182B49] mb-2">The Lure</h3>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Scammers send a message pretending to be a bank, electricity provider, or courier service, asking you to install an app to &ldquo;update KYC&rdquo; or &ldquo;claim a refund&rdquo;.
            </p>
          </div>
          
          <div className="bg-[#F6F8FB] p-5 rounded-[14px] border border-[#DCE3ED]">
            <div className="w-8 h-8 rounded-lg bg-white border border-[#DCE3ED] text-[#925500] flex items-center justify-center font-bold text-sm mb-3 shadow-xs">
              2
            </div>
            <h3 className="text-base font-bold text-[#182B49] mb-2">The Installation</h3>
            <p className="text-xs text-[#58677D] leading-relaxed">
              They send an <code className="bg-white px-1 py-0.5 rounded border border-[#DCE3ED] text-[#182B49] font-mono text-[11px]">.apk</code> file directly instead of a Google Play Store or Apple App Store link, prompting you to bypass Android security warnings.
            </p>
          </div>
          
          <div className="bg-[#F6F8FB] p-5 rounded-[14px] border border-[#DCE3ED]">
            <div className="w-8 h-8 rounded-lg bg-white border border-[#DCE3ED] text-[#B53232] flex items-center justify-center font-bold text-sm mb-3 shadow-xs">
              3
            </div>
            <h3 className="text-base font-bold text-[#182B49] mb-2">The Hijack</h3>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Once installed, the app requests SMS and Accessibility permissions. Scammers can now read incoming bank OTPs in the background and drain funds without your knowledge.
            </p>
          </div>
        </div>
      </div>

      {/* Prevention Guidelines */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-[#182B49]">Everyday Precautions for Your Phone</h2>
        
        <div className="grid gap-4">
          <div className="flex bg-white p-5 rounded-[16px] border border-[#DCE3ED] items-start gap-4 shadow-[0_2px_10px_rgba(24,43,73,0.03)]">
            <div className="w-9 h-9 rounded-xl bg-[#EAF6EF] text-[#18734D] flex items-center justify-center shrink-0 mt-0.5">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#182B49]">Install Apps Exclusively from Official Stores</h3>
              <p className="text-xs sm:text-sm text-[#58677D] mt-1 leading-relaxed">
                Never download or install apps sent via WhatsApp chats, Telegram channels, or SMS download links. Only install applications from Google Play Store or Apple App Store.
              </p>
            </div>
          </div>

          <div className="flex bg-white p-5 rounded-[16px] border border-[#DCE3ED] items-start gap-4 shadow-[0_2px_10px_rgba(24,43,73,0.03)]">
            <div className="w-9 h-9 rounded-xl bg-[#EAF6EF] text-[#18734D] flex items-center justify-center shrink-0 mt-0.5">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#182B49]">Keep &ldquo;Install Unknown Apps&rdquo; Disabled</h3>
              <p className="text-xs sm:text-sm text-[#58677D] mt-1 leading-relaxed">
                Keep this Android setting turned OFF at all times: <span className="font-semibold text-[#182B49]">Settings &gt; Apps &gt; Special App Access &gt; Install Unknown Apps</span>. Ensure WhatsApp and browsers do not have permission to install APKs.
              </p>
            </div>
          </div>

          <div className="flex bg-white p-5 rounded-[16px] border border-[#DCE3ED] items-start gap-4 shadow-[0_2px_10px_rgba(24,43,73,0.03)]">
            <div className="w-9 h-9 rounded-xl bg-[#EAF6EF] text-[#18734D] flex items-center justify-center shrink-0 mt-0.5">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#182B49]">Audit Critical Device Permissions</h3>
              <p className="text-xs sm:text-sm text-[#58677D] mt-1 leading-relaxed">
                Be extremely wary of apps requesting SMS reading, call forwarding, or Accessibility Services. Legitimate utilities almost never require full screen reading or SMS interception permissions.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Immediate Action Panel */}
      <div className="bg-[#FFF0EE] border border-[#F6C4BD] p-6 sm:p-7 rounded-[20px] shadow-[0_4px_16px_rgba(181,50,50,0.06)]">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-9 h-9 rounded-xl bg-[#B53232] text-white flex items-center justify-center font-bold shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-[#B53232]">Already installed a suspicious APK? Take these actions now:</h3>
        </div>
        
        <ol className="space-y-3 mt-4 text-xs sm:text-sm text-[#58677D]">
          <li className="flex items-start gap-3 bg-white/80 p-3.5 rounded-[12px] border border-[#F6C4BD]/60">
            <WifiOff className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
            <div>
              <strong className="text-[#182B49]">1. Turn on Airplane Mode immediately:</strong> Disconnecting from Wi-Fi and mobile data prevents the malware from transmitting captured OTPs or receiving remote commands.
            </div>
          </li>
          <li className="flex items-start gap-3 bg-white/80 p-3.5 rounded-[12px] border border-[#F6C4BD]/60">
            <Trash2 className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
            <div>
              <strong className="text-[#182B49]">2. Uninstall the suspicious app:</strong> Go to <span className="font-semibold text-[#182B49]">Settings &gt; Apps</span>, locate the newly downloaded APK, force stop it, and tap &ldquo;Uninstall&rdquo;.
            </div>
          </li>
          <li className="flex items-start gap-3 bg-white/80 p-3.5 rounded-[12px] border border-[#F6C4BD]/60">
            <PhoneCall className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
            <div>
              <strong className="text-[#182B49]">3. Call 1930 & contact your bank from another phone:</strong> Report that an unauthorized app may have intercepted your phone. Request immediate account freeze or UPI limit blocks.
            </div>
          </li>
        </ol>

        <div className="mt-5 pt-4 border-t border-[#F6C4BD] flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#B53232]">
            <span>Need emergency guidance right now?</span>
          </div>
          <Link
            href="/emergency"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#B53232] text-white text-xs font-bold hover:bg-[#9B2A2A] transition-colors"
          >
            Emergency 1930 Guide <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* Community Disclaimer */}
      <footer className="pt-4 border-t border-[#DCE3ED] flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-[#58677D] gap-3">
        <p>CLYRA Cyber Safety is a community guidance concept, not an official portal, emergency service or legal advisor.</p>
        <Link 
          href="/learn"
          className="text-[#245CC5] hover:underline font-semibold inline-flex items-center gap-1"
        >
          View all everyday safety lessons <ExternalLink className="w-3 h-3" />
        </Link>
      </footer>
    </div>
  );
}
