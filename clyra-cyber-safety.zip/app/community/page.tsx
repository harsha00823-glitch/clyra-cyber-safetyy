"use client";

import { useState } from "react";
import { Search, Lock } from "lucide-react";

interface Post {
  id: string;
  title: string;
  category: string;
  author: string;
  time: string;
  replies: number;
  body: string;
  moderatorReply?: {
    author: string;
    role: string;
    text: string;
  };
}

export default function CommunityPage() {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");

  const posts: Post[] = [
    {
      id: "upi-refund",
      title: "Do I need my UPI PIN to get a refund?",
      category: "Payments",
      author: "Anonymous",
      time: "Today · Illustrative post",
      replies: 6,
      body: "Someone called saying they would refund my shopping order and sent a collect request on PhonePe. The app asks for my UPI PIN. I haven’t entered it yet. What should I do?",
      moderatorReply: {
        author: "CLYRA moderator",
        role: "Verified role · Demo",
        text: "You did the right thing by pausing! You never need a UPI PIN to receive money. A collect request asks you to pay. Decline it immediately and check your refund in the official shopping app — not through any link sent by the caller.",
      },
    },
    {
      id: "parent-calls",
      title: "How do I talk to my parent about scam calls?",
      category: "Families",
      author: "Anonymous",
      time: "Today",
      replies: 4,
      body: "My elderly father almost transferred money yesterday after someone claiming to be police threatened to arrest him for an illegal parcel. How do I help him feel safe answering the phone?",
      moderatorReply: {
        author: "CLYRA moderator",
        role: "Verified role · Demo",
        text: "Remind him calmly that no Indian police officer or judge can arrest anyone over a phone call or Skype. Tell him to hang up immediately and call you first without hesitation or fear.",
      },
    },
    {
      id: "parcel-hold",
      title: "A message says my parcel is on hold for ₹25 address fee",
      category: "Messages",
      author: "Anonymous",
      time: "Yesterday",
      replies: 3,
      body: "Got an SMS from India Post saying parcel cannot be delivered without updating address at a strange link. Is this genuine?",
      moderatorReply: {
        author: "CLYRA moderator",
        role: "Verified role · Demo",
        text: "This is a widespread phishing tactic. India Post never sends SMS links asking for small payment updates to deliver parcels. Open indiapost.gov.in manually and check your real tracking number there.",
      },
    },
    {
      id: "work-email",
      title: "How can I verify an urgent email from work?",
      category: "At work",
      author: "Anonymous",
      time: "Yesterday",
      replies: 2,
      body: "Received an email from what looks like my manager asking for immediate gift cards or vendor account changes while they are in a meeting.",
      moderatorReply: {
        author: "CLYRA moderator",
        role: "Verified role · Demo",
        text: "Always verify through a separate, known channel — call or message your manager on their known phone number before processing any financial request.",
      },
    },
  ];

  const filteredPosts = posts.filter((p) => {
    const matchesCategory = activeCategory === "all" || p.category.toLowerCase().includes(activeCategory.toLowerCase());
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || p.body.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-2">
      {/* 1. Header (From Figma) */}
      <header className="space-y-2 text-left">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EDF3FF] border border-[#C5D8FD] text-[#245CC5] text-xs font-semibold">
          <span>COMMUNITY</span>
          <span>·</span>
          <span>Moderated peer support</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#182B49]">
          Ask a question. Leave private details out.
        </h1>
        <p className="text-sm text-[#58677D]">
          A calm space for everyday questions, practical guidance, and respectful peer support.
        </p>
      </header>

      {/* 2. Privacy Advisory Banner (From Figma) */}
      <div className="saathi-card p-4 bg-[#F6F8FB] border-[#DCE3ED] flex items-start gap-3 text-xs text-[#58677D]">
        <Lock className="w-4 h-4 text-[#245CC5] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <strong className="text-[#182B49] font-semibold block">
            Protect yourself and others before posting:
          </strong>
          <p className="leading-relaxed">
            Do not post OTPs, PINs, phone numbers, bank account numbers, identity documents, or transaction screenshots. This community is a peer guidance space, not an official reporting channel.
          </p>
        </div>
      </div>

      {/* 3. Search and Category Filters */}
      <div className="saathi-panel p-6 bg-white space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 text-xs overflow-x-auto pb-1 sm:pb-0">
            {["all", "payments", "families", "messages", "at work"].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 rounded-lg font-semibold capitalize transition-colors ${
                  activeCategory === cat
                    ? "bg-[#245CC5] text-white"
                    : "text-[#58677D] hover:bg-[#F6F8FB] border border-[#DCE3ED]"
                }`}
              >
                {cat === "all" ? "All topics" : cat}
              </button>
            ))}
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-[#58677D] absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search community questions..."
              className="w-full sm:w-60 bg-[#F6F8FB] border border-[#DCE3ED] rounded-lg pl-8 pr-3 py-2 text-xs text-[#182B49] focus:outline-none focus:ring-3 focus:ring-[#93B4F4]"
            />
          </div>
        </div>

        {/* Questions Feed */}
        <div className="space-y-4 pt-2">
          {filteredPosts.map((post) => (
            <div
              key={post.id}
              className="p-5 rounded-xl border border-[#DCE3ED] bg-[#F6F8FB] space-y-3 transition-colors hover:border-[#C5D8FD]"
            >
              <div className="flex items-center justify-between text-xs text-[#58677D]">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-[#245CC5] bg-white px-2 py-0.5 rounded border border-[#DCE3ED]">
                    {post.category}
                  </span>
                  <span>·</span>
                  <span>{post.author}</span>
                  <span>·</span>
                  <span>{post.time}</span>
                </div>
                <span>{post.replies} replies</span>
              </div>

              <div>
                <h3 className="font-bold text-sm text-[#182B49] mb-1">
                  {post.title}
                </h3>
                <p className="text-xs text-[#58677D] leading-relaxed">
                  {post.body}
                </p>
              </div>

              {/* Moderator Answer Card (From Figma Spec) */}
              {post.moderatorReply && (
                <div className="p-3.5 rounded-xl bg-white border border-[#DCE3ED] space-y-1.5 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#182B49]">
                      {post.moderatorReply.author}
                    </span>
                    <span className="text-[10px] font-bold text-[#18734D] bg-[#EAF6EF] px-2 py-0.2 rounded border border-[#C3E7D5]">
                      {post.moderatorReply.role}
                    </span>
                  </div>
                  <p className="text-[#182B49] leading-relaxed">
                    {post.moderatorReply.text}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 4. Honest Boundaries Disclaimer */}
      <div className="p-4 rounded-xl border border-[#DCE3ED] bg-white text-xs text-[#8B98A9] text-center space-y-1">
        <p>
          All discussions and replies shown are illustrative community guidance.
        </p>
        <p className="text-[11px]">
          CLYRA Cyber Safety is a community guidance concept, not an official emergency service or government portal.
        </p>
      </div>
    </div>
  );
}
