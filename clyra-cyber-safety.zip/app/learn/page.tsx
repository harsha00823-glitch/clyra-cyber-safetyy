"use client";

import Link from "next/link";
import { 
  Clock, 
  ArrowRight, 
  CheckCircle2
} from "lucide-react";

export default function LearnPage() {

  const lessons = [
    {
      id: "upi-pin",
      category: "Payments",
      time: "5 min",
      title: "UPI: receiving money never needs a PIN",
      description: "Understand collect requests, deceptive QR codes and 'refund' stories. Your UPI PIN only authorises money to leave your account.",
      status: "In progress",
      href: "#upi-detail",
    },
    {
      id: "phishing-rush",
      category: "Phishing",
      time: "4 min",
      title: "Spot a message that wants you to rush",
      description: "Pause when an SMS or WhatsApp threatens to block an account in 2 hours or cancel electricity tonight.",
      status: "New",
      href: "/digital-arrest",
    },
    {
      id: "account-safety",
      category: "Account safety",
      time: "6 min",
      title: "Take back an account safely",
      description: "Learn where to reset a compromised password, review signed-in devices, and enable 2-step verification securely.",
      status: "New",
      href: "/malicious-apps",
    },
    {
      id: "families",
      category: "For families",
      time: "7 min",
      title: "A family conversation about online safety",
      description: "Help children and parents ask for help without fear, blame, or shame when something unexpected happens.",
      status: "New",
      href: "/quiz",
    },
    {
      id: "workday",
      category: "At work",
      time: "5 min",
      title: "A safer workday, one habit at a time",
      description: "Verify unusual requests for urgent wire transfers, vendor invoice changes, and remote-access app installation.",
      status: "New",
      href: "#",
    },
    {
      id: "recovery-records",
      category: "Recovery",
      time: "4 min",
      title: "What to save when something goes wrong",
      description: "Keep useful payment receipts and timestamps privately while leaving private details out of public discussions.",
      status: "New",
      href: "/report",
    },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-10 py-2">
      {/* 1. Header (From Figma) */}
      <header className="space-y-2 text-left">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EDF3FF] border border-[#C5D8FD] text-[#245CC5] text-xs font-semibold">
          <span>LEARN</span>
          <span>·</span>
          <span>Everyday digital safety</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#182B49]">
          Confidence grows with a little practice.
        </h1>
        <p className="text-sm text-[#58677D]">
          Short, practical lessons for you, your family, and your everyday work.
        </p>
      </header>

      {/* 2. Continue Learning Featured Card (From Figma) */}
      <div className="saathi-panel p-6 sm:p-8 bg-white border-[#C5D8FD] space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-[#245CC5] uppercase tracking-wider">
            CONTINUE LEARNING · Part 2 of 3 · About 3 minutes left
          </span>
          <span className="text-xs text-[#58677D] font-medium">5-minute lesson</span>
        </div>

        <div className="space-y-2">
          <h2 className="text-xl sm:text-2xl font-bold text-[#182B49]">
            UPI: receiving money never needs your PIN
          </h2>
          <p className="text-xs sm:text-sm text-[#58677D] leading-relaxed max-w-2xl">
            A simple rule that helps you recognise a common refund scam: Your UPI PIN authorises money to leave your account. You do not need to enter it to receive a payment.
          </p>
        </div>

        {/* 3 Step Rule Visual (From Figma Spec) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-xs">
          <div className="p-3.5 rounded-xl border border-[#DCE3ED] bg-[#F6F8FB] space-y-1">
            <span className="font-bold text-[#245CC5] block">1 · Know the PIN rule</span>
            <p className="text-[#58677D]">
              Entering your UPI PIN means authorising a payment. If a screen asks for your PIN, money will be debited.
            </p>
          </div>

          <div className="p-3.5 rounded-xl border border-[#DCE3ED] bg-[#F6F8FB] space-y-1">
            <span className="font-bold text-[#245CC5] block">2 · Spot the refund story</span>
            <p className="text-[#58677D]">
              &ldquo;I’ll refund your order. Just scan this QR code and enter your PIN to receive ₹2,000.&rdquo; — This is always a debit request.
            </p>
          </div>

          <div className="p-3.5 rounded-xl border border-[#DCE3ED] bg-[#F6F8FB] space-y-1">
            <span className="font-bold text-[#245CC5] block">3 · Verify before you pay</span>
            <p className="text-[#58677D]">
              Check credit balances in your bank app. Legitimate refunds credit your account automatically without any action.
            </p>
          </div>
        </div>

        <div className="pt-2 flex items-center justify-between border-t border-[#DCE3ED]">
          <span className="text-xs text-[#18734D] font-semibold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" />
            <span>Rule: To receive money, I never enter my UPI PIN.</span>
          </span>

          <Link
            href="/quiz"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#245CC5] hover:bg-[#19489F] text-white text-xs font-semibold shadow-xs"
          >
            <span>Test this in Quiz</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* 3. Explore the Essentials: 6 Lessons Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-[#182B49]">
              Explore the essentials · 6 lessons
            </h3>
            <p className="text-xs text-[#58677D]">
              Practical safety habits for payments, messaging, family, and work.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {lessons.map((lesson) => (
            <div
              key={lesson.id}
              className="saathi-card p-5 bg-white flex flex-col justify-between space-y-4 hover:border-[#245CC5] transition-colors"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-[#245CC5] uppercase tracking-wider text-[11px]">
                    {lesson.category}
                  </span>
                  <span className="text-[#58677D] text-[11px] flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{lesson.time}</span>
                  </span>
                </div>

                <h4 className="font-bold text-[#182B49] text-sm leading-snug">
                  {lesson.title}
                </h4>

                <p className="text-xs text-[#58677D] leading-relaxed">
                  {lesson.description}
                </p>
              </div>

              <div className="pt-2 border-t border-[#DCE3ED] flex items-center justify-between text-xs">
                <Link
                  href={lesson.href}
                  className="font-semibold text-[#245CC5] hover:underline flex items-center gap-1"
                >
                  <span>Start lesson</span>
                  <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Family Safety & Knowledge Test */}
      <section className="saathi-card p-6 bg-[#F6F8FB] border-[#DCE3ED] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1">
          <h4 className="text-sm font-bold text-[#182B49]">
            Want to test what you’ve learned?
          </h4>
          <p className="text-xs text-[#58677D]">
            Take the 4-part interactive safety habit assessment to practice spotting real-world scam lures.
          </p>
        </div>

        <Link
          href="/quiz"
          className="px-5 py-2.5 rounded-lg bg-[#245CC5] hover:bg-[#19489F] text-white text-xs font-semibold shadow-xs shrink-0"
        >
          Take habit assessment →
        </Link>
      </section>
    </div>
  );
}
