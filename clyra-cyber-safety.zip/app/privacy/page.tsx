import Link from "next/link";
import { ShieldCheck, EyeOff, Cpu, Lock, Scale, ArrowRight } from "lucide-react";

export default function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto py-10 px-4 sm:px-6 space-y-8">
      {/* Category Header */}
      <header className="space-y-2 border-b border-[#DCE3ED] pb-6">
        <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#245CC5]">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>GUIDANCE / PRIVACY &amp; DATA TRANSPARENCY</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#182B49] tracking-tight">
          Privacy Notice: How CLYRA Protects What You Share
        </h1>
        <p className="text-[#58677D] text-sm sm:text-base leading-relaxed max-w-2xl">
          Honest boundaries and on-device processing. Seeking help after a scary digital encounter should never compromise your personal privacy.
        </p>
      </header>
      
      {/* Privacy Commitments Grid */}
      <div className="space-y-6">
        {/* Section 1 */}
        <section className="bg-white border border-[#DCE3ED] rounded-[18px] p-6 shadow-[0_2px_12px_rgba(24,43,73,0.03)] space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#245CC5] flex items-center justify-center shrink-0">
              <EyeOff className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-[#182B49]">1. No Sign-In Needed to Check a Threat</h2>
          </div>
          <p className="text-xs sm:text-sm text-[#58677D] leading-relaxed pl-12">
            You can verify suspicious SMS messages, WhatsApp copy, or suspicious links without registering or creating an account. We process threat queries ephemerally so you can make informed decisions immediately.
          </p>
        </section>

        {/* Section 2 */}
        <section className="bg-white border border-[#DCE3ED] rounded-[18px] p-6 shadow-[0_2px_12px_rgba(24,43,73,0.03)] space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#EAF6EF] text-[#18734D] flex items-center justify-center shrink-0">
              <Cpu className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-[#182B49]">2. Screenshot Analysis: On-Device Processing</h2>
          </div>
          <p className="text-xs sm:text-sm text-[#58677D] leading-relaxed pl-12">
            When you check a screenshot, <strong className="text-[#182B49]">your image never leaves your phone or browser</strong>. We run WebAssembly-based Optical Character Recognition (OCR) locally on your device. Only extracted, redacted text snippets are evaluated against our pattern detection rules.
          </p>
        </section>

        {/* Section 3 */}
        <section className="bg-white border border-[#DCE3ED] rounded-[18px] p-6 shadow-[0_2px_12px_rgba(24,43,73,0.03)] space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#FFF5E3] text-[#925500] flex items-center justify-center shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-[#182B49]">3. Automated Redaction of Sensitive Details</h2>
          </div>
          <p className="text-xs sm:text-sm text-[#58677D] leading-relaxed pl-12">
            Before text is analyzed or saved to your personal recovery checklist, our safety filter automatically masks confidential credentials including 6-digit OTP codes, UPI PINs, Aadhaar numbers, and bank account sequences.
          </p>
        </section>

        {/* Section 4 */}
        <section className="bg-white border border-[#DCE3ED] rounded-[18px] p-6 shadow-[0_2px_12px_rgba(24,43,73,0.03)] space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-[#182B49]">4. Isolated Personal Recovery Tracking</h2>
          </div>
          <p className="text-xs sm:text-sm text-[#58677D] leading-relaxed pl-12">
            When you sign in to maintain a recovery timeline or compile an incident report summary, all checklists and notes are secured using Row Level Security (RLS). No third parties or community members can inspect your personal records.
          </p>
        </section>

        {/* Section 5 */}
        <section className="bg-white border border-[#DCE3ED] rounded-[18px] p-6 shadow-[0_2px_12px_rgba(24,43,73,0.03)] space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#FFF0EE] text-[#B53232] flex items-center justify-center shrink-0">
              <Scale className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-[#182B49]">5. Honest Civic Boundaries &amp; Reporting Disclaimer</h2>
          </div>
          <p className="text-xs sm:text-sm text-[#58677D] leading-relaxed pl-12">
            CLYRA Cyber Safety is a community guidance concept. We are not a police station, investigative agency, bank, or court. While our tool helps you organize evidence and print an incident summary dossier, legal complaints must be submitted directly through the official National Cyber Crime Reporting Portal (<a href="https://cybercrime.gov.in" target="_blank" rel="noopener noreferrer" className="text-[#245CC5] underline font-medium">cybercrime.gov.in</a>) or by calling <span className="font-bold text-[#B53232]">1930</span>.
          </p>
        </section>
      </div>

      {/* Footer navigation */}
      <div className="pt-4 border-t border-[#DCE3ED] flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-xs text-[#58677D]">
          CLYRA Cyber Safety · Detect. Understand. Protect.
        </p>
        <Link
          href="/analyze"
          className="inline-flex items-center gap-2 text-xs font-bold text-[#245CC5] hover:underline"
        >
          Return to threat check <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
}
