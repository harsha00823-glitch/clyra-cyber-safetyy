"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  Award, 
  ArrowRight, 
  RotateCcw, 
  BookOpen, 
  ShieldCheck 
} from "lucide-react";

const QUIZ_QUESTIONS = [
  {
    id: 1,
    question: "You receive a video call on WhatsApp from an unknown number showing a person in police uniform claiming you are under 'Digital Arrest' for money laundering. What is the safest next step?",
    options: [
      { id: "a", text: "Stay on the video call to prove your innocence and show your documents." },
      { id: "b", text: "Transfer a security deposit to their 'court verification account' to avoid arrest." },
      { id: "c", text: "Disconnect the call immediately. Indian police and courts do not conduct arrests over video calls." },
      { id: "d", text: "Ask them to send the FIR notice over WhatsApp before paying." }
    ],
    correctOptionId: "c",
    explanation: "Indian law and law enforcement agencies (CBI, ED, Police) do not conduct arrests or trial hearings over Skype or WhatsApp video calls. Genuine police notices are served in person or by physical legal post under Section 41A of BNSS."
  },
  {
    id: 2,
    question: "You receive an SMS: 'Dear Customer, your electricity connection will be disconnected tonight at 9:30 PM due to unpaid dues. Call our officer immediately on 9876543210.' How should you handle this?",
    options: [
      { id: "a", text: "Call the phone number provided right away to avoid losing power." },
      { id: "b", text: "Do not call the number. Open your electricity board's official app or portal manually to check your bill status." },
      { id: "c", text: "Download the APK file the caller sends you to pay the pending bill." },
      { id: "d", text: "Reply to the SMS with your 10-digit consumer account ID." }
    ],
    correctOptionId: "b",
    explanation: "Power utility providers send official bill statements through registered company SMS headers with consumer numbers, never urgent threats from personal 10-digit mobile numbers asking you to call someone directly."
  },
  {
    id: 3,
    question: "You are waiting for a delivery and receive an SMS with a link: 'https://india-post-tracking-service.net/track'. Is it safe to enter your phone number and OTP?",
    options: [
      { id: "a", text: "Yes, because the website address contains 'india-post'." },
      { id: "b", text: "Yes, because the address starts with https:// (the padlock icon)." },
      { id: "c", text: "No, this is a deceptive look-alike URL. The official portal is indiapost.gov.in." },
      { id: "d", text: "Yes, standard delivery redelivery fee is only ₹5." }
    ],
    correctOptionId: "c",
    explanation: "Scammers register fake lookalike web domains. India Post is a government department with the official website domain 'indiapost.gov.in'. The small ₹5 fee is a trick to collect your card details and steal large sums."
  },
  {
    id: 4,
    question: "A stranger contacts you on Telegram offering work-from-home earnings of ₹3,000/day for liking YouTube videos. They pay you ₹150 for the first task, then ask you to deposit ₹2,000 for a 'prepaid VIP task'. This is:",
    options: [
      { id: "a", text: "A legitimate digital marketing freelance opportunity." },
      { id: "b", text: "A standard refundable corporate onboarding deposit." },
      { id: "c", text: "A Task/Prepaid scam designed to gain trust with small payouts before stealing larger amounts." },
      { id: "d", text: "An approved cryptocurrency investment trial." }
    ],
    correctOptionId: "c",
    explanation: "Prepaid task scams hook victims by transferring nominal amounts (₹100–₹200) initially to establish trust, then pressure victims into transferring thousands or lakhs of rupees under the guise of higher-tier tasks."
  }
];

export default function QuizPage() {
  const router = useRouter();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [quizComplete, setQuizComplete] = useState(false);

  const question = QUIZ_QUESTIONS[currentQuestionIndex];

  const handleOptionSelect = (optionId: string) => {
    if (!isSubmitted) {
      setSelectedOption(optionId);
    }
  };

  const handleSubmit = () => {
    if (!selectedOption) return;
    
    setIsSubmitted(true);
    if (selectedOption === question.correctOptionId) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < QUIZ_QUESTIONS.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedOption(null);
      setIsSubmitted(false);
    } else {
      setQuizComplete(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedOption(null);
    setIsSubmitted(false);
    setScore(0);
    setQuizComplete(false);
  };

  if (quizComplete) {
    const percentage = Math.round((score / QUIZ_QUESTIONS.length) * 100);
    return (
      <div className="max-w-3xl mx-auto py-12 px-4 sm:px-6 space-y-8">
        <header className="text-center space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAF6EF] text-[#18734D] text-xs font-semibold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Check Complete</span>
          </div>
          <h1 className="text-3xl font-extrabold text-[#182B49]">Your Safety Habits Score</h1>
          <p className="text-[#58677D] text-sm">Clear guidance. No judgment. One step at a time.</p>
        </header>

        <div className="bg-white border border-[#DCE3ED] p-8 sm:p-10 rounded-[20px] shadow-[0_4px_20px_rgba(24,43,73,0.05)] text-center space-y-6">
          <div className="w-20 h-20 rounded-2xl bg-[#F6F8FB] border border-[#DCE3ED] flex items-center justify-center mx-auto text-[#245CC5]">
            <Award className="w-10 h-10" />
          </div>

          <div>
            <div className="text-4xl font-extrabold text-[#182B49] mb-1">
              {score} / {QUIZ_QUESTIONS.length}
            </div>
            <p className="text-sm font-semibold text-[#245CC5]">{percentage}% Awareness Score</p>
          </div>

          <p className="text-sm text-[#58677D] max-w-md mx-auto leading-relaxed">
            {percentage === 100 
              ? "Excellent instinct! You recognize high-risk pressure tactics, fake domains, and impersonation attempts with high clarity." 
              : "Great effort! Staying safer online is about small daily habits. Review our everyday lessons to strengthen your instincts further."}
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-3 pt-2">
            <Button onClick={resetQuiz} variant="secondary" className="gap-2">
              <RotateCcw className="w-4 h-4" /> Try Again
            </Button>
            <Button onClick={() => router.push('/learn')} variant="primary" className="gap-2">
              <BookOpen className="w-4 h-4" /> Everyday Safety Lessons
            </Button>
          </div>
        </div>

        <div className="text-center text-xs text-[#58677D]">
          CLYRA Cyber Safety is a community guidance concept, not an official portal, emergency service or legal advisor.
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto py-8 px-4 sm:px-6 space-y-8">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-end justify-between border-b border-[#DCE3ED] pb-4 gap-2">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-wider uppercase text-[#245CC5] mb-1">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>LEARN / INTERACTIVE SAFETY CHECK</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#182B49] tracking-tight">
            Safety Habits Check
          </h1>
          <p className="text-xs sm:text-sm text-[#58677D]">
            Test your instinct against common digital scam scenarios.
          </p>
        </div>
        <div className="inline-flex items-center px-3 py-1 rounded-full bg-[#F6F8FB] border border-[#DCE3ED] text-xs font-bold text-[#182B49]">
          Question {currentQuestionIndex + 1} of {QUIZ_QUESTIONS.length}
        </div>
      </header>

      {/* Question Card */}
      <div className="bg-white border border-[#DCE3ED] p-6 sm:p-8 rounded-[20px] shadow-[0_4px_20px_rgba(24,43,73,0.04)] space-y-6">
        <h2 className="text-lg sm:text-xl font-bold text-[#182B49] leading-relaxed">
          {question.question}
        </h2>

        {/* Options */}
        <div className="space-y-3">
          {question.options.map((option) => {
            let itemClass = "border-[#DCE3ED] bg-[#F6F8FB] text-[#182B49] hover:border-[#245CC5] hover:bg-white cursor-pointer";
            
            if (selectedOption === option.id) {
              itemClass = "border-[#245CC5] bg-blue-50/50 text-[#182B49] ring-2 ring-[#245CC5]";
            }
            
            if (isSubmitted) {
              if (option.id === question.correctOptionId) {
                itemClass = "border-[#18734D] bg-[#EAF6EF] text-[#18734D] ring-2 ring-[#18734D]";
              } else if (selectedOption === option.id && selectedOption !== question.correctOptionId) {
                itemClass = "border-[#B53232] bg-[#FFF0EE] text-[#B53232]";
              } else {
                itemClass = "border-[#DCE3ED] bg-[#F6F8FB]/50 text-[#8B98A9] opacity-60 cursor-default";
              }
            }

            return (
              <div
                key={option.id}
                onClick={() => handleOptionSelect(option.id)}
                className={`p-4 border rounded-[14px] transition-all flex items-start gap-3 ${itemClass}`}
              >
                <span className="w-6 h-6 rounded-md bg-white border border-[#DCE3ED] text-[#182B49] text-xs font-bold flex items-center justify-center shrink-0 mt-0.5 uppercase shadow-xs">
                  {option.id}
                </span>
                <span className="text-xs sm:text-sm font-medium leading-relaxed flex-1">
                  {option.text}
                </span>
                
                {isSubmitted && option.id === question.correctOptionId && (
                  <CheckCircle2 className="w-5 h-5 text-[#18734D] shrink-0 mt-0.5" />
                )}
                {isSubmitted && selectedOption === option.id && selectedOption !== question.correctOptionId && (
                  <XCircle className="w-5 h-5 text-[#B53232] shrink-0 mt-0.5" />
                )}
              </div>
            );
          })}
        </div>

        {/* Explanation */}
        {isSubmitted && (
          <div className={`p-4 sm:p-5 rounded-[14px] border ${
            selectedOption === question.correctOptionId 
              ? "bg-[#EAF6EF] border-[#B8E2CB] text-[#18734D]" 
              : "bg-[#FFF5E3] border-[#F6DCA8] text-[#925500]"
          }`}>
            <h4 className="text-sm font-bold mb-1 flex items-center gap-1.5">
              {selectedOption === question.correctOptionId ? (
                <>
                  <CheckCircle2 className="w-4 h-4" /> Correct reasoning!
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" /> Key safety insight:
                </>
              )}
            </h4>
            <p className="text-xs sm:text-sm leading-relaxed text-[#182B49]">
              {question.explanation}
            </p>
          </div>
        )}

        {/* Action Button */}
        <div className="flex justify-between items-center pt-2 border-t border-[#DCE3ED]">
          <Link
            href="/learn"
            className="text-xs font-semibold text-[#58677D] hover:text-[#182B49]"
          >
            ← Exit to Safety Lessons
          </Link>

          {!isSubmitted ? (
            <Button onClick={handleSubmit} disabled={!selectedOption} variant="primary">
              Check Answer
            </Button>
          ) : (
            <Button onClick={handleNext} variant="primary" className="gap-2">
              {currentQuestionIndex < QUIZ_QUESTIONS.length - 1 ? (
                <>Next Question <ArrowRight className="w-4 h-4" /></>
              ) : (
                <>Finish Check <ArrowRight className="w-4 h-4" /></>
              )}
            </Button>
          )}
        </div>
      </div>

      {/* Bottom disclaimer */}
      <p className="text-center text-xs text-[#58677D]">
        CLYRA Cyber Safety is a community guidance concept, not an official portal, emergency service or legal advisor.
      </p>
    </div>
  );
}
