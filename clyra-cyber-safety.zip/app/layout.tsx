import type { Metadata } from "next";
import { cookies } from "next/headers";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import PageContainer from "@/components/layout/PageContainer";
import { createClient } from "@/lib/supabase/server";
import "./globals.css";

export const metadata: Metadata = {
  title: "CLYRA — Detect. Understand. Protect | Cyber Safety",
  description:
    "Detect suspicious messages, understand cyber threats in plain language, and protect yourself. CLYRA: Detect. Understand. Protect.",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  // If no Supabase user, check demo session cookie
  const cookieStore = await cookies();
  const demoCookie = cookieStore.get("csp_demo_session")?.value;
  
  let activeUser = user;
  if (!activeUser && demoCookie === "true") {
    activeUser = {
      id: "demo-clyra-user",
      email: "asha@clyra.community",
      app_metadata: {},
      user_metadata: { display_name: "Asha Sharma" },
      aud: "authenticated",
      created_at: "2026-10-04T12:00:00.000Z",
    } as unknown as import("@supabase/supabase-js").User;
  }

  return (
    <html lang="en" className="h-full">
      <body className="min-h-full flex flex-col bg-[#F6F8FB] text-[#182B49] font-sans antialiased">
        <Navbar user={activeUser} />
        <PageContainer>{children}</PageContainer>
        <Footer />
      </body>
    </html>
  );
}
