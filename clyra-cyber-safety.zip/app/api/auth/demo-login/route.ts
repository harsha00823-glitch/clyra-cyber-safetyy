import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function POST() {
  const cookieStore = await cookies();
  cookieStore.set("csp_demo_session", "true", {
    path: "/",
    httpOnly: false,
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7, // 7 days
  });

  return NextResponse.json({
    success: true,
    user: {
      id: "demo-sec-analyst",
      email: "analyst@cybersafety.defense",
      displayName: "Security Operations Analyst",
      role: "admin",
    },
  });
}
