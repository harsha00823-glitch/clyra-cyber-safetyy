import { NextResponse } from 'next/server';
import { analyzeContent } from '@/lib/analysis/engine';
import { persistAnalysisSession } from '@/lib/supabase/service';
import { createClient } from '@/lib/supabase/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { text } = body;

    if (!text || typeof text !== 'string') {
      return NextResponse.json({ error: 'Invalid input text' }, { status: 400 });
    }

    if (text.length > 5000) {
      return NextResponse.json({ error: 'Input text exceeds maximum length of 5000 characters' }, { status: 400 });
    }

    // Process analysis
    const result = analyzeContent(text, 'message');

    // Attempt to identify user for history persistence
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    // Persist analysis asynchronously (fire-and-forget for performance, or await if needed)
    // We await here to get the generated session ID back if it worked
    const persistenceResult = await persistAnalysisSession(result, text, user?.id);

    // Return structured result augmented with persistence ID
    return NextResponse.json({
      ...result,
      id: persistenceResult.sessionId || undefined,
      _persistenceNote: persistenceResult.note,
    });
  } catch (error) {
    console.error('Analysis API Error:', error);
    return NextResponse.json({ error: 'Internal server error during analysis' }, { status: 500 });
  }
}
