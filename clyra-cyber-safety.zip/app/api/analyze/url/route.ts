import { NextResponse } from 'next/server';
import { analyzeContent } from '@/lib/analysis/engine';
import { persistAnalysisSession } from '@/lib/supabase/service';
import { createClient } from '@/lib/supabase/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { url } = body;

    if (!url || typeof url !== 'string') {
      return NextResponse.json({ error: 'Invalid URL input' }, { status: 400 });
    }

    if (url.length > 2000) {
      return NextResponse.json({ error: 'URL exceeds maximum length of 2000 characters' }, { status: 400 });
    }

    // Process analysis
    const result = analyzeContent(url, 'url');

    // Attempt to identify user for history persistence
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    // Persist analysis
    const persistenceResult = await persistAnalysisSession(result, url, user?.id);

    return NextResponse.json({
      ...result,
      id: persistenceResult.sessionId || undefined,
      _persistenceNote: persistenceResult.note,
    });
  } catch (error) {
    console.error('URL Analysis API Error:', error);
    return NextResponse.json({ error: 'Internal server error during URL analysis' }, { status: 500 });
  }
}
