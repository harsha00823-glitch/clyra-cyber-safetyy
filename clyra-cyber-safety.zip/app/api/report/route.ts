import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { analysisId, additionalNotes, incidentDate } = body;

    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    // In a real app we'd fetch the analysis details from Supabase using the analysisId.
    // For this demonstration, we'll build a structured JSON report payload.
    let originalInput = "Not provided";
    let riskLevel = "Unknown";
    let score = 0;

    if (analysisId) {
      // Use service role if you want to bypass RLS, or let the user fetch their own.
      // Since it's a generated report for the user, they must own it (unless it's public).
      const { data: analysis } = await supabase
        .from('analysis_sessions')
        .select('*')
        .eq('id', analysisId)
        .single();
      
      if (analysis) {
        // Obfuscate slightly for the report if needed, though they own it.
        originalInput = analysis.input_preview || (analysis as Record<string, unknown>).original_input || "Redacted snippet";
        riskLevel = analysis.risk_level;
        score = analysis.risk_score;
      }
    }

    const reportContent = {
      referenceNumber: `CYB-RPT-${Math.floor(Date.now() / 1000)}`,
      generatedAt: new Date().toISOString(),
      user: user ? user.email : 'Anonymous / Unauthenticated',
      incidentDetails: {
        dateOfIncident: incidentDate || new Date().toISOString().split('T')[0],
        suspiciousContent: originalInput,
        automatedRiskAssessment: {
          level: riskLevel,
          score: score,
        },
        userNotes: additionalNotes || 'None provided',
      },
      nextSteps: [
        "Do not engage with the sender or click any remaining links.",
        "If financial details were shared, contact your bank immediately.",
        "Preserve original messages/emails for potential law enforcement review.",
        "Consider filing an official complaint with the National Cyber Crime Reporting Portal (cybercrime.gov.in) if financial loss occurred."
      ]
    };

    return NextResponse.json({ report: reportContent });
  } catch (error) {
    console.error('Report API Error:', error);
    return NextResponse.json({ error: 'Internal server error while generating report' }, { status: 500 });
  }
}
