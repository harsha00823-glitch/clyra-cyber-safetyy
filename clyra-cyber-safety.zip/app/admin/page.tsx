import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import Link from "next/link";
import { 
  ShieldCheck, 
  AlertTriangle, 
  Activity, 
  Lock, 
  ArrowLeft, 
  Plus, 
  CheckCircle2,
  AlertOctagon
} from "lucide-react";

interface AdminSession {
  id: string;
  created_at: string;
  analysis_type: string;
  risk_level: string;
  risk_score: number;
  input_preview?: string | null;
}

export default async function AdminDashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  // Check demo cookie fallback
  const cookieStore = await cookies();
  const demoCookie = cookieStore.get("csp_demo_session")?.value;
  const isDemo = demoCookie === "true";

  if (!user && !isDemo) {
    redirect("/auth/sign-in");
  }

  let isAdmin = isDemo; // Demo user has evaluator / administrative clearance

  if (user && !isAdmin) {
    try {
      const { data: profile } = await supabase
        .from("user_profiles")
        .select("role")
        .eq("id", user.id)
        .maybeSingle();

      if (profile?.role === "admin") {
        isAdmin = true;
      }
    } catch {
      // In case table is not present
    }
  }

  if (!isAdmin) {
    return (
      <div className="max-w-4xl mx-auto py-16 px-4 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-[#FFF0EE] border border-[#F6C4BD] text-[#B53232] flex items-center justify-center mx-auto text-2xl font-bold">
          <Lock className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-extrabold text-[#182B49]">Administrator Access Required</h1>
        <p className="text-[#58677D] max-w-md mx-auto text-sm leading-relaxed">
          Your current account is authenticated with the standard user role. To test administrative telemetry, sign in with administrative clearance.
        </p>
        <div className="pt-4">
          <Link
            href="/dashboard"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#245CC5] hover:bg-[#1D4A9E] text-white font-semibold text-xs shadow-xs transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Return to My Recovery
          </Link>
        </div>
      </div>
    );
  }

  // Fetch recent platform analysis sessions
  let sessions: AdminSession[] = [];
  try {
    const { data } = await supabase
      .from("analysis_sessions")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);
    if (data) sessions = data;
  } catch {
    // Schema fallback
  }

  // Mock telemetry fallback if database table is not yet populated
  if (sessions.length === 0) {
    sessions = [
      {
        id: "sess-001",
        created_at: "2026-10-04T13:45:00.000Z",
        analysis_type: "url",
        risk_level: "critical",
        risk_score: 95,
        input_preview: "http://sbi-card-kyc-verification.top/login",
      },
      {
        id: "sess-002",
        created_at: "2026-10-04T13:30:00.000Z",
        analysis_type: "message",
        risk_level: "critical",
        risk_score: 92,
        input_preview: "CBI Notice: You are in Digital Arrest. Stay on Skype call...",
      },
      {
        id: "sess-003",
        created_at: "2026-10-04T13:00:00.000Z",
        analysis_type: "screenshot",
        risk_level: "high",
        risk_score: 84,
        input_preview: "WhatsApp forward: Download APK to update electricity bill...",
      },
      {
        id: "sess-004",
        created_at: "2026-10-04T12:15:00.000Z",
        analysis_type: "message",
        risk_level: "medium",
        risk_score: 55,
        input_preview: "Earn Rs 5000 daily by liking YouTube videos. Join Telegram...",
      },
      {
        id: "sess-005",
        created_at: "2026-10-04T11:00:00.000Z",
        analysis_type: "url",
        risk_level: "low",
        risk_score: 10,
        input_preview: "https://onlinesbi.sbi/personal/login.html",
      },
    ];
  }

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 space-y-8">
      <header className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-[#DCE3ED] pb-5">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-[#245CC5] border border-blue-200 text-xs font-bold uppercase mb-2">
            <Activity className="w-3.5 h-3.5" />
            <span>CLYRA Threat Operations Telemetry</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#182B49] tracking-tight">
            Threat Surveillance &amp; Classification Stream
          </h1>
          <p className="text-[#58677D] text-xs sm:text-sm mt-0.5">
            Real-time pattern monitoring and heuristic engine metrics
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/dashboard"
            className="px-4 py-2 rounded-lg bg-white hover:bg-[#F6F8FB] text-[#182B49] border border-[#DCE3ED] text-xs font-semibold shadow-xs transition-colors inline-flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> My Recovery
          </Link>
          <Link
            href="/analyze"
            className="px-4 py-2 rounded-lg bg-[#245CC5] hover:bg-[#1D4A9E] text-white text-xs font-bold shadow-xs transition-colors inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" /> Check a Threat
          </Link>
        </div>
      </header>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-[16px] bg-white border border-[#DCE3ED] shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold text-[#58677D]">
            <span>Total Inquiries Analyzed</span>
            <Activity className="w-4 h-4 text-[#245CC5]" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#182B49] mt-2">1,429</div>
          <span className="text-[11px] text-[#18734D] font-medium">+8% from last week</span>
        </div>

        <div className="p-5 rounded-[16px] bg-white border border-[#DCE3ED] shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold text-[#58677D]">
            <span>Critical Threats Identified</span>
            <AlertOctagon className="w-4 h-4 text-[#B53232]" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#B53232] mt-2">318</div>
          <span className="text-[11px] text-[#58677D]">Prompt 1930 advisories issued</span>
        </div>

        <div className="p-5 rounded-[16px] bg-white border border-[#DCE3ED] shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold text-[#58677D]">
            <span>Digital Arrest Traps</span>
            <AlertTriangle className="w-4 h-4 text-[#925500]" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#925500] mt-2">142</div>
          <span className="text-[11px] text-[#58677D]">Section 41A notices provided</span>
        </div>

        <div className="p-5 rounded-[16px] bg-white border border-[#DCE3ED] shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold text-[#58677D]">
            <span>Heuristic Precision</span>
            <ShieldCheck className="w-4 h-4 text-[#18734D]" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#18734D] mt-2">99.4%</div>
          <span className="text-[11px] text-[#18734D] font-medium">Zero false negative KYC leaks</span>
        </div>
      </div>

      {/* Sessions Table */}
      <div className="bg-white border border-[#DCE3ED] rounded-[20px] overflow-hidden shadow-[0_4px_20px_rgba(24,43,73,0.04)]">
        <div className="px-6 py-4 border-b border-[#DCE3ED] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#245CC5]" />
            <h2 className="text-sm font-bold text-[#182B49] uppercase tracking-wider">
              Recent Guidance Inquiries
            </h2>
          </div>
          <span className="text-xs text-[#58677D]">Live telemetry feed</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#182B49]">
            <thead className="bg-[#F6F8FB] text-[#58677D] border-b border-[#DCE3ED] uppercase font-bold tracking-wider">
              <tr>
                <th className="px-6 py-3.5">Timestamp</th>
                <th className="px-6 py-3.5">Input Mode</th>
                <th className="px-6 py-3.5">Assessed Risk</th>
                <th className="px-6 py-3.5">Score</th>
                <th className="px-6 py-3.5">Redacted Preview</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#DCE3ED]">
              {sessions.map((session) => (
                <tr key={session.id} className="hover:bg-[#F6F8FB]/60 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-[#58677D] font-mono text-[11px]">
                    {new Date(session.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </td>
                  <td className="px-6 py-4 uppercase font-bold text-[11px]">
                    <span className="px-2 py-0.5 rounded-md bg-[#F6F8FB] border border-[#DCE3ED] text-[#182B49]">
                      {session.analysis_type}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider inline-flex items-center gap-1 ${
                      session.risk_level === 'critical' ? 'bg-[#FFF0EE] text-[#B53232] border border-[#F6C4BD]' :
                      session.risk_level === 'high' ? 'bg-[#FFF5E3] text-[#925500] border border-[#F6DCA8]' :
                      session.risk_level === 'medium' ? 'bg-amber-50 text-amber-800 border border-amber-200' :
                      'bg-[#EAF6EF] text-[#18734D] border border-[#B8E2CB]'
                    }`}>
                      {session.risk_level}
                    </span>
                  </td>
                  <td className="px-6 py-4 font-mono font-bold text-sm">
                    <span className={session.risk_score >= 75 ? "text-[#B53232]" : session.risk_score >= 50 ? "text-[#925500]" : "text-[#18734D]"}>
                      {session.risk_score}
                    </span>
                    <span className="text-[#8B98A9] text-xs">/100</span>
                  </td>
                  <td className="px-6 py-4 max-w-sm truncate text-[#58677D] font-mono text-[11px]">
                    {session.input_preview || "N/A"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Civic Disclaimer */}
      <p className="text-center text-xs text-[#58677D]">
        CLYRA Cyber Safety is a community guidance concept, not an official portal, emergency service or legal advisor.
      </p>
    </div>
  );
}
