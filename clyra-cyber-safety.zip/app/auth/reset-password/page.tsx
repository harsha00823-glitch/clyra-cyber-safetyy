"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { AuthCard } from "@/components/ui/AuthCard";
import { FormInput } from "@/components/ui/FormInput";
import { Button } from "@/components/ui/Button";
import { AlertCircle } from "lucide-react";

export default function ResetPasswordPage() {
  const router = useRouter();
  const supabase = createClient();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      setIsLoading(false);
      return;
    }
    
    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      setIsLoading(false);
      return;
    }

    const { error: updateError } = await supabase.auth.updateUser({
      password,
    });

    if (updateError) {
      setError(updateError.message);
      setIsLoading(false);
      return;
    }

    router.push("/dashboard");
    router.refresh();
  };

  return (
    <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <AuthCard 
        title="Set New Password" 
        description="Please enter and confirm your new secure account password."
      >
        <form onSubmit={handleUpdatePassword} className="space-y-4">
          <FormInput
            id="password"
            type="password"
            label="New Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="new-password"
            placeholder="At least 6 characters"
          />
          
          <FormInput
            id="confirmPassword"
            type="password"
            label="Confirm New Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            autoComplete="new-password"
            placeholder="Re-enter new password"
          />

          {error && (
            <div className="p-3 bg-[#FFF0EE] border border-[#F6C4BD] rounded-lg flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
              <p className="text-xs text-[#B53232] leading-relaxed">{error}</p>
            </div>
          )}

          <Button 
            type="submit" 
            variant="primary"
            className="w-full mt-2" 
            isLoading={isLoading}
          >
            Update Password &amp; Continue
          </Button>

          <div className="flex items-center justify-center mt-4 text-xs">
            <a 
              href="/auth/forgot-password" 
              className="text-[#245CC5] hover:underline font-semibold"
            >
              Request new reset link
            </a>
          </div>
        </form>
      </AuthCard>
    </div>
  );
}
