"use client";

import { useState, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { AuthCard } from "@/components/ui/AuthCard";
import { FormInput } from "@/components/ui/FormInput";
import { Button } from "@/components/ui/Button";
import { Sparkles, AlertCircle, CheckCircle2, RefreshCw, Mail } from "lucide-react";

function SignInForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const supabase = createClient();

  const errorParam = searchParams.get("error");
  const urlError = errorParam
    ? errorParam === "invalid_or_expired_link"
      ? "The email confirmation or password reset link is invalid or has expired. Please sign in or request a new verification email."
      : decodeURIComponent(errorParam)
    : null;

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [formError, setFormError] = useState<string | null>(null);
  const [unconfirmedEmail, setUnconfirmedEmail] = useState<string | null>(null);
  const [resendStatus, setResendStatus] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [isDemoLoading, setIsDemoLoading] = useState(false);

  const activeError = formError || urlError;

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setFormError(null);
    setUnconfirmedEmail(null);
    setResendStatus(null);

    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (signInError) {
        const errorMsg = signInError.message.toLowerCase();
        if (errorMsg.includes("email not confirmed")) {
          setUnconfirmedEmail(email.trim());
        } else if (errorMsg.includes("invalid login credentials")) {
          setFormError("Invalid email or password. Please verify your credentials or sign up for a new account.");
        } else {
          setFormError(signInError.message);
        }
        setIsLoading(false);
        return;
      }

      if (data?.session) {
        router.push("/dashboard");
        router.refresh();
      } else {
        setFormError("Sign-in succeeded, but no active session was returned. Please try again.");
        setIsLoading(false);
      }
    } catch (err: unknown) {
      const e = err as Error;
      setFormError(e.message || "An unexpected error occurred during sign in.");
      setIsLoading(false);
    }
  };

  const handleResendConfirmation = async () => {
    if (!unconfirmedEmail && !email) return;
    const targetEmail = (unconfirmedEmail || email).trim();

    setIsResending(true);
    setResendStatus(null);
    setFormError(null);

    try {
      const emailRedirectTo = `${window.location.origin}/auth/callback?next=/dashboard`;
      const { error: resendError } = await supabase.auth.resend({
        type: "signup",
        email: targetEmail,
        options: {
          emailRedirectTo,
        },
      });

      if (resendError) {
        setFormError(resendError.message);
      } else {
        setResendStatus(`Verification link resent to ${targetEmail}. Please check your inbox.`);
      }
    } catch (err: unknown) {
      const e = err as Error;
      setFormError(e.message || "Failed to resend confirmation email.");
    } finally {
      setIsResending(false);
    }
  };

  const handleDemoLogin = async () => {
    setIsDemoLoading(true);
    setFormError(null);
    try {
      const res = await fetch("/api/auth/demo-login", { method: "POST" });
      if (res.ok) {
        router.push("/dashboard");
        router.refresh();
      } else {
        setFormError("Failed to initialize evaluator session. Please try again.");
        setIsDemoLoading(false);
      }
    } catch {
      setFormError("Network error initiating demo login.");
      setIsDemoLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Quick Evaluator / Demo Access Option */}
      <div className="p-4 rounded-[14px] bg-[#EAF6EF] border border-[#B8E2CB] text-center space-y-2">
        <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-[#18734D]">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Evaluator / Demo Login</span>
        </div>
        <p className="text-xs text-[#58677D]">
          Pre-configured evaluator workspace with sample incident data. Completely separate from real Supabase user accounts:
        </p>
        <Button
          type="button"
          variant="secondary"
          className="w-full bg-white hover:bg-emerald-50 text-[#18734D] border-[#B8E2CB] font-bold py-2 shadow-xs text-xs"
          isLoading={isDemoLoading}
          onClick={handleDemoLogin}
        >
          One-Click Instant Access
        </Button>
      </div>

      <div className="relative flex items-center justify-center">
        <div className="border-t border-[#DCE3ED] w-full"></div>
        <span className="bg-white px-3 text-xs uppercase text-[#58677D] font-semibold tracking-wider">
          Or Sign In with Email
        </span>
        <div className="border-t border-[#DCE3ED] w-full"></div>
      </div>

      <form onSubmit={handleSignIn} className="space-y-4">
        <FormInput
          id="email"
          type="email"
          label="Email Address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          autoComplete="email"
          placeholder="user@example.com"
        />
        
        <FormInput
          id="password"
          type="password"
          label="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          autoComplete="current-password"
          placeholder="••••••••"
        />

        {/* Unconfirmed Email Notice with Resend Action */}
        {unconfirmedEmail && (
          <div className="p-3.5 bg-[#FFF5E3] border border-[#F6E1B6] rounded-xl space-y-2 text-left">
            <div className="flex items-start gap-2">
              <Mail className="w-4 h-4 text-[#925500] shrink-0 mt-0.5" />
              <div className="text-xs text-[#925500] space-y-1">
                <p className="font-bold">Email not confirmed yet</p>
                <p className="text-[11px] leading-relaxed text-[#6D4002]">
                  Your account requires email verification. Please check your inbox for the confirmation link sent to <strong>{unconfirmedEmail}</strong>.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleResendConfirmation}
              disabled={isResending}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#245CC5] hover:underline pt-1"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isResending ? "animate-spin" : ""}`} />
              <span>{isResending ? "Resending..." : "Resend confirmation email"}</span>
            </button>
          </div>
        )}

        {resendStatus && (
          <div className="p-3 bg-[#EAF6EF] border border-[#B8E2CB] rounded-lg text-xs text-[#18734D] font-medium flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{resendStatus}</span>
          </div>
        )}

        {activeError && (
          <div className="p-3 bg-[#FFF0EE] border border-[#F6C4BD] rounded-lg flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
            <p className="text-xs text-[#B53232] leading-relaxed">{activeError}</p>
          </div>
        )}

        <Button 
          type="submit" 
          variant="primary"
          className="w-full mt-2" 
          isLoading={isLoading}
        >
          Sign In
        </Button>

        <div className="flex items-center justify-between mt-4 text-xs">
          <Link 
            href="/auth/forgot-password" 
            className="text-[#245CC5] hover:underline font-semibold"
          >
            Forgot your password?
          </Link>
          <Link 
            href="/auth/sign-up" 
            className="text-[#58677D] hover:text-[#182B49] font-medium"
          >
            Don&apos;t have an account? Sign up
          </Link>
        </div>
      </form>
    </div>
  );
}

export default function SignInPage() {
  return (
    <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <AuthCard 
        title="Sign In to CLYRA" 
        description="Pick up where you left off in your personal recovery workspace."
      >
        <Suspense fallback={<div className="py-8 text-center text-xs text-[#58677D]">Loading...</div>}>
          <SignInForm />
        </Suspense>
      </AuthCard>
    </div>
  );
}
