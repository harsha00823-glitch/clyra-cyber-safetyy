"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { AuthCard } from "@/components/ui/AuthCard";
import { FormInput } from "@/components/ui/FormInput";
import { Button } from "@/components/ui/Button";
import { Sparkles, AlertCircle, CheckCircle2, Mail, ArrowLeft, RefreshCw } from "lucide-react";

export default function SignUpPage() {
  const router = useRouter();
  const supabase = createClient();
  
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [preferredLanguage, setPreferredLanguage] = useState("en");
  
  const [error, setError] = useState<string | null>(null);
  const [resendStatus, setResendStatus] = useState<string | null>(null);
  const [isEmailSent, setIsEmailSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [isDemoLoading, setIsDemoLoading] = useState(false);

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setResendStatus(null);

    // Validation
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      setIsLoading(false);
      return;
    }
    
    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      setIsLoading(false);
      return;
    }

    try {
      const emailRedirectTo = `${window.location.origin}/auth/callback?next=/dashboard`;

      const { data, error: signUpError } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          emailRedirectTo,
          data: {
            display_name: displayName.trim(),
            preferred_language: preferredLanguage,
          },
        },
      });

      if (signUpError) {
        const msg = signUpError.message.toLowerCase();
        if (
          msg.includes("rate limit") ||
          msg.includes("security purposes") ||
          msg.includes("over_email_send_rate_limit") ||
          msg.includes("too many requests") ||
          (signUpError as { status?: number }).status === 429
        ) {
          setError("Supabase email rate limit reached. Please wait a few minutes before requesting another confirmation email, or use Evaluator / Demo Login below.");
        } else {
          setError(signUpError.message);
        }
        setIsLoading(false);
        return;
      }

      // If Supabase has email confirmation disabled, session is returned immediately
      if (data?.session) {
        router.push("/dashboard");
        router.refresh();
        return;
      }

      // Supabase email confirmation is required: display positive verification instructions
      if (data?.user) {
        setIsEmailSent(true);
        setIsLoading(false);
      }
    } catch (err: unknown) {
      const e = err as Error;
      setError(e.message || "An unexpected error occurred during registration.");
      setIsLoading(false);
    }
  };

  const handleResendConfirmation = async () => {
    setIsResending(true);
    setResendStatus(null);
    setError(null);

    try {
      const emailRedirectTo = `${window.location.origin}/auth/callback?next=/dashboard`;
      const { error: resendError } = await supabase.auth.resend({
        type: "signup",
        email: email.trim(),
        options: {
          emailRedirectTo,
        },
      });

      if (resendError) {
        const msg = resendError.message.toLowerCase();
        if (
          msg.includes("rate limit") ||
          msg.includes("security purposes") ||
          msg.includes("over_email_send_rate_limit") ||
          msg.includes("too many requests") ||
          (resendError as { status?: number }).status === 429
        ) {
          setError("Supabase email rate limit reached. Please wait a few minutes before requesting another confirmation email, or use Evaluator / Demo Login below.");
        } else {
          setError(resendError.message);
        }
      } else {
        setResendStatus("A new verification link has been sent to your email.");
      }
    } catch (err: unknown) {
      const e = err as Error;
      setError(e.message || "Failed to resend confirmation email.");
    } finally {
      setIsResending(false);
    }
  };

  const handleDemoLogin = async () => {
    setIsDemoLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/demo-login", { method: "POST" });
      if (res.ok) {
        router.push("/dashboard");
        router.refresh();
      } else {
        setError("Failed to initialize evaluator session.");
        setIsDemoLoading(false);
      }
    } catch {
      setError("Network error initiating demo login.");
      setIsDemoLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <AuthCard 
        title="Create an Account" 
        description="Save your safety checklists, track evidence, and access guided recovery."
      >
        {isEmailSent ? (
          /* Post-Signup Email Confirmation Sent Screen */
          <div className="space-y-5 text-center py-2">
            <div className="w-12 h-12 rounded-full bg-[#EAF6EF] border border-[#B8E2CB] text-[#18734D] flex items-center justify-center mx-auto shadow-xs">
              <Mail className="w-6 h-6" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-base font-bold text-[#182B49]">
                Confirm your email address
              </h3>
              <p className="text-xs text-[#58677D] leading-relaxed max-w-sm mx-auto">
                We sent a secure verification link to <strong className="text-[#182B49]">{email}</strong>. Please check your inbox and click the link to activate your account.
              </p>
            </div>

            <div className="p-3.5 rounded-[12px] bg-[#F6F8FB] border border-[#DCE3ED] text-left text-xs space-y-1.5 text-[#58677D]">
              <div className="flex items-center gap-1.5 font-bold text-[#182B49]">
                <CheckCircle2 className="w-4 h-4 text-[#18734D]" />
                <span>Next steps:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 pl-1 text-[11px] leading-relaxed">
                <li>Check your inbox and spam/junk folder</li>
                <li>Click the confirmation button or link</li>
                <li>You will be redirected automatically to your recovery workspace</li>
              </ul>
            </div>

            {resendStatus && (
              <div className="p-3 bg-[#EAF6EF] border border-[#B8E2CB] rounded-lg text-xs text-[#18734D] font-medium flex items-center justify-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{resendStatus}</span>
              </div>
            )}

            {error && (
              <div className="p-3 bg-[#FFF0EE] border border-[#F6C4BD] rounded-lg flex items-start gap-2 text-left">
                <AlertCircle className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
                <p className="text-xs text-[#B53232] leading-relaxed">{error}</p>
              </div>
            )}

            <div className="space-y-2 pt-2">
              <Button
                type="button"
                variant="secondary"
                className="w-full text-xs flex items-center justify-center gap-1.5"
                isLoading={isResending}
                onClick={handleResendConfirmation}
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Resend confirmation email</span>
              </Button>

              <Link
                href="/auth/sign-in"
                className="inline-flex items-center justify-center gap-1.5 text-xs text-[#245CC5] hover:underline font-semibold pt-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Proceed to Sign In</span>
              </Link>
            </div>
          </div>
        ) : (
          /* Main Signup Form */
          <div className="space-y-4">
            {/* Dedicated Evaluator / Demo Login Section */}
            <div className="p-3.5 rounded-[14px] bg-[#EAF6EF] border border-[#B8E2CB] text-center space-y-2">
              <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-[#18734D]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Evaluator / Demo Login</span>
              </div>
              <p className="text-xs text-[#58677D]">
                Pre-configured evaluator workspace with sample incident data. Completely separate from real Supabase user accounts:
              </p>
              <Button
                type="button"
                variant="secondary"
                className="w-full bg-white hover:bg-emerald-50 text-[#18734D] border-[#B8E2CB] font-bold py-2 shadow-xs text-xs"
                isLoading={isDemoLoading}
                onClick={handleDemoLogin}
              >
                One-Click Instant Access
              </Button>
            </div>

            <div className="relative flex items-center justify-center">
              <div className="border-t border-[#DCE3ED] w-full"></div>
              <span className="bg-white px-3 text-xs uppercase text-[#58677D] font-semibold tracking-wider">
                Or Register Real Account with Email
              </span>
              <div className="border-t border-[#DCE3ED] w-full"></div>
            </div>

            <form onSubmit={handleSignUp} className="space-y-3.5">
              <FormInput
                id="displayName"
                type="text"
                label="Your Name"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                required
                placeholder="e.g. Asha Sharma"
              />

              <FormInput
                id="email"
                type="email"
                label="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoComplete="email"
                placeholder="user@example.com"
              />
              
              <FormInput
                id="password"
                type="password"
                label="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete="new-password"
                placeholder="At least 6 characters"
              />

              <FormInput
                id="confirmPassword"
                type="password"
                label="Confirm Password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                autoComplete="new-password"
                placeholder="Re-enter password"
              />

              <div className="w-full text-left">
                <label htmlFor="language" className="block text-xs font-semibold text-[#182B49] mb-1.5">
                  Preferred Guidance Language
                </label>
                <select
                  id="language"
                  value={preferredLanguage}
                  onChange={(e) => setPreferredLanguage(e.target.value)}
                  className="w-full bg-white border border-[#DCE3ED] focus:border-[#245CC5] focus:ring-3 focus:ring-[#93B4F4] rounded-lg px-3.5 py-2.5 text-[#182B49] text-sm focus:outline-none transition-all shadow-xs"
                >
                  <option value="en">English</option>
                  <option value="hi">हिन्दी (Hindi)</option>
                  <option value="kn">ಕನ್ನಡ (Kannada)</option>
                </select>
              </div>

              {error && (
                <div className="p-3 bg-[#FFF0EE] border border-[#F6C4BD] rounded-lg flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
                  <p className="text-xs text-[#B53232] leading-relaxed">{error}</p>
                </div>
              )}

              <Button 
                type="submit" 
                variant="primary"
                className="w-full mt-3" 
                isLoading={isLoading}
              >
                Create Account
              </Button>

              <div className="flex items-center justify-center mt-3 text-xs">
                <Link 
                  href="/auth/sign-in" 
                  className="text-[#245CC5] hover:underline font-semibold"
                >
                  Already have an account? Sign in
                </Link>
              </div>
            </form>
          </div>
        )}
      </AuthCard>
    </div>
  );
}
