import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { type EmailOtpType } from "@supabase/supabase-js";

export async function GET(request: Request) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get("code");
  const token_hash = requestUrl.searchParams.get("token_hash");
  const type = requestUrl.searchParams.get("type") as EmailOtpType | null;
  const next = requestUrl.searchParams.get("next") ?? "/dashboard";
  const errorParam = requestUrl.searchParams.get("error");
  const errorDescription = requestUrl.searchParams.get("error_description");

  // Determine origin safely for production, reverse proxy, or local dev
  const forwardedHost = request.headers.get("x-forwarded-host");
  const forwardedProto = request.headers.get("x-forwarded-proto") || "http";
  const origin = forwardedHost 
    ? `${forwardedProto}://${forwardedHost}` 
    : requestUrl.origin;

  // Handle any explicit auth error query params returned by Supabase
  if (errorParam) {
    const errorUrl = new URL("/auth/sign-in", origin);
    errorUrl.searchParams.set("error", errorDescription || errorParam);
    return NextResponse.redirect(errorUrl);
  }

  const supabase = await createClient();

  // 1. Handle PKCE authorization code exchange
  if (code) {
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) {
      const targetPath = next.startsWith("/") ? next : `/${next}`;
      const redirectUrl = new URL(targetPath, origin);
      return NextResponse.redirect(redirectUrl);
    }
  }

  // 2. Handle token_hash / OTP verification (used in certain Supabase email templates)
  if (token_hash && type) {
    const { error } = await supabase.auth.verifyOtp({ token_hash, type });
    if (!error) {
      const targetPath = next.startsWith("/") ? next : `/${next}`;
      const redirectUrl = new URL(targetPath, origin);
      return NextResponse.redirect(redirectUrl);
    }
  }

  // Redirect to sign in with clear notice if confirmation link is invalid or expired
  const redirectUrl = new URL("/auth/sign-in", origin);
  redirectUrl.searchParams.set("error", "invalid_or_expired_link");
  return NextResponse.redirect(redirectUrl);
}
