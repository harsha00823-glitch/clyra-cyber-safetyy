"use client";

import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { AuthCard } from "@/components/ui/AuthCard";
import { FormInput } from "@/components/ui/FormInput";
import { Button } from "@/components/ui/Button";
import { CheckCircle2, AlertCircle, ArrowLeft } from "lucide-react";

export default function ForgotPasswordPage() {
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setIsSuccess(false);

    const { error: resetError } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/auth/callback?next=/auth/reset-password`,
    });

    if (resetError) {
      setError(resetError.message);
      setIsLoading(false);
      return;
    }

    setIsSuccess(true);
    setIsLoading(false);
  };

  return (
    <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <AuthCard 
        title="Reset Your Password" 
        description="Enter your registered email address to receive password reset instructions."
      >
        {!isSuccess ? (
          <form onSubmit={handleReset} className="space-y-4">
            <FormInput
              id="email"
              type="email"
              label="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
              placeholder="user@example.com"
            />
            
            {error && (
              <div className="p-3 bg-[#FFF0EE] border border-[#F6C4BD] rounded-lg flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
                <p className="text-xs text-[#B53232] leading-relaxed">{error}</p>
              </div>
            )}

            <Button 
              type="submit" 
              variant="primary"
              className="w-full mt-2" 
              isLoading={isLoading}
            >
              Send Password Reset Link
            </Button>
          </form>
        ) : (
          <div className="text-center space-y-4 py-2">
            <div className="p-4 bg-[#EAF6EF] border border-[#B8E2CB] rounded-[14px] flex flex-col items-center gap-2">
              <CheckCircle2 className="w-8 h-8 text-[#18734D]" />
              <p className="text-[#18734D] font-bold text-sm">Check your inbox</p>
              <p className="text-xs text-[#58677D] leading-relaxed">
                We have sent a secure password reset link to <strong className="text-[#182B49]">{email}</strong>.
              </p>
            </div>
          </div>
        )}

        <div className="flex items-center justify-center mt-6 text-xs">
          <Link 
            href="/auth/sign-in" 
            className="text-[#245CC5] hover:underline font-semibold inline-flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to sign in
          </Link>
        </div>
      </AuthCard>
    </div>
  );
}
