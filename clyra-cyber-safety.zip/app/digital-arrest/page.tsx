import Link from "next/link";
import { 
  ShieldCheck, 
  Scale, 
  AlertTriangle, 
  PhoneCall
} from "lucide-react";

export default function DigitalArrestPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8 py-2">
      {/* 1. Header (Saathi Style) */}
      <header className="space-y-2 text-left">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFF0EE] border border-[#FFD5D2] text-[#B53232] text-xs font-semibold">
          <span>PROTECT</span>
          <span>·</span>
          <span>Authority impersonation</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#182B49]">
          Digital Arrest: What it is and how to stay safe.
        </h1>
        <p className="text-sm text-[#58677D]">
          No Indian court or police agency can arrest you over a video call. Learn how to recognise the psychological tricks and protect yourself.
        </p>
      </header>

      {/* 2. Top Summary Card */}
      <div className="saathi-panel p-6 sm:p-8 bg-white space-y-4">
        <h2 className="text-lg font-bold text-[#182B49]">
          What is a &ldquo;Digital Arrest&rdquo; scam?
        </h2>
        <div className="space-y-3 text-sm text-[#58677D] leading-relaxed">
          <p>
            A &ldquo;Digital Arrest&rdquo; is an extortion scam where cyber criminals impersonate police officers, CBI agents, Customs officials, or judges. They claim an illegal parcel containing drugs, passports, or stolen money was intercepted in your name.
          </p>
          <div className="p-4 rounded-xl bg-[#FFF0EE] border border-[#FFD5D2] text-xs text-[#B53232] space-y-1">
            <strong className="block font-bold">Their primary weapon is isolation and fear:</strong>
            <p className="text-[#932525]">
              They demand you stay on a continuous Skype or WhatsApp video call, forbidding you from talking to family members or hanging up, until you transfer your savings to a &ldquo;safe government verification account&rdquo;.
            </p>
          </div>
        </div>
      </div>

      {/* 3. 4 Red Flags vs 4 Protection Actions */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* 4 Warning Signs */}
        <div className="saathi-card p-6 bg-white space-y-4">
          <div className="flex items-center gap-2 border-b border-[#DCE3ED] pb-3">
            <AlertTriangle className="w-5 h-5 text-[#925500]" />
            <h3 className="font-bold text-[#182B49] text-base">
              The 4 Warning Signs
            </h3>
          </div>

          <ul className="space-y-3 text-xs text-[#58677D]">
            <li className="space-y-1">
              <strong className="text-[#182B49] block">1. The Isolation Demand:</strong>
              They forbid you from hanging up the video call or telling anyone in your home.
            </li>
            <li className="space-y-1">
              <strong className="text-[#182B49] block">2. Forged Government Documents:</strong>
              They send fake arrest warrants, Supreme Court seals, or RBI notices over WhatsApp.
            </li>
            <li className="space-y-1">
              <strong className="text-[#182B49] block">3. Staged Police Station Backgrounds:</strong>
              They wear theatrical uniforms and sit in front of mocked-up police banners.
            </li>
            <li className="space-y-1">
              <strong className="text-[#182B49] block">4. The &ldquo;Safe Account&rdquo; Transfer:</strong>
              The final demand is always sending your money to a temporary account for &ldquo;clearing your name&rdquo;.
            </li>
          </ul>
        </div>

        {/* 4 Protection Habits */}
        <div className="saathi-card p-6 bg-white space-y-4">
          <div className="flex items-center gap-2 border-b border-[#DCE3ED] pb-3">
            <ShieldCheck className="w-5 h-5 text-[#18734D]" />
            <h3 className="font-bold text-[#182B49] text-base">
              What to Do Immediately
            </h3>
          </div>

          <ul className="space-y-3 text-xs text-[#58677D]">
            <li className="space-y-1">
              <strong className="text-[#18734D] block">1. Disconnect Immediately:</strong>
              Hang up the call. Real police never interrogate or arrest anyone over video.
            </li>
            <li className="space-y-1">
              <strong className="text-[#18734D] block">2. Never Transfer Funds:</strong>
              Government agencies never ask citizens to transfer money to prove innocence.
            </li>
            <li className="space-y-1">
              <strong className="text-[#18734D] block">3. Verify Independently:</strong>
              If you feel concerned, visit your local neighborhood police station in person with a friend.
            </li>
            <li className="space-y-1">
              <strong className="text-[#18734D] block">4. Call 1930 Helpline:</strong>
              Report the caller’s number to the National Cybercrime Reporting Portal.
            </li>
          </ul>
        </div>
      </div>

      {/* 4. Statutory Legal Reality Box */}
      <div className="saathi-card p-6 bg-[#EDF3FF] border-[#C5D8FD] flex items-start gap-3.5">
        <Scale className="w-5 h-5 text-[#245CC5] shrink-0 mt-0.5" />
        <div className="space-y-1 text-xs text-[#182B49]">
          <strong className="font-bold text-[#245CC5] block text-sm">
            The Legal Reality (Section 41A CrPC / BNSS)
          </strong>
          <p className="text-[#58677D] leading-relaxed">
            Under Indian Criminal Law, summons must be served physically in writing. Arrests require physical warrants and physical presence before a magistrate within 24 hours. There is no concept of a &ldquo;Digital Arrest&rdquo; anywhere in Indian statutes.
          </p>
        </div>
      </div>

      {/* 5. Action Row */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-[#DCE3ED] text-xs">
        <Link
          href="/analyze"
          className="font-semibold text-[#245CC5] hover:underline"
        >
          Check a message you received →
        </Link>

        <a
          href="tel:1930"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#B53232] text-white font-bold hover:bg-[#932525] transition-colors"
        >
          <PhoneCall className="w-3.5 h-3.5" />
          <span>Call 1930 Cyber Helpline</span>
        </a>
      </div>
    </div>
  );
}
