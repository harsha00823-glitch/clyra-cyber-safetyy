import Link from "next/link";
import { 
  PhoneCall, 
  ExternalLink, 
  AlertTriangle, 
  ArrowRight
} from "lucide-react";

export default function EmergencyPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8 py-2">
      {/* 1. Reassuring Empathy Header */}
      <header className="space-y-2 text-left">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFF0EE] border border-[#FFD5D2] text-[#B53232] text-xs font-semibold">
          <span>EMERGENCY HELP</span>
          <span>·</span>
          <span>Money lost</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#182B49]">
          Lost money? Focus on these steps first.
        </h1>
        <p className="text-sm text-[#58677D]">
          We’re sorry this happened. Scams can happen to anyone. Acting promptly may help — recovery is not guaranteed.
        </p>
      </header>

      {/* 2. Primary 1930 Helpline Hero Card (From Figma) */}
      <div className="clyra-panel p-6 sm:p-8 bg-gradient-to-r from-[#FFF0EE] to-[#FFFFFF] border-[#FFD5D2] space-y-4">
        <div className="flex items-center gap-2 text-[#B53232] text-xs font-bold uppercase tracking-wider">
          <PhoneCall className="w-4 h-4 text-[#B53232]" />
          <span>Act promptly · Financial fraud helpline</span>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="space-y-1">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#182B49]">
              Call India&apos;s cybercrime helpline: <span className="text-[#B53232]">1930</span>
            </h2>
            <p className="text-xs text-[#58677D] leading-relaxed max-w-xl">
              Keep the transaction amount, time, and UTR reference ready. Do not wait to finish a CLYRA checklist before calling.
            </p>
          </div>

          <a
            href="tel:1930"
            className="px-8 py-4 rounded-xl bg-[#B53232] hover:bg-[#932525] text-white font-bold text-base shadow-xs transition-colors text-center shrink-0 flex items-center justify-center gap-2"
          >
            <PhoneCall className="w-5 h-5" />
            <span>Call 1930 on your phone</span>
          </a>
        </div>

        <p className="text-[11px] text-[#8B98A9] pt-2 border-t border-[#FFD5D2]/50 italic">
          1930 is an official government assistance helpline run by the Indian Cyber Crime Coordination Centre (I4C). CLYRA is not affiliated with it.
        </p>
      </div>

      {/* 3. Time-Sensitive Checklist (1 to 4 Steps) */}
      <div className="clyra-panel p-6 sm:p-8 bg-white space-y-6">
        <div className="border-b border-[#DCE3ED] pb-4">
          <h3 className="text-base font-bold text-[#182B49]">
            Your Time-Sensitive Action Steps
          </h3>
          <p className="text-xs text-[#58677D]">
            Start with the most urgent actions. You can work through the rest at your own pace.
          </p>
        </div>

        <div className="space-y-4">
          {/* Action 1 */}
          <div className="p-4 rounded-xl border border-[#DCE3ED] bg-[#F6F8FB] space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#182B49] text-sm">
                1 · Contact your bank or payment provider immediately
              </span>
              <span className="text-[10px] font-bold text-[#B53232] bg-[#FFF0EE] px-2 py-0.5 rounded border border-[#FFD5D2] uppercase">
                Urgent
              </span>
            </div>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Use the official app, website, or the phone number printed on the back of your debit/credit card. Report the unauthorized debit, ask to block compromised cards/UPI, and request a transaction dispute or freeze.
            </p>
          </div>

          {/* Action 2 */}
          <div className="p-4 rounded-xl border border-[#DCE3ED] bg-white space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#182B49] text-sm">
                2 · Report through the official portal (cybercrime.gov.in)
              </span>
              <span className="text-[10px] font-bold text-[#245CC5] bg-[#EDF3FF] px-2 py-0.5 rounded border border-[#C5D8FD] uppercase">
                Official
              </span>
            </div>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Follow instructions provided by 1930 and the portal. CLYRA does not file a complaint for you. Prepare your summary first if you need to organize your evidence.
            </p>
            <div className="pt-1 flex items-center gap-3">
              <a
                href="https://cybercrime.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#245CC5] bg-[#EDF3FF] hover:bg-[#DCE7FD] text-[#245CC5] text-xs font-semibold transition-colors"
              >
                <span>Open cybercrime.gov.in</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <Link
                href="/report"
                className="text-xs font-semibold text-[#58677D] hover:text-[#182B49] underline"
              >
                Prepare incident summary in CLYRA →
              </Link>
            </div>
          </div>

          {/* Action 3 */}
          <div className="p-4 rounded-xl border border-[#DCE3ED] bg-white space-y-2">
            <span className="font-bold text-[#182B49] text-sm block">
              3 · Preserve evidence without contacting the sender again
            </span>
            <p className="text-xs text-[#58677D] leading-relaxed">
              Save screenshots, payment receipts, UTR numbers, caller phone numbers, and WhatsApp chat exports privately. Never post them in public forums or delete them.
            </p>
          </div>

          {/* Action 4 */}
          <div className="p-4 rounded-xl border border-[#DCE3ED] bg-white space-y-2">
            <span className="font-bold text-[#182B49] text-sm block">
              4 · Change passwords &amp; secure your device
            </span>
            <p className="text-xs text-[#58677D] leading-relaxed">
              If an APK was installed, disconnect Wi-Fi and mobile data immediately. Review recently granted SMS permissions, uninstall unknown apps, and change your net-banking password from a trusted device.
            </p>
          </div>
        </div>
      </div>

      {/* 4. Warning: Beware of Fake Recovery Agents (From Figma) */}
      <div className="clyra-card p-5 bg-[#FFF5E3] border-[#F6E1B6] flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-[#925500] shrink-0 mt-0.5" />
        <div className="space-y-1 text-xs">
          <strong className="font-bold text-[#925500] block text-sm">
            Beware of &ldquo;recovery agents&rdquo; or secondary scams
          </strong>
          <p className="text-[#6D4002] leading-relaxed">
            Anyone promising to recover your stolen money on Telegram, WhatsApp, or Instagram in exchange for an upfront fee or &ldquo;file charge&rdquo; is another scammer. Official recovery is handled strictly through your bank and law enforcement. Never pay anyone to get your money back.
          </p>
        </div>
      </div>

      {/* 5. Navigation Row */}
      <div className="flex items-center justify-between pt-2 border-t border-[#DCE3ED] text-xs">
        <Link
          href="/dashboard"
          className="font-semibold text-[#245CC5] hover:underline flex items-center gap-1.5"
        >
          <ArrowRight className="w-3.5 h-3.5 rotate-180" />
          <span>Go to my recovery workspace</span>
        </Link>

        <Link
          href="/report"
          className="font-semibold text-[#182B49] hover:underline"
        >
          Prepare incident report dossier →
        </Link>
      </div>
    </div>
  );
}
