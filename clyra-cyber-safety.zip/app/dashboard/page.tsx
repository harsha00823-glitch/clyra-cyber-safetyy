import { redirect } from "next/navigation";
import Link from "next/link";
import { cookies } from "next/headers";
import { createClient } from "@/lib/supabase/server";
import { 
  PhoneCall, 
  CheckCircle2, 
  Circle, 
  FileText, 
  Lock,
  Search,
  BookOpen,
  ArrowRight,
  ShieldAlert,
  History
} from "lucide-react";

interface AnalysisSession {
  id: string;
  created_at: string;
  analysis_type: string;
  risk_level: string;
  risk_score: number;
  input_preview?: string | null;
}

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const cookieStore = await cookies();
  const demoCookie = cookieStore.get("csp_demo_session")?.value;
  const isDemo = demoCookie === "true";

  if (!user && !isDemo) {
    redirect("/auth/sign-in");
  }

  let displayName = "Asha Sharma";

  if (user) {
    displayName = user.user_metadata?.display_name || user.email?.split("@")[0] || "Asha";

    try {
      const { data: profile } = await supabase
        .from("user_profiles")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();

      if (profile?.display_name) {
        displayName = profile.display_name;
      }
    } catch {
      // Graceful fallback
    }
  }

  // Fetch user's real recent analysis history if available
  let userSessions: AnalysisSession[] = [];
  if (user) {
    try {
      const { data } = await supabase
        .from("analysis_sessions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(5);
      if (data && data.length > 0) {
        userSessions = data;
      }
    } catch {
      // Supabase table fallback
    }
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8 py-2">
      {/* 1. Header: Reassuring Companion Intro */}
      <header className="space-y-2 text-left">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EDF3FF] border border-[#C5D8FD] text-[#245CC5] text-xs font-semibold">
          <span>03 / PROTECT &amp; RECOVER</span>
          <span>·</span>
          <span>My safety checklist</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#182B49]">
          Small steps that put you back in control, {displayName}.
        </h1>
        <p className="text-sm text-[#58677D]">
          A calm place for your actions, evidence, and notes. This is your personal tracking record, not an official investigation.
        </p>
      </header>

      {/* 2. Quick Action Tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Link
          href="/analyze"
          className="clyra-card p-4 hover:border-[#245CC5] transition-all group flex flex-col justify-between space-y-3"
        >
          <div className="w-8 h-8 rounded-lg bg-[#EDF3FF] text-[#245CC5] flex items-center justify-center group-hover:scale-105 transition-transform">
            <Search className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-xs text-[#182B49] flex items-center justify-between">
              <span>Check Threat</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#58677D] group-hover:text-[#245CC5] transition-colors" />
            </div>
            <p className="text-[11px] text-[#58677D] mt-0.5">Message, link or image</p>
          </div>
        </Link>

        <Link
          href="/emergency"
          className="clyra-card p-4 hover:border-[#B53232] transition-all group flex flex-col justify-between space-y-3 bg-[#FFF0EE]/30"
        >
          <div className="w-8 h-8 rounded-lg bg-[#FFF0EE] text-[#B53232] flex items-center justify-center group-hover:scale-105 transition-transform">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-xs text-[#B53232] flex items-center justify-between">
              <span>Lost Money?</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#B53232]" />
            </div>
            <p className="text-[11px] text-[#58677D] mt-0.5">1930 &amp; Bank dispute</p>
          </div>
        </Link>

        <Link
          href="/report"
          className="clyra-card p-4 hover:border-[#245CC5] transition-all group flex flex-col justify-between space-y-3"
        >
          <div className="w-8 h-8 rounded-lg bg-[#EDF3FF] text-[#245CC5] flex items-center justify-center group-hover:scale-105 transition-transform">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-xs text-[#182B49] flex items-center justify-between">
              <span>Prepare Report</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#58677D] group-hover:text-[#245CC5] transition-colors" />
            </div>
            <p className="text-[11px] text-[#58677D] mt-0.5">Export PDF dossier</p>
          </div>
        </Link>

        <Link
          href="/learn"
          className="clyra-card p-4 hover:border-[#18734D] transition-all group flex flex-col justify-between space-y-3"
        >
          <div className="w-8 h-8 rounded-lg bg-[#EAF6EF] text-[#18734D] flex items-center justify-center group-hover:scale-105 transition-transform">
            <BookOpen className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-xs text-[#182B49] flex items-center justify-between">
              <span>Safety Lessons</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#58677D] group-hover:text-[#18734D] transition-colors" />
            </div>
            <p className="text-[11px] text-[#58677D] mt-0.5">UPI, Phishing &amp; APKs</p>
          </div>
        </Link>
      </div>

      {/* 3. Top Emergency Alert Card: 1930 Helpline */}
      <div className="clyra-card p-6 bg-gradient-to-r from-[#FFF0EE] to-[#FFFFFF] border-[#FFD5D2] flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2 text-[#B53232] text-xs font-bold uppercase tracking-wider">
            <PhoneCall className="w-4 h-4 text-[#B53232]" />
            <span>Cyber financial-fraud assistance</span>
          </div>
          <h2 className="text-lg font-bold text-[#182B49]">
            Call India&apos;s cybercrime helpline: 1930
          </h2>
          <p className="text-xs text-[#58677D] leading-relaxed">
            Keep your transaction amount, time, and UTR reference ready. Do not wait to finish your CLYRA checklist before calling.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <a
            href="tel:1930"
            className="px-6 py-3 rounded-lg bg-[#B53232] hover:bg-[#932525] text-white font-bold text-sm shadow-xs transition-colors flex items-center gap-2"
          >
            <PhoneCall className="w-4 h-4" />
            <span>Call 1930 Now</span>
          </a>
        </div>
      </div>

      {/* 4. Main Recovery Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Personal Safety Checklist (5 Steps) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="clyra-panel p-6 bg-white space-y-5">
            <div className="flex items-center justify-between border-b border-[#DCE3ED] pb-4">
              <div>
                <h3 className="text-base font-bold text-[#182B49]">
                  Your Personal Safety Checklist
                </h3>
                <p className="text-xs text-[#58677D]">
                  2 of 5 actions completed · Your own tracking, not a safety score
                </p>
              </div>

              <span className="px-2.5 py-1 rounded-full bg-[#EAF6EF] text-[#18734D] text-xs font-semibold border border-[#C3E7D5]">
                2 / 5 Completed
              </span>
            </div>

            {/* Checklist items */}
            <div className="space-y-3">
              {/* Step 1 - Done */}
              <div className="p-3.5 rounded-xl border border-[#DCE3ED] bg-[#F6F8FB] flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#18734D] shrink-0 mt-0.5" />
                <div className="space-y-0.5 text-xs">
                  <span className="font-bold text-[#182B49] block">
                    1. Stop contact with the suspicious sender
                  </span>
                  <p className="text-[#58677D]">
                    Don’t reply, click the link, or make another payment. Block the sender after preserving messages.
                  </p>
                  <span className="inline-block text-[11px] font-semibold text-[#18734D] mt-1">
                    ✓ Done
                  </span>
                </div>
              </div>

              {/* Step 2 - Done */}
              <div className="p-3.5 rounded-xl border border-[#DCE3ED] bg-[#F6F8FB] flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#18734D] shrink-0 mt-0.5" />
                <div className="space-y-0.5 text-xs">
                  <span className="font-bold text-[#182B49] block">
                    2. Contact your bank or payment provider
                  </span>
                  <p className="text-[#58677D]">
                    Used support in the official bank app. Reported the payment and requested a transaction dispute.
                  </p>
                  <span className="inline-block text-[11px] font-semibold text-[#18734D] mt-1">
                    ✓ Done
                  </span>
                </div>
              </div>

              {/* Step 3 - In Progress */}
              <div className="p-3.5 rounded-xl border border-[#C5D8FD] bg-[#EDF3FF] flex items-start gap-3">
                <Circle className="w-5 h-5 text-[#245CC5] shrink-0 mt-0.5" />
                <div className="space-y-1 text-xs">
                  <span className="font-bold text-[#182B49] block">
                    3. Prepare and submit a report
                  </span>
                  <p className="text-[#58677D]">
                    Prepare a clear incident summary and check your evidence. Then submit it yourself through the official reporting portal.
                  </p>
                  <div className="pt-1 flex items-center gap-2">
                    <Link
                      href="/report"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#245CC5] text-white font-semibold text-[11px] shadow-xs hover:bg-[#19489F]"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Prepare incident report</span>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Step 4 - To do */}
              <div className="p-3.5 rounded-xl border border-[#DCE3ED] bg-white flex items-start gap-3">
                <Circle className="w-5 h-5 text-[#8B98A9] shrink-0 mt-0.5" />
                <div className="space-y-0.5 text-xs">
                  <span className="font-bold text-[#182B49] block">
                    4. Preserve evidence without further contact
                  </span>
                  <p className="text-[#58677D]">
                    Keep payment receipts, transaction references, and original conversations privately. Don’t delete messages.
                  </p>
                </div>
              </div>

              {/* Step 5 - To do */}
              <div className="p-3.5 rounded-xl border border-[#DCE3ED] bg-white flex items-start gap-3">
                <Circle className="w-5 h-5 text-[#8B98A9] shrink-0 mt-0.5" />
                <div className="space-y-0.5 text-xs">
                  <span className="font-bold text-[#182B49] block">
                    5. Review apps and device permissions
                  </span>
                  <p className="text-[#58677D]">
                    Remove unfamiliar remote-access apps. Update device and review permissions you recently allowed.
                  </p>
                  <Link
                    href="/malicious-apps"
                    className="inline-block text-[11px] font-semibold text-[#245CC5] hover:underline mt-0.5"
                  >
                    View app safety tips →
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* User Recent Analysis Sessions (Real DB data or clean fallback) */}
          {userSessions.length > 0 && (
            <div className="clyra-card p-6 bg-white space-y-4">
              <div className="flex items-center justify-between border-b border-[#DCE3ED] pb-3">
                <div className="flex items-center gap-2">
                  <History className="w-4 h-4 text-[#245CC5]" />
                  <h3 className="text-sm font-bold text-[#182B49]">Recent Threat Scans</h3>
                </div>
                <Link href="/analyze" className="text-xs font-semibold text-[#245CC5] hover:underline">
                  New Check +
                </Link>
              </div>

              <div className="divide-y divide-[#DCE3ED]">
                {userSessions.map((session) => (
                  <div key={session.id} className="py-3 flex items-center justify-between text-xs gap-3">
                    <div className="space-y-0.5 max-w-sm truncate">
                      <span className="font-semibold text-[#182B49] block truncate">
                        {session.input_preview || `${session.analysis_type.toUpperCase()} scan`}
                      </span>
                      <span className="text-[10px] text-[#58677D]">
                        {new Date(session.created_at).toLocaleDateString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      session.risk_level === 'critical' ? 'bg-[#FFF0EE] text-[#B53232] border border-[#FFD5D2]' :
                      session.risk_level === 'high' ? 'bg-[#FFF5E3] text-[#925500] border border-[#F6E1B6]' :
                      session.risk_level === 'medium' ? 'bg-amber-50 text-amber-800 border border-amber-200' :
                      'bg-[#EAF6EF] text-[#18734D] border border-[#C3E7D5]'
                    }`}>
                      {session.risk_level} · {session.risk_score}/100
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recovery Timeline (From Figma) */}
          <div className="clyra-card p-6 bg-white space-y-4">
            <h3 className="text-base font-bold text-[#182B49]">
              Your Recovery Timeline
            </h3>
            <div className="border-l-2 border-[#DCE3ED] ml-2 pl-4 space-y-4 text-xs">
              <div className="space-y-0.5">
                <div className="text-[11px] font-bold text-[#58677D]">
                  04 Oct · 14:35 — Called 1930
                </div>
                <p className="text-[#182B49]">
                  Noted the guidance received. Contacted the helpline promptly.
                </p>
              </div>

              <div className="space-y-0.5">
                <div className="text-[11px] font-bold text-[#58677D]">
                  04 Oct · 14:50 — Contacted bank support
                </div>
                <p className="text-[#182B49]">
                  Used support in the official bank app. Asked about a transaction dispute.
                </p>
              </div>

              <div className="space-y-0.5">
                <div className="text-[11px] font-bold text-[#245CC5]">
                  05 Oct — Prepare and submit report (In progress)
                </div>
                <p className="text-[#58677D]">
                  Summary draft created in CLYRA. Official submission on cybercrime.gov.in not yet completed.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Case Data, Evidence & Notes */}
        <div className="space-y-6">
          {/* Active Case Summary Card (From Figma SC-DEMO-014) */}
          <div className="clyra-card p-5 bg-white space-y-3.5">
            <div className="flex items-center justify-between border-b border-[#DCE3ED] pb-3">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#58677D]">
                Personal Record
              </span>
              <span className="text-xs font-mono font-bold text-[#245CC5]">
                SC-DEMO-014
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <span className="text-[#58677D] block">Incident type:</span>
                <span className="font-semibold text-[#182B49]">
                  Suspicious UPI payment / collect request
                </span>
              </div>

              <div className="flex justify-between">
                <div>
                  <span className="text-[#58677D] block">Amount lost:</span>
                  <span className="font-bold text-[#B53232] text-sm">₹8,500</span>
                </div>
                <div>
                  <span className="text-[#58677D] block">Date:</span>
                  <span className="font-semibold text-[#182B49]">04 Oct 2026</span>
                </div>
              </div>

              <div>
                <span className="text-[#58677D] block">Official reference:</span>
                <span className="text-[#8B98A9] italic text-[11px]">
                  Not added yet (add after filing on portal)
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-[#DCE3ED]">
              <Link
                href="/report"
                className="w-full inline-flex items-center justify-center gap-1.5 py-2.5 rounded-lg bg-[#245CC5] hover:bg-[#19489F] text-white text-xs font-semibold transition-colors shadow-xs"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Prepare report summary</span>
              </Link>
            </div>
          </div>

          {/* Private Notes Panel */}
          <div className="clyra-card p-5 bg-white space-y-3">
            <div className="flex items-center justify-between border-b border-[#DCE3ED] pb-2.5">
              <span className="text-xs font-bold text-[#182B49]">Private Notes</span>
              <span className="text-[11px] text-[#58677D]">Not shared publicly</span>
            </div>

            <div className="p-3 rounded-lg bg-[#F6F8FB] border border-[#DCE3ED] text-xs text-[#182B49] leading-relaxed">
              &ldquo;Bank support asked me to retain the receipt and transaction reference. I will check their response in the official app.&rdquo;
            </div>

            <p className="text-[11px] text-[#8B98A9]">
              Keep notes of who you contacted and when.
            </p>
          </div>

          {/* Evidence Kept Private Card */}
          <div className="clyra-card p-5 bg-white space-y-3">
            <div className="flex items-center justify-between border-b border-[#DCE3ED] pb-2.5">
              <span className="text-xs font-bold text-[#182B49]">Evidence Inventory</span>
              <Lock className="w-3.5 h-3.5 text-[#245CC5]" />
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-lg border border-[#DCE3ED] bg-[#F6F8FB] flex items-center justify-between">
                <div>
                  <span className="font-semibold text-[#182B49] block">Payment receipt.pdf</span>
                  <span className="text-[10px] text-[#58677D]">Added 04 Oct 2026</span>
                </div>
                <span className="text-[10px] font-bold text-[#245CC5] bg-white px-2 py-0.5 rounded border border-[#DCE3ED]">
                  Private
                </span>
              </div>

              <div className="p-2.5 rounded-lg border border-[#DCE3ED] bg-[#F6F8FB] flex items-center justify-between">
                <div>
                  <span className="font-semibold text-[#182B49] block">Conversation-redacted.png</span>
                  <span className="text-[10px] text-[#58677D]">Details hidden</span>
                </div>
                <span className="text-[10px] font-bold text-[#245CC5] bg-white px-2 py-0.5 rounded border border-[#DCE3ED]">
                  Private
                </span>
              </div>
            </div>

            <p className="text-[11px] text-[#8B98A9]">
              Never post evidence, account numbers, or OTPs in the public community.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
