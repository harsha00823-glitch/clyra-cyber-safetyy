"use client";

import { useState, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { AnalysisResult } from "@/types/analysis";
import { extractTextFromImage } from "@/lib/utils/ocr";
import { 
  ShieldCheck, 
  MessageSquare, 
  Link2, 
  Camera, 
  AlertTriangle, 
  Lock,
  PhoneCall,
  XCircle,
  AlertOctagon,
  ArrowRight,
  CheckCircle2
} from "lucide-react";

type TabMode = "message" | "url" | "screenshot";

function AnalyzeContent() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("query") || "";

  const [activeTab, setActiveTab] = useState<TabMode>("message");
  const [input, setInput] = useState(initialQuery);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
      setResult(null);
      setError(null);
    }
  };

  const loadSample = (type: "safe" | "moderate" | "danger") => {
    setError(null);
    setResult(null);
    setImageFile(null);
    setImagePreview(null);
    setActiveTab("message");

    if (type === "safe") {
      setInput("Your monthly electricity bill of Rs 1,420 for Consumer ID 982341 has been generated. You can pay securely through the official BESCOM app or portal.");
    } else if (type === "moderate") {
      setInput("Urgent: Your parcel could not be delivered due to an incomplete house number. Update your delivery address within 24 hours at http://track-postal-status.in/update");
    } else {
      setInput("Dear customer, your bank KYC expires TODAY. Your account will be blocked in 2 hours. Update now at http://sbi-card-kyc-verification.top and enter the OTP to avoid permanent suspension.");
    }
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setError(null);
    setResult(null);
    
    let textToAnalyze = input;

    try {
      if (activeTab === "screenshot") {
        if (!imageFile) {
          throw new Error("Please select an image file first.");
        }
        setOcrProgress(true);
        textToAnalyze = await extractTextFromImage(imageFile);
        setOcrProgress(false);
        
        if (!textToAnalyze || textToAnalyze.trim().length < 3) {
          throw new Error("Could not extract readable text. Try a clearer image or paste text manually.");
        }
      } else {
        if (!textToAnalyze.trim()) {
          throw new Error("Please enter content to check.");
        }
      }

      const endpoint = activeTab === "url" ? "/api/analyze/url" : "/api/analyze/message";
      const payloadKey = activeTab === "url" ? "url" : "text";

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [payloadKey]: textToAnalyze }),
      });

      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || "Analysis failed. Please try again.");
      }

      setResult(data);
    } catch (err: unknown) {
      const errorObj = err as Error;
      setError(errorObj.message);
    } finally {
      setIsAnalyzing(false);
      setOcrProgress(false);
    }
  };

  const resetForm = () => {
    setInput("");
    setImageFile(null);
    setImagePreview(null);
    setResult(null);
    setError(null);
  };

  const isDanger = result && (result.level === "critical" || result.level === "high");
  const isModerate = result && result.level === "medium";

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-2">
      {/* 1. Reassuring Step Header */}
      <header className="space-y-2 text-left">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EDF3FF] border border-[#C5D8FD] text-[#245CC5] text-xs font-semibold">
          <span>01 / DETECT</span>
          <span>·</span>
          <span>Check something</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#182B49]">
          Let’s check what you received.
        </h1>
        <p className="text-sm text-[#58677D]">
          Share only what’s needed. We’ll illuminate warning signs with clear Green (Safe), Yellow (Moderate), and Red (Danger) lights, and tell you exactly what you must NOT do.
        </p>
      </header>

      {/* 2. Visual Risk Light Level Indicator Bar */}
      <div className="grid grid-cols-3 gap-2.5 sm:gap-4 text-xs font-semibold">
        <button
          type="button"
          onClick={() => loadSample("safe")}
          className="p-3 rounded-xl border border-emerald-300 bg-gradient-to-r from-emerald-50 to-white hover:from-emerald-100/80 transition-all text-left flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 shadow-xs group"
        >
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 shadow-[0_0_8px_#10B981]"></span>
            </span>
            <div>
              <span className="text-[#18734D] font-bold block">Green Light</span>
              <span className="text-[11px] text-[#58677D] font-normal hidden sm:inline">Safe / Low Risk</span>
            </div>
          </div>
          <span className="text-[10px] text-[#18734D] bg-emerald-100/70 px-2 py-0.5 rounded font-mono font-bold group-hover:bg-emerald-200">
            Sample →
          </span>
        </button>

        <button
          type="button"
          onClick={() => loadSample("moderate")}
          className="p-3 rounded-xl border border-amber-300 bg-gradient-to-r from-amber-50 to-white hover:from-amber-100/80 transition-all text-left flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 shadow-xs group"
        >
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500 shadow-[0_0_8px_#F59E0B]"></span>
            </span>
            <div>
              <span className="text-[#925500] font-bold block">Yellow Light</span>
              <span className="text-[11px] text-[#58677D] font-normal hidden sm:inline">Moderate / Caution</span>
            </div>
          </div>
          <span className="text-[10px] text-[#925500] bg-amber-100/70 px-2 py-0.5 rounded font-mono font-bold group-hover:bg-amber-200">
            Sample →
          </span>
        </button>

        <button
          type="button"
          onClick={() => loadSample("danger")}
          className="p-3 rounded-xl border border-red-300 bg-gradient-to-r from-red-50 to-white hover:from-red-100/80 transition-all text-left flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 shadow-xs group"
        >
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-80"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600 shadow-[0_0_10px_#EF4444]"></span>
            </span>
            <div>
              <span className="text-[#B53232] font-bold block">Red Light</span>
              <span className="text-[11px] text-[#58677D] font-normal hidden sm:inline">Danger / Scam Alert</span>
            </div>
          </div>
          <span className="text-[10px] text-[#B53232] bg-red-100/70 px-2 py-0.5 rounded font-mono font-bold group-hover:bg-red-200">
            Sample →
          </span>
        </button>
      </div>

      {/* 3. Main Checking Card */}
      <div className="clyra-panel p-6 sm:p-8 bg-white space-y-6 shadow-[0_4px_20px_rgba(24,43,73,0.04)]">
        {/* Tab Selection */}
        <div className="flex items-center gap-2 border-b border-[#DCE3ED] pb-3 text-xs">
          <button
            onClick={() => { setActiveTab("message"); setResult(null); setError(null); }}
            className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 ${
              activeTab === "message"
                ? "bg-[#245CC5] text-white shadow-xs"
                : "text-[#58677D] hover:bg-[#F6F8FB]"
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Message text</span>
          </button>
          <button
            onClick={() => { setActiveTab("url"); setResult(null); setError(null); }}
            className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 ${
              activeTab === "url"
                ? "bg-[#245CC5] text-white shadow-xs"
                : "text-[#58677D] hover:bg-[#F6F8FB]"
            }`}
          >
            <Link2 className="w-3.5 h-3.5" />
            <span>Website link (URL)</span>
          </button>
          <button
            onClick={() => { setActiveTab("screenshot"); setResult(null); setError(null); }}
            className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 ${
              activeTab === "screenshot"
                ? "bg-[#245CC5] text-white shadow-xs"
                : "text-[#58677D] hover:bg-[#F6F8FB]"
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Screenshot (OCR)</span>
          </button>
        </div>

        {/* Input Area */}
        {activeTab === "screenshot" ? (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-[#DCE3ED] hover:border-[#245CC5] rounded-2xl p-6 text-center space-y-3 transition-colors bg-[#F6F8FB]">
              <Camera className="w-8 h-8 text-[#58677D] mx-auto" />
              <div>
                <label className="inline-block px-4 py-2 rounded-lg bg-white border border-[#DCE3ED] text-[#182B49] text-xs font-semibold cursor-pointer hover:bg-[#F6F8FB] shadow-xs">
                  <span>Choose redacted image</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
                <p className="text-xs text-[#58677D] mt-2">
                  Upload a PNG or JPG. We extract the text locally inside your browser.
                </p>
              </div>

              {imagePreview && (
                <div className="mt-4 rounded-xl overflow-hidden border border-[#DCE3ED] bg-white flex justify-center max-h-60 p-2">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={imagePreview} alt="Screenshot preview" className="object-contain max-h-56 rounded" />
                </div>
              )}
            </div>

            <div className="p-3 rounded-lg bg-[#EAF6EF] border border-[#C3E7D5] text-xs text-[#18734D] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>
                <strong>100% On-Device Privacy:</strong> OCR runs locally using WebAssembly. Your image is never uploaded to any cloud server.
              </span>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs">
              <label htmlFor="text-input" className="font-semibold text-[#182B49]">
                {activeTab === "url" ? "Suspicious website link" : "Message text (SMS, WhatsApp, Telegram)"}
              </label>
              <span className="text-[#925500] bg-[#FFF5E3] px-2 py-0.5 rounded border border-[#F6E1B6]">
                Keep wording, remove personal details
              </span>
            </div>

            <textarea
              id="text-input"
              rows={5}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                activeTab === "url"
                  ? "Paste the link here (e.g. http://unfamiliar-update-kyc.com)..."
                  : "Paste the message wording here (e.g. KYC blocked today, electricity cutoff)..."
              }
              className="w-full bg-[#F6F8FB] border border-[#DCE3ED] rounded-xl p-3.5 text-sm text-[#182B49] placeholder-[#8B98A9] focus:outline-none focus:ring-3 focus:ring-[#93B4F4] focus:border-[#245CC5] focus:bg-white transition-all resize-none"
            />
          </div>
        )}

        {/* Advisory Callout */}
        <div className="p-3.5 rounded-xl bg-[#F6F8FB] border border-[#DCE3ED] text-xs text-[#58677D] flex items-start gap-2.5">
          <Lock className="w-4 h-4 text-[#245CC5] shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <p className="font-semibold text-[#182B49]">Before you check:</p>
            <p className="leading-relaxed">
              Do not submit OTPs, UPI PINs, passwords, full account numbers or identity documents. Remove names and personal phone numbers first.
            </p>
          </div>
        </div>

        {error && (
          <div className="p-3.5 rounded-xl bg-[#FFF0EE] border border-[#FFD5D2] text-xs text-[#B53232] flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {/* Action Button */}
        <div className="flex items-center justify-between pt-2">
          <Button
            onClick={handleAnalyze}
            isLoading={isAnalyzing}
            disabled={activeTab === "screenshot" ? !imageFile : !input.trim()}
            className="w-full sm:w-auto px-6 shadow-xs"
          >
            {ocrProgress ? "Reading image text locally..." : "Check for warning signs"}
          </Button>

          {(input || imageFile || result) && (
            <button
              onClick={resetForm}
              className="text-xs text-[#58677D] hover:text-[#182B49] hover:underline"
            >
              Clear &amp; start over
            </button>
          )}
        </div>
      </div>

      {/* 4. UNDERSTAND / STEP 2: The Illuminated Risk Light Result Screen */}
      {result && (
        <section 
          id="analysis-result-panel"
          data-testid="analysis-result-panel"
          className={`rounded-3xl p-6 sm:p-8 space-y-6 transition-all duration-300 animate-in fade-in ${
            isDanger
              ? "border-2 border-[#B53232] bg-gradient-to-b from-[#FFF0EE] via-white to-[#FFF0EE]/40 shadow-[0_0_45px_rgba(181,50,50,0.28)] ring-2 ring-[#B53232]/25"
              : isModerate
              ? "border-2 border-[#D97706] bg-gradient-to-b from-[#FFF5E3] via-white to-[#FFF5E3]/40 shadow-[0_0_40px_rgba(217,119,6,0.22)] ring-2 ring-[#D97706]/20"
              : "border-2 border-[#18734D] bg-gradient-to-b from-[#EAF6EF] via-white to-[#EAF6EF]/30 shadow-[0_0_35px_rgba(24,115,77,0.18)] ring-2 ring-[#18734D]/15"
          }`}
        >
          {/* Top Illuminated Beacon Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#DCE3ED] pb-5">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-2">
                <span className="relative flex h-3.5 w-3.5">
                  <span 
                    className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                      isDanger ? "bg-red-500" : isModerate ? "bg-amber-500" : "bg-emerald-500"
                    }`}
                  ></span>
                  <span 
                    className={`relative inline-flex rounded-full h-3.5 w-3.5 ${
                      isDanger 
                        ? "bg-[#B53232] shadow-[0_0_12px_#B53232]" 
                        : isModerate 
                        ? "bg-[#D97706] shadow-[0_0_10px_#D97706]" 
                        : "bg-[#18734D] shadow-[0_0_10px_#18734D]"
                    }`}
                  ></span>
                </span>
                <span 
                  className={`text-xs font-bold uppercase tracking-wider ${
                    isDanger ? "text-[#B53232]" : isModerate ? "text-[#925500]" : "text-[#18734D]"
                  }`}
                >
                  {isDanger ? "RED LIGHT · DANGER / HIGH RISK" : isModerate ? "YELLOW LIGHT · MODERATE RISK / CAUTION" : "GREEN LIGHT · SAFE / NO OBVIOUS SIGNS"}
                </span>
              </div>

              <h2 className="text-xl sm:text-2xl font-bold text-[#182B49]">
                {isDanger
                  ? "This message shows high-risk warning signs."
                  : isModerate
                  ? "This message needs a closer look."
                  : "No obvious warning signs detected."}
              </h2>
              <p className="text-xs text-[#58677D]">
                {isDanger
                  ? "High urgency and coercive wording detected. Do not click, pay, or reply."
                  : isModerate
                  ? "Unverified link or vague delivery request. Pause before you respond."
                  : "Routine wording with no detected urgency traps or malicious links."}
              </p>
            </div>

            {/* Score Pill */}
            <div className="shrink-0 flex items-center gap-3">
              <div 
                className={`px-4 py-2 rounded-2xl border text-center font-mono ${
                  isDanger 
                    ? "bg-[#FFF0EE] border-[#FFD5D2] text-[#B53232]" 
                    : isModerate 
                    ? "bg-[#FFF5E3] border-[#F6E1B6] text-[#925500]" 
                    : "bg-[#EAF6EF] border-[#C3E7D5] text-[#18734D]"
                }`}
              >
                <span className="text-xs block font-sans font-bold uppercase">Risk Score</span>
                <span className="text-xl font-extrabold">{result.score}</span>
                <span className="text-[11px] text-[#58677D]"> / 100</span>
              </div>
            </div>
          </div>

          {/* Plain Language Summary */}
          <div className="p-4 rounded-xl bg-white border border-[#DCE3ED] space-y-1 shadow-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#58677D]">
              Summary of analysis:
            </span>
            <p className="text-sm text-[#182B49] leading-relaxed font-medium">
              {result.summary}
            </p>
          </div>

          {/* CRITICAL: WHAT YOU MUST NOT DO (The Explicit Safety Barrier) */}
          <div 
            className={`p-5 rounded-2xl border space-y-3 ${
              isDanger 
                ? "bg-[#FFF0EE] border-[#FFD5D2]" 
                : isModerate 
                ? "bg-[#FFF5E3] border-[#F6E1B6]" 
                : "bg-[#F6F8FB] border-[#DCE3ED]"
            }`}
          >
            <div className="flex items-center gap-2">
              {isDanger ? (
                <AlertOctagon className="w-5 h-5 text-[#B53232] shrink-0" />
              ) : isModerate ? (
                <AlertTriangle className="w-5 h-5 text-[#925500] shrink-0" />
              ) : (
                <ShieldCheck className="w-5 h-5 text-[#18734D] shrink-0" />
              )}
              <h3 
                className={`text-sm font-bold uppercase tracking-wider ${
                  isDanger ? "text-[#B53232]" : isModerate ? "text-[#925500]" : "text-[#182B49]"
                }`}
              >
                {isDanger ? "CRITICAL: WHAT YOU MUST NOT DO" : isModerate ? "WHAT YOU MUST NOT DO" : "SAFE ROUTINE PRECAUTIONS (WHAT NOT TO DO)"}
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-[#182B49]">
              {isDanger ? (
                <>
                  <div className="p-3 bg-white rounded-xl border border-[#FFD5D2] flex items-start gap-2">
                    <XCircle className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#B53232] block font-bold">DO NOT SEND MONEY OR APPROVE UPI REQUESTS</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">UPI PIN is strictly for paying. Receiving money NEVER requires entering a PIN or clicking approve.</p>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-[#FFD5D2] flex items-start gap-2">
                    <XCircle className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#B53232] block font-bold">DO NOT STAY ON VIDEO CALLS (DIGITAL ARREST)</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">Police, CBI, and courts NEVER conduct arrests, trials, or document verification over Skype or WhatsApp.</p>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-[#FFD5D2] flex items-start gap-2">
                    <XCircle className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#B53232] block font-bold">DO NOT CLICK THE LINK OR SHARE AN OTP</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">Banks never demand OTPs or passwords to stop account suspension. Links lead to credential harvesting sites.</p>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-[#FFD5D2] flex items-start gap-2">
                    <XCircle className="w-4 h-4 text-[#B53232] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#B53232] block font-bold">DO NOT INSTALL APKS OR SCREEN-SHARING APPS</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">Never install AnyDesk, TeamViewer, QuickSupport, or WhatsApp APKs sent by unknown callers.</p>
                    </div>
                  </div>
                </>
              ) : isModerate ? (
                <>
                  <div className="p-3 bg-white rounded-xl border border-[#F6E1B6] flex items-start gap-2">
                    <XCircle className="w-4 h-4 text-[#925500] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#925500] block font-bold">DO NOT CLICK UNVERIFIED SHORT LINKS</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">Open the official service website or courier app directly by typing the known URL yourself.</p>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-[#F6E1B6] flex items-start gap-2">
                    <XCircle className="w-4 h-4 text-[#925500] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#925500] block font-bold">DO NOT ENTER PASSWORDS OR CARD DETAILS</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">If redirected from a message, never enter debit card numbers, CVVs, or bank logins.</p>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-[#F6E1B6] flex items-start gap-2">
                    <XCircle className="w-4 h-4 text-[#925500] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#925500] block font-bold">DO NOT CALL THE PHONE NUMBER IN THE TEXT</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">Look up official customer support on your bank card or official utility bill.</p>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-[#F6E1B6] flex items-start gap-2">
                    <XCircle className="w-4 h-4 text-[#925500] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#925500] block font-bold">DO NOT FORWARD UNVERIFIED MESSAGES</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">Prevent spreading unverified financial or delivery claims to family and group chats.</p>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="p-3 bg-white rounded-xl border border-[#DCE3ED] flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#18734D] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#182B49] block font-bold">DO NOT REVEAL PASSWORDS EVEN IF MESSAGE LOOKS REAL</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">Routine updates never require sharing your credentials or approving unexpected transactions.</p>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-[#DCE3ED] flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#18734D] shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-[#182B49] block font-bold">DO NOT ASSUME SENDER IDs CANNOT BE SPOOFED</strong>
                      <p className="text-[#58677D] mt-0.5 text-[11px]">Always access your banking or service dashboard through your own bookmarked app.</p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Warning Signs List (Numbered Cards) */}
          {result.signals.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#58677D]">
                Why these are warning signs:
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {result.signals.map((signal, idx) => (
                  <div
                    key={idx}
                    className={`p-4 rounded-xl border space-y-1.5 ${
                      signal.severity === "high" || signal.severity === "critical"
                        ? "bg-[#FFF0EE] border-[#FFD5D2]"
                        : "bg-[#FFF5E3] border-[#F6E1B6]"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-white text-xs font-bold flex items-center justify-center border border-current shadow-xs">
                        {idx + 1}
                      </span>
                      <span className="font-bold text-xs text-[#182B49]">
                        {signal.name}
                      </span>
                    </div>
                    <p className="text-xs text-[#58677D] leading-relaxed">
                      {signal.explanation}
                    </p>
                    <div className="pt-1 text-[11px] font-semibold text-[#182B49]">
                      Advice: {signal.recommendedAction}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Practical Next Steps */}
          <div className="p-5 rounded-2xl bg-[#EDF3FF] border border-[#C5D8FD] space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#245CC5]">
              What to do now:
            </h3>
            <ul className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-[#182B49]">
              <li className="p-3 bg-white rounded-xl border border-[#DCE3ED] space-y-1">
                <span className="font-bold text-[#245CC5] block">1 · Stop interacting</span>
                <p className="text-[#58677D]">
                  Don’t click, reply, pay, or share an OTP. Block the sender after saving the text.
                </p>
              </li>
              <li className="p-3 bg-white rounded-xl border border-[#DCE3ED] space-y-1">
                <span className="font-bold text-[#245CC5] block">2 · Check with bank directly</span>
                <p className="text-[#58677D]">
                  Open your bank’s official app yourself or use the customer care number on your card.
                </p>
              </li>
              <li className="p-3 bg-white rounded-xl border border-[#DCE3ED] space-y-1">
                <span className="font-bold text-[#245CC5] block">3 · Keep the original privately</span>
                <p className="text-[#58677D]">
                  Preserve screenshots and timestamps in your recovery workspace for future reporting.
                </p>
              </li>
            </ul>
          </div>

          {/* Emergency 1930 Callout (If Danger or High Risk) */}
          {isDanger && (
            <div className="p-4 rounded-xl bg-[#FFF0EE] border border-[#FFD5D2] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#B53232]">
                  <PhoneCall className="w-4 h-4" />
                  <span>Lost money to this sender already?</span>
                </div>
                <p className="text-xs text-[#58677D]">
                  Call India&apos;s cyber financial fraud helpline immediately: <strong className="text-[#182B49]">1930</strong>.
                </p>
              </div>
              <a
                href="tel:1930"
                className="w-full sm:w-auto px-4 py-2 rounded-lg bg-[#B53232] hover:bg-[#932525] text-white text-xs font-bold text-center transition-colors shadow-xs"
              >
                Call 1930 Helpline
              </a>
            </div>
          )}

          {/* Action Row: Recovery, Report, New Check */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2 border-t border-[#DCE3ED]">
            <div className="flex items-center gap-2">
              <Link
                href="/dashboard"
                className="px-4 py-2.5 rounded-lg bg-[#245CC5] hover:bg-[#19489F] text-white text-xs font-semibold transition-colors shadow-xs flex items-center gap-1.5"
              >
                <span>Open my safety checklist</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
              <Link
                href="/report"
                className="px-4 py-2.5 rounded-lg border border-[#DCE3ED] bg-white hover:bg-[#F6F8FB] text-[#182B49] text-xs font-semibold transition-colors"
              >
                Prepare incident report
              </Link>
            </div>

            <button
              onClick={resetForm}
              className="text-xs text-[#58677D] hover:text-[#182B49] text-center sm:text-right hover:underline"
            >
              Check another message
            </button>
          </div>

          {/* Honest Boundary Disclaimer */}
          <p className="text-[11px] text-[#8B98A9] italic text-center pt-2">
            A check cannot guarantee safety. Legitimate messages can look unusual, and scams can look convincing. Always confirm through official channels.
          </p>
        </section>
      )}
    </div>
  );
}

export default function AnalyzePage() {
  return (
    <Suspense fallback={<div className="max-w-4xl mx-auto py-12 text-center text-xs text-[#58677D]">Loading Analyzer...</div>}>
      <AnalyzeContent />
    </Suspense>
  );
}
