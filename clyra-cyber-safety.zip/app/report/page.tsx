"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { 
  ExternalLink, 
  PhoneCall, 
  Download, 
  CheckCircle2
} from "lucide-react";

export default function ReportPage() {
  const [step, setStep] = useState<1 | 2>(1);
  const [incidentType, setIncidentType] = useState("Suspected UPI payment scam");
  const [amountLost, setAmountLost] = useState("8500");
  const [incidentDate, setIncidentDate] = useState("2026-10-04");
  const [incidentTime, setIncidentTime] = useState("14:20");
  const [referenceNumber, setReferenceNumber] = useState("DEMO-UTR-014");
  const [platform, setPlatform] = useState("UPI payment app");
  const [narrative, setNarrative] = useState(
    "I received a call from someone claiming to help with a refund. They sent a UPI collect request. I approved it believing I would receive money, but ₹8,500 was debited. I stopped contact and called 1930. I then contacted support through my bank’s official app and preserved the receipt and conversation."
  );

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-2">
      {/* 1. Reassuring Header */}
      <header className="space-y-2 text-left no-print">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EDF3FF] border border-[#C5D8FD] text-[#245CC5] text-xs font-semibold">
          <span>04 / REPORT</span>
          <span>·</span>
          <span>{step === 1 ? "Prepare incident summary" : "Review & export"}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#182B49]">
          {step === 1 ? "Tell your story, one detail at a time." : "Your summary is ready for review."}
        </h1>
        <p className="text-sm text-[#58677D]">
          We’ll organise a summary for you to review and submit through the official portal. CLYRA does not submit it for you.
        </p>
      </header>

      {/* 2. Urgent Callout */}
      <div className="saathi-card p-4 bg-[#FFF5E3] border-[#F6E1B6] text-xs text-[#925500] flex items-center justify-between gap-3 no-print">
        <div className="flex items-center gap-2">
          <PhoneCall className="w-4 h-4 text-[#925500] shrink-0" />
          <span>
            <strong>Money just left your account?</strong> Call <strong>1930</strong> and contact your bank promptly. You don&apos;t need to complete this form first.
          </span>
        </div>
        <a
          href="tel:1930"
          className="px-3 py-1.5 rounded-lg bg-[#B53232] text-white font-bold text-xs shrink-0 hover:bg-[#932525]"
        >
          Call 1930
        </a>
      </div>

      {/* 3. Progress Step Pills (Figma: 1 Incident details -> 2 Review & export -> 3 Submit on official portal) */}
      <div className="flex items-center gap-2 text-xs font-semibold border-b border-[#DCE3ED] pb-3 no-print">
        <button
          onClick={() => setStep(1)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
            step === 1 ? "bg-[#245CC5] text-white" : "text-[#58677D] hover:bg-[#F6F8FB]"
          }`}
        >
          <span>1 · Incident details</span>
        </button>
        <span className="text-[#8B98A9]">→</span>
        <button
          onClick={() => setStep(2)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
            step === 2 ? "bg-[#245CC5] text-white" : "text-[#58677D] hover:bg-[#F6F8FB]"
          }`}
        >
          <span>2 · Review &amp; export</span>
        </button>
        <span className="text-[#8B98A9]">→</span>
        <span className="text-[#8B98A9] px-2 py-1">
          3 · Submit on official portal
        </span>
      </div>

      {/* STEP 1: FORM INPUTS */}
      {step === 1 && (
        <div className="saathi-panel p-6 sm:p-8 bg-white space-y-6 no-print">
          <div className="border-b border-[#DCE3ED] pb-4">
            <h2 className="text-base font-bold text-[#182B49]">
              Incident Details
            </h2>
            <p className="text-xs text-[#58677D]">
              Provide what you know. You can use &ldquo;approximately&rdquo; if you are unsure of exact times.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1.5">
              <label className="font-semibold text-[#182B49] block">Incident type</label>
              <select
                value={incidentType}
                onChange={(e) => setIncidentType(e.target.value)}
                className="w-full bg-[#F6F8FB] border border-[#DCE3ED] rounded-lg p-2.5 text-xs text-[#182B49] focus:outline-none focus:ring-3 focus:ring-[#93B4F4]"
              >
                <option value="Suspected UPI payment scam">UPI / payment scam</option>
                <option value="Digital arrest extortion attempt">Digital arrest coercion</option>
                <option value="Fake bank KYC phishing">Fake bank KYC phishing</option>
                <option value="Malicious APK installation">Malicious APK / OTP interception</option>
                <option value="Part-time job / task scam">Part-time job / task scam</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-[#182B49] block">Platform or payment app used</label>
              <input
                type="text"
                value={platform}
                onChange={(e) => setPlatform(e.target.value)}
                placeholder="e.g. Google Pay, PhonePe, WhatsApp, Telegram"
                className="w-full bg-[#F6F8FB] border border-[#DCE3ED] rounded-lg p-2.5 text-xs text-[#182B49] focus:outline-none focus:ring-3 focus:ring-[#93B4F4]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-[#182B49] block">Date of incident</label>
              <input
                type="date"
                value={incidentDate}
                onChange={(e) => setIncidentDate(e.target.value)}
                className="w-full bg-[#F6F8FB] border border-[#DCE3ED] rounded-lg p-2.5 text-xs text-[#182B49] focus:outline-none focus:ring-3 focus:ring-[#93B4F4]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-[#182B49] block">Approximate time (IST)</label>
              <input
                type="time"
                value={incidentTime}
                onChange={(e) => setIncidentTime(e.target.value)}
                className="w-full bg-[#F6F8FB] border border-[#DCE3ED] rounded-lg p-2.5 text-xs text-[#182B49] focus:outline-none focus:ring-3 focus:ring-[#93B4F4]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-[#182B49] block">Amount lost (₹)</label>
              <input
                type="number"
                value={amountLost}
                onChange={(e) => setAmountLost(e.target.value)}
                placeholder="Leave blank if no money was lost"
                className="w-full bg-[#F6F8FB] border border-[#DCE3ED] rounded-lg p-2.5 text-xs text-[#182B49] focus:outline-none focus:ring-3 focus:ring-[#93B4F4]"
              />
              <p className="text-[11px] text-[#58677D]">Include only money that left your account.</p>
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-[#182B49] block">Transaction / UTR Reference</label>
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                placeholder="e.g. 12-digit UTR number from bank SMS"
                className="w-full bg-[#F6F8FB] border border-[#DCE3ED] rounded-lg p-2.5 text-xs text-[#182B49] focus:outline-none focus:ring-3 focus:ring-[#93B4F4]"
              />
            </div>
          </div>

          <div className="space-y-1.5 text-xs">
            <label className="font-semibold text-[#182B49] block">
              What happened? (Brief description in your own words)
            </label>
            <textarea
              rows={4}
              value={narrative}
              onChange={(e) => setNarrative(e.target.value)}
              className="w-full bg-[#F6F8FB] border border-[#DCE3ED] rounded-lg p-3 text-xs text-[#182B49] focus:outline-none focus:ring-3 focus:ring-[#93B4F4] resize-none leading-relaxed"
            />
            <p className="text-[11px] text-[#58677D]">
              Include the sequence of events. Do not enter an OTP, PIN, password, or CVV.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-between border-t border-[#DCE3ED]">
            <Link
              href="/dashboard"
              className="text-xs text-[#58677D] hover:text-[#182B49] hover:underline"
            >
              ← Back to recovery workspace
            </Link>

            <Button
              onClick={() => setStep(2)}
              className="px-6"
            >
              Review summary draft →
            </Button>
          </div>
        </div>
      )}

      {/* STEP 2: REVIEW & EXPORT SUMMARY (Matches Figma Spec) */}
      {step === 2 && (
        <div className="space-y-6">
          {/* Honest Notice Card */}
          <div className="saathi-card p-4 bg-[#EDF3FF] border-[#C5D8FD] text-xs text-[#245CC5] flex items-center gap-2.5 no-print">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <div>
              <p className="font-bold">Preparation complete — not an official complaint</p>
              <p className="text-[#58677D]">
                This summary is ready to export. No complaint has been lodged by CLYRA, and no official acknowledgement has been received here.
              </p>
            </div>
          </div>

          {/* Clean Printable Incident Summary Document */}
          <div className="saathi-panel p-8 bg-white space-y-6 print:shadow-none print:border-none print:p-0">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b-2 border-[#182B49] pb-4">
              <div>
                <span className="text-[10px] font-bold tracking-widest uppercase text-[#58677D]">
                  CLYRA Cyber Safety · Incident Summary
                </span>
                <h2 className="text-xl font-bold text-[#182B49]">
                  Personal Incident Dossier
                </h2>
              </div>
              <div className="text-right text-xs text-[#58677D]">
                <p>Record ID: <strong className="text-[#182B49]">SC-DEMO-014</strong></p>
                <p>Prepared: 05 Oct 2026</p>
              </div>
            </div>

            {/* Structured Table */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-[#F6F8FB] border border-[#DCE3ED] text-xs">
              <div>
                <span className="text-[#58677D] block text-[11px]">INCIDENT TYPE</span>
                <span className="font-bold text-[#182B49]">{incidentType}</span>
              </div>
              <div>
                <span className="text-[#58677D] block text-[11px]">PLATFORM</span>
                <span className="font-bold text-[#182B49]">{platform}</span>
              </div>
              <div>
                <span className="text-[#58677D] block text-[11px]">WHEN</span>
                <span className="font-bold text-[#182B49]">{incidentDate} · {incidentTime} IST</span>
              </div>
              <div>
                <span className="text-[#58677D] block text-[11px]">AMOUNT &amp; REF</span>
                <span className="font-bold text-[#B53232]">₹{amountLost || "0"} · {referenceNumber}</span>
              </div>
            </div>

            {/* Sequence of Events Narrative */}
            <div className="space-y-2 text-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#58677D]">
                Sequence of Events (What Happened)
              </span>
              <div className="p-4 rounded-xl border border-[#DCE3ED] bg-white text-[#182B49] leading-relaxed text-sm">
                &ldquo;{narrative}&rdquo;
              </div>
            </div>

            {/* Evidence Inventory */}
            <div className="space-y-2 text-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#58677D]">
                Evidence In This Draft
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="p-3 rounded-lg border border-[#DCE3ED] bg-[#F6F8FB] flex items-center justify-between">
                  <span className="font-semibold text-[#182B49]">Payment receipt.pdf</span>
                  <span className="text-[11px] text-[#58677D]">1 illustrative PDF attached</span>
                </div>
                <div className="p-3 rounded-lg border border-[#DCE3ED] bg-[#F6F8FB] flex items-center justify-between">
                  <span className="font-semibold text-[#182B49]">Redacted conversation.png</span>
                  <span className="text-[11px] text-[#58677D]">1 illustrative image attached</span>
                </div>
              </div>
            </div>

            {/* Disclaimer */}
            <div className="border-t border-[#DCE3ED] pt-4 text-[11px] text-[#8B98A9] text-center">
              All dates, amounts, and references are recorded by the user. CLYRA Cyber Safety is a community guidance concept, not an official government service.
            </div>

            {/* Action Buttons (From Figma) */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-[#DCE3ED] no-print">
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Button
                  onClick={handlePrint}
                  variant="primary"
                  className="w-full sm:w-auto flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Export summary · PDF</span>
                </Button>

                <button
                  onClick={() => setStep(1)}
                  className="px-4 py-2.5 rounded-lg border border-[#DCE3ED] bg-white hover:bg-[#F6F8FB] text-[#182B49] text-xs font-semibold transition-colors"
                >
                  Edit details
                </button>
              </div>

              <a
                href="https://cybercrime.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-[#245CC5] bg-[#EDF3FF] hover:bg-[#DCE7FD] text-[#245CC5] text-xs font-bold transition-colors"
              >
                <span>Open official reporting portal (cybercrime.gov.in)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Print styles */}
      <style dangerouslySetInnerHTML={{__html: `
        @media print {
          body * { visibility: hidden; }
          .no-print { display: none !important; }
          .saathi-panel, .saathi-panel * { visibility: visible; }
          .saathi-panel { position: absolute; left: 0; top: 0; width: 100%; border: none !important; box-shadow: none !important; }
        }
      `}} />
    </div>
  );
}
